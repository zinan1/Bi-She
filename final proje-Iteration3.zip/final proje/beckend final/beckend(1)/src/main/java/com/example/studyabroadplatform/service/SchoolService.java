package com.example.studyabroadplatform.service;
import com.example.studyabroadplatform.model.School;
import com.example.studyabroadplatform.repository.SchoolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class SchoolService  {
    @Autowired
    private SchoolRepository schoolRepository;

    public List<School> findAll() {
        return schoolRepository.findAll();
    }

    public School findById(Long id) {
        return schoolRepository.findById(id).orElse(null);
    }

    public School save(School school) {
        return schoolRepository.save(school);
    }

    public void deleteById(Long id) {
        schoolRepository.deleteById(id);
    }

    public School findBySchoolId(String schoolId) {
        return schoolRepository.findBySchoolId(schoolId)
                .orElseThrow(() -> new RuntimeException("学校不存在"));
    }

    public List<School> findSchoolsByMajor(String major) {
        List<School> allSchools = findAll();
        List<School> schoolsWithMajor = new ArrayList<>();

        for (School school : allSchools) {
            List<String> majors = school.getMajors();
            if (majors != null && majors.contains(major)) {
                schoolsWithMajor.add(school);
            }
        }

        return schoolsWithMajor;
    }
    
    // 添加按学校名称查询的方法
    public List<School> findSchoolsByName(String schoolName) {
        return schoolRepository.findBySchoolNameContaining(schoolName);
    }
    
    // 添加按地域查询的方法
    public List<School> findSchoolsByLocation(String location) {
        return schoolRepository.findByLocationContaining(location);
    }
}