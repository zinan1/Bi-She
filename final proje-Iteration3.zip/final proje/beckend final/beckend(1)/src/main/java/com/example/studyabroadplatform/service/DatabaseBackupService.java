package com.example.studyabroadplatform.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DatabaseBackupService {

    @Value("${spring.datasource.username}")
    private String dbUsername;

    @Value("${spring.datasource.password}")
    private String dbPassword;

    @Value("${spring.datasource.url}")
    private String dbUrl;

    private String dbName;

    // 备份文件存储目录
    private final String BACKUP_DIR = "backups";
    
    // 最大保留备份数量
    private final int MAX_BACKUPS = 10;

    public DatabaseBackupService() {
        // 创建备份目录
        File backupDir = new File(BACKUP_DIR);
        if (!backupDir.exists()) {
            backupDir.mkdirs();
        }
    }

    /**
     * 初始化数据库名称
     */
    private void initDbName() {
        if (dbName == null && dbUrl != null) {
            // 从JDBC URL中提取数据库名称
            int lastSlashIndex = dbUrl.lastIndexOf("/");
            int questionMarkIndex = dbUrl.indexOf("?");
            if (questionMarkIndex > 0) {
                dbName = dbUrl.substring(lastSlashIndex + 1, questionMarkIndex);
            } else {
                dbName = dbUrl.substring(lastSlashIndex + 1);
            }
        }
    }

    /**
     * 执行数据库备份
     * @param backupName 备份名称（可选）
     * @return 备份文件路径
     */
    public String backupDatabase(String backupName) throws IOException {
        initDbName();
        
        // 生成备份文件名
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = (backupName != null && !backupName.isEmpty()) 
                ? backupName + "_" + timestamp + ".sql" 
                : "backup_" + timestamp + ".sql";
        
        String backupFilePath = BACKUP_DIR + File.separator + fileName;
        
        // 构建mysqldump命令
        ProcessBuilder processBuilder = new ProcessBuilder(
                "mysqldump",
                "--user=" + dbUsername,
                "--password=" + dbPassword,
                "--databases", dbName,
                "--result-file=" + backupFilePath
        );
        
        Process process = processBuilder.start();
        
        try {
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                // 备份成功后，检查并删除多余的备份
                cleanupOldBackups();
                return backupFilePath;
            } else {
                throw new IOException("数据库备份失败，退出代码: " + exitCode);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("数据库备份过程被中断", e);
        }
    }
    
    /**
     * 从备份文件恢复数据库
     * @param backupFilePath 备份文件路径
     */
    public void restoreDatabase(String backupFilePath) throws IOException {
        initDbName();
        
        File backupFile = new File(backupFilePath);
        if (!backupFile.exists()) {
            throw new IOException("备份文件不存在: " + backupFilePath);
        }
        
        // 构建mysql命令
        ProcessBuilder processBuilder = new ProcessBuilder(
                "mysql",
                "--user=" + dbUsername,
                "--password=" + dbPassword,
                dbName
        );
        
        Process process = processBuilder.start();
        
        // 将备份文件内容写入mysql进程的输入流
        try {
            Files.copy(backupFile.toPath(), process.getOutputStream());
            process.getOutputStream().close();
            
            // 读取错误输出
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            String errorLine;
            StringBuilder errorOutput = new StringBuilder();
            while ((errorLine = errorReader.readLine()) != null) {
                errorOutput.append(errorLine).append("\n");
            }
            
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                throw new IOException("数据库恢复失败，退出代码: " + exitCode + "\n错误信息: " + errorOutput.toString());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("数据库恢复过程被中断", e);
        }
    }
    
    /**
     * 获取所有备份文件列表
     */
    public List<String> getAllBackups() throws IOException {
        Path backupPath = Paths.get(BACKUP_DIR);
        return Files.list(backupPath)
                .filter(path -> path.toString().endsWith(".sql"))
                .map(Path::toString)
                .collect(Collectors.toList());
    }
    
    /**
     * 清理旧备份，只保留最新的MAX_BACKUPS个备份
     */
    private void cleanupOldBackups() throws IOException {
        Path backupPath = Paths.get(BACKUP_DIR);
        List<Path> backupFiles = Files.list(backupPath)
                .filter(path -> path.toString().endsWith(".sql"))
                .sorted(Comparator.comparing(path -> {
                    try {
                        return Files.getLastModifiedTime(path);
                    } catch (IOException e) {
                        return null;
                    }
                }))
                .collect(Collectors.toList());
        
        // 如果备份数量超过最大值，删除最旧的备份
        if (backupFiles.size() > MAX_BACKUPS) {
            int filesToDelete = backupFiles.size() - MAX_BACKUPS;
            for (int i = 0; i < filesToDelete; i++) {
                Files.delete(backupFiles.get(i));
            }
        }
    }
    
    /**
     * 定时备份任务 - 每天凌晨2点执行
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void scheduledBackup() {
        try {
            String backupName = "scheduled";
            backupDatabase(backupName);
        } catch (IOException e) {
            // 记录错误日志
            e.printStackTrace();
        }
    }
}