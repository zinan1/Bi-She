package com.example.studyabroadplatform.controller;
import com.example.studyabroadplatform.model.*;
import com.example.studyabroadplatform.service.ApplicationService;

import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.*;

import com.example.studyabroadplatform.service.SchoolService;
import com.example.studyabroadplatform.service.StudentService;
import com.example.studyabroadplatform.util.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


@RestController
@RequestMapping("/api/student")
public class StudentController {
    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private SchoolService schoolService;

    @Autowired
    private JwtUtil jwtUtil;


    @PostMapping("/applications")
    public ResponseEntity<?> submitApplication(
            @RequestParam("file") MultipartFile file,
            @RequestParam("applicationData") String applicationDataJson,
            @RequestHeader("Authorization") String token) {
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        try {
            // 将JSON字符串转换为ApplicationVo对象
            ObjectMapper mapper = new ObjectMapper();
            ApplicationVo vo = mapper.readValue(applicationDataJson, ApplicationVo.class);

            // 检查学生是否存在
            Student student = studentService.findByStudentId(vo.getStudent_id());
            if (student == null) {
                throw new RuntimeException("学生不存在");
            }

            School school = schoolService.findBySchoolId(vo.getSchool_id());
            if (school == null) {
                throw new RuntimeException("学校不存在");
            }

            // 检查该学生是否已有该学校的某专业PENDING申请
            if (applicationService.existsPendingApplication(
                    student.getStudentId(),
                    school.getSchoolId(),
                    vo.getMajor()
            )) {
                throw new RuntimeException("已有待处理请求");
            }

            // 处理文件上传
            Path uploadPath = Paths.get("application_files");
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // 保存文件
            String originalFilename = file.getOriginalFilename();
            String filename = studentId + "_" + originalFilename;
            Path filePath = uploadPath.resolve(filename);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            // 设置学生对象时使用托管实体
            Student managedStudent = studentService.getStudentById(student.getId());

            // 设置申请对象
            Application application = new Application();
            application.setStudent(managedStudent);
            application.setSchool(school);

            //验证选填专业的正确性
            List<String> schoolMajors = school.getMajors();
            if (schoolMajors == null || !schoolMajors.contains(vo.getMajor())) {
                throw new RuntimeException("所选专业不在该学校提供的专业列表中");
            }

            application.setCurrentschool(vo.getCurrentschool());
            application.setMajor(vo.getMajor());
            application.setGpa(vo.getGpa());
            application.setGrades(vo.getGrades());
            application.setEnrolled(vo.getEnrolled());
            application.setStatus("PENDING");
            application.setApplicationDate(LocalDate.now());
            application.setApplicationFiles(Collections.singletonList(filePath.toString()));

            Application savedApplication = applicationService.saveApplication(application);

            Map<String, Object> response = new HashMap<>();
            response.put("application", savedApplication);
            response.put("filePath", filePath.toString());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.status(500).body("申请提交失败: " + e.getMessage());
        }
    }

    @PostMapping("/schools/search")
    public ResponseEntity<?> searchSchools(@RequestBody Map<String, String> requestBody, @RequestHeader("Authorization") String token) {
        // 解析Token获取学生ID和角色
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 从请求体中获取搜索条件
        String major = requestBody.get("major");
        String location = requestBody.get("location");
        String schoolName = requestBody.get("schoolName");

        // 如果所有搜索条件都为空，返回错误信息
        if ((major == null || major.trim().isEmpty()) &&
                (location == null || location.trim().isEmpty()) &&
                (schoolName == null || schoolName.trim().isEmpty())) {
            return ResponseEntity.badRequest().body("请至少提供一个搜索条件");
        }

        // 获取所有学校作为初始集合
        List<School> allSchools = schoolService.findAll();
        List<School> resultSchools = new ArrayList<>(allSchools);

        // 根据专业筛选
        if (major != null && !major.trim().isEmpty()) {
            List<School> schoolsWithMajor = new ArrayList<>();
            for (School school : resultSchools) {
                List<String> majors = school.getMajors();
                if (majors != null) {
                    for (String schoolMajor : majors) {
                        if (schoolMajor.contains(major)) {
                            schoolsWithMajor.add(school);
                            break; // 找到一个匹配就跳出内循环
                        }
                    }
                }
            }
            // 更新结果为交集
            resultSchools = schoolsWithMajor;
        }

        // 根据地域筛选（在现有结果中继续筛选）
        if (location != null && !location.trim().isEmpty() && !resultSchools.isEmpty()) {
            List<School> schoolsWithLocation = new ArrayList<>();
            for (School school : resultSchools) {
                if (school.getLocation() != null && school.getLocation().contains(location)) {
                    schoolsWithLocation.add(school);
                }
            }
            // 更新结果为交集
            resultSchools = schoolsWithLocation;
        }

        // 根据学校名称筛选（在现有结果中继续筛选）
        if (schoolName != null && !schoolName.trim().isEmpty() && !resultSchools.isEmpty()) {
            List<School> schoolsWithName = new ArrayList<>();
            for (School school : resultSchools) {
                if (school.getSchoolName() != null && school.getSchoolName().contains(schoolName)) {
                    schoolsWithName.add(school);
                }
            }
            // 更新结果为交集
            resultSchools = schoolsWithName;
        }

        // 如果没有找到任何学校，返回空列表和适当的消息
        if (resultSchools.isEmpty()) {
            Map<String, Object> response = new HashMap<>();
            response.put("schools", resultSchools);
            response.put("message", "没有找到符合所有条件的学校");
            return ResponseEntity.ok(response);
        }

        return ResponseEntity.ok(resultSchools);
    }

    @GetMapping("/applications")
    public List<Application> getStudentApplications(@RequestHeader("Authorization") String token) {
        // 解析Token获取学生ID
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 获取学生的申请记录
        return applicationService.findByStudentId(studentId.toString());
    }

    @GetMapping("/info")
    public ResponseEntity<?> getStudentInfo(@RequestHeader("Authorization") String token) {
        // 解析Token获取学生ID
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 获取学生信息
        Student student = studentService.findByStudentId(studentId);
        if (student == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(student);
    }

    @PutMapping("/info")
    public ResponseEntity<?> setStudentInfo(@RequestHeader("Authorization") String token, @RequestBody Student updatestudent) {
        // 解析Token获取学生ID
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 更新学生信息
        Student student = studentService.findByStudentId(studentId);
        student.setCurrentschool(updatestudent.getCurrentschool());
        student.setName(updatestudent.getName());
        student.setBirthDate(updatestudent.getBirthDate());
        student.setContactPhone(updatestudent.getContactPhone());
        student.setContactEmail(updatestudent.getContactEmail());
        student.setAddress(updatestudent.getAddress());
        studentService.save(student);
        return ResponseEntity.ok(student);
    }

    @PostMapping("/avatar")
    public ResponseEntity<?> uploadAvatar(@RequestParam("file") MultipartFile file, @RequestHeader("Authorization") String token) {
        String studentId = jwtUtil.getLoginIdFromToken(token);
        try {
            // 创建存储目录
            Path uploadPath = Paths.get("avatars");
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // 保存文件
            String filename = studentId + "." +
                    file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
            Path filePath = uploadPath.resolve(filename);

            // 覆盖已存在的文件
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);


            // 更新数据库
            Student student = studentService.findByStudentId(studentId);
            student.setAvatar(filePath.toString());
            studentService.save(student);

            Map<String, String> responseMap = new HashMap<>();
            responseMap.put("avatarUrl", filePath.toString());
            return ResponseEntity.ok(responseMap);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("文件上传失败");
        }
    }


    @PostMapping("/schools/recommend")
    public ResponseEntity<?> recommendSchools(@RequestBody RecommendationRequest request, @RequestHeader("Authorization") String token) {
        // 解析Token获取学生ID和角色
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 获取学生输入的信息
        Double studentGpa = request.getGpa();
        String studentGrades = request.getGrades();
        String studentMajor = request.getMajor();
        String currentSchool = request.getCurrentSchool();

        // 验证输入
        if (studentGpa == null || studentGrades == null || studentGrades.trim().isEmpty() ||
                studentMajor == null || studentMajor.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("请提供完整的成绩、绩点和专业信息");
        }

        // 获取所有学校
        List<School> allSchools = schoolService.findAll();
        List<School> recommendedSchools = new ArrayList<>();
        Map<School, Integer> schoolMatchScores = new HashMap<>(); // 用于存储学校匹配分数

        // 分析每个学校的申请要求并进行匹配
        for (School school : allSchools) {
            String applyRequest = school.getApplyrequest();
            List<String> majors = school.getMajors();

            // 跳过没有申请要求或专业列表的学校
            if (applyRequest == null || majors == null || majors.isEmpty()) {
                continue;
            }

            // 计算匹配分数
            int matchScore = calculateMatchScore(school, studentGpa, studentGrades, studentMajor, majors);

            // 如果匹配分数大于0，则添加到推荐列表
            if (matchScore > 0) {
                recommendedSchools.add(school);
                schoolMatchScores.put(school, matchScore);
            }
        }

        // 根据匹配分数对学校进行排序（从高到低）
        recommendedSchools.sort((s1, s2) -> schoolMatchScores.get(s2).compareTo(schoolMatchScores.get(s1)));

        // 如果没有找到匹配的学校，返回适当的消息
        if (recommendedSchools.isEmpty()) {
            Map<String, Object> response = new HashMap<>();
            response.put("schools", recommendedSchools);
            response.put("message", "没有找到符合您条件的学校，请调整您的条件");
            return ResponseEntity.ok(response);
        }

        // 返回推荐结果
        Map<String, Object> response = new HashMap<>();
        response.put("schools", recommendedSchools);
        response.put("message", "为您找到" + recommendedSchools.size() + "所符合条件的学校");
        return ResponseEntity.ok(response);
    }

    // 计算学生与学校的匹配分数
    private int calculateMatchScore(School school, Double studentGpa, String studentGrades,
                                    String studentMajor, List<String> schoolMajors) {
        int score = 0;
        String applyRequest = school.getApplyrequest().toLowerCase();

        // 解析申请要求中的GPA要求
        double requiredGpa = 0.0;
        if (applyRequest.contains("gpa above")) {
            String[] parts = applyRequest.split("gpa above");
            if (parts.length > 1) {
                String gpaStr = parts[1].trim().split("[\\ ,]|\\.\\s")[0];
                try {
                    requiredGpa = Double.parseDouble(gpaStr);
                } catch (NumberFormatException e) {
                    // 解析失败，使用默认值
                }
            }
        }

        // 解析申请要求中的平均分要求
        int requiredGrades = 0;
        if (applyRequest.contains("average score above")) {
            String[] parts = applyRequest.split("average score above");
            if (parts.length > 1) {
                String gradesStr = parts[1].trim().split("[\\ ,]|\\.\\s")[0];
                try {
                    requiredGrades = Integer.parseInt(gradesStr);
                } catch (NumberFormatException e) {
                    // 解析失败，使用默认值
                }
            }
        }

        // 检查GPA是否符合要求
        if (studentGpa >= requiredGpa) {
            score += 40; // GPA符合要求，加40分
        } else if (studentGpa >= requiredGpa - 0.2) {
            score += 20; // GPA接近要求，加20分
        }

        // 检查平均分是否符合要求
        try {
            int studentAvgGrade = Integer.parseInt(studentGrades);
            if (studentAvgGrade >= requiredGrades) {
                score += 40; // 平均分符合要求，加40分
            } else if (studentAvgGrade >= requiredGrades - 5) {
                score += 20; // 平均分接近要求，加20分
            }
        } catch (NumberFormatException e) {
            // 学生平均分格式不正确，不加分
        }

        // 检查专业匹配度
        boolean majorMatch = false;
        for (String schoolMajor : schoolMajors) {
            if (schoolMajor.toLowerCase().contains(studentMajor.toLowerCase())) {
                majorMatch = true;
                break;
            }
        }

        if (majorMatch) {
            score += 20; // 专业匹配，加20分
        }

        return score;
    }
}