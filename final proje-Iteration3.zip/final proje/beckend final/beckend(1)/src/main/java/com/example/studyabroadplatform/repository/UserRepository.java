package com.example.studyabroadplatform.repository;

import com.example.studyabroadplatform.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    boolean existsByLoginIdAndRole(String loginId, String role);
    Optional<User> findByLoginId(String loginId);
    
    // 新增删除方法
    void deleteByLoginId(String loginId);
}