package com.example.studyabroadplatform.controller;
import com.example.studyabroadplatform.model.Student;
import com.example.studyabroadplatform.model.School;
import com.example.studyabroadplatform.repository.UserRepository;
import com.example.studyabroadplatform.service.DatabaseBackupService;
import com.example.studyabroadplatform.service.StudentService;
import com.example.studyabroadplatform.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired
    private StudentService studentService;

    @Autowired
    public SchoolService schoolService;

    @Autowired
    private UserRepository UserRepository;
    
    @Autowired
    private DatabaseBackupService databaseBackupService;


    // 学生管理
    @GetMapping("/students")
    public List<Student> getAllStudents() {
        return studentService.findAll();
    }

    @GetMapping("/students/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        Student student = studentService.findById(id);
        return student != null ? ResponseEntity.ok(student) : ResponseEntity.notFound().build();
    }

    @PostMapping("/students")
    public Student createStudent(@RequestBody Student student) {
        return studentService.save(student);
    }

    @PutMapping("/students/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student student) {
        student.setId(id);
        return ResponseEntity.ok(studentService.save(student));

    }

    @DeleteMapping("/students/{id}")
    @Transactional
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        Student student = studentService.findById(id);
        studentService.deleteById(id);
        UserRepository.deleteByLoginId(student.getStudentId());
        return ResponseEntity.noContent().build();
    }

    // 校方管理
    @GetMapping("/schools")
    public List<School> getAllSchools() {
        return schoolService.findAll();
    }

    @GetMapping("/schools/{id}")
    public ResponseEntity<School> getSchoolById(@PathVariable Long id) {
        School school = schoolService.findById(id);
        return school != null ? ResponseEntity.ok(school) : ResponseEntity.notFound().build();
    }

    @PostMapping("/schools")
    public School createSchool(@RequestBody School school) {
        return schoolService.save(school);
    }

    @PutMapping("/schools/{id}")
    public ResponseEntity<School> updateSchool(@PathVariable Long id, @RequestBody School school) {
        school.setId(id);
        return ResponseEntity.ok(schoolService.save(school));
    }

    @DeleteMapping("/schools/{id}")
    @Transactional
    public ResponseEntity<Void> deleteSchool(@PathVariable Long id) {
        School school =schoolService.findById(id);
        schoolService.deleteById(id);
        UserRepository.deleteByLoginId(school.getSchoolId());
        return ResponseEntity.noContent().build();
    }
    
    // 数据库备份和恢复接口
    
    /**
     * 手动触发数据库备份
     * @param backupName 备份名称（可选）
     * @return 备份结果
     */
    @PostMapping("/database/backup")
    public ResponseEntity<?> backupDatabase(@RequestParam(required = false) String backupName) {
        try {
            String backupPath = databaseBackupService.backupDatabase(backupName);
            Map<String, String> response = new HashMap<>();
            response.put("message", "数据库备份成功");
            response.put("backupPath", backupPath);
            return ResponseEntity.ok(response);
        } catch (IOException e) {
            return ResponseEntity.status(500).body("数据库备份失败: " + e.getMessage());
        }
    }

    @PostMapping("/database/restore")
    public ResponseEntity<?> restoreDatabase(@RequestBody Map<String, String> requestBody) {
        try {
            String backupPath = requestBody.get("backupPath");
            if (backupPath == null || backupPath.isEmpty()) {
                return ResponseEntity.badRequest().body("备份路径不能为空");
            }

            databaseBackupService.restoreDatabase(backupPath);
            Map<String, String> response = new HashMap<>();
            response.put("message", "数据库恢复成功");
            return ResponseEntity.ok(response);
        } catch (IOException e) {
            return ResponseEntity.status(500).body("数据库恢复失败: " + e.getMessage());
        }
    }
    
    /**
     * 获取所有备份文件列表
     * @return 备份文件列表
     */
    @GetMapping("/database/backups")
    public ResponseEntity<?> getAllBackups() {
        try {
            List<String> backups = databaseBackupService.getAllBackups();
            return ResponseEntity.ok(backups);
        } catch (IOException e) {
            return ResponseEntity.status(500).body("获取备份列表失败: " + e.getMessage());
        }
    }
}
