package com.example.studyabroadplatform.controller;
import com.example.studyabroadplatform.model.Application;
import com.example.studyabroadplatform.model.School;
import com.example.studyabroadplatform.model.Student;
import com.example.studyabroadplatform.service.ApplicationService;
import com.example.studyabroadplatform.service.SchoolService;
import com.example.studyabroadplatform.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource; 
import org.springframework.core.io.UrlResource; 
import org.springframework.http.HttpHeaders; 
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.ArrayList; 
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/school")
public class SchoolController {
    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private SchoolService schoolService;

    @Autowired
    private JwtUtil jwtUtil;

    @GetMapping("/applications")
    public List<Application> getApplications(@RequestHeader("Authorization") String token) {
        // 解析Token获取学校ID
        // 由于 getUserIdFromToken 方法是非静态的，需要使用注入的 jwtUtil 实例来调用
        String schoolId = jwtUtil.getLoginIdFromToken(token);
        return applicationService.findBySchoolId(schoolId.toString());
    }

    @GetMapping("/info")
    public ResponseEntity<?> getSchoolInfo(@RequestHeader("Authorization") String token) {
        // 解析Token获取学校ID
        String schoolId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"SCHOOL".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 获取学校信息
        School school = schoolService.findBySchoolId(schoolId);
        if (school == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(school);
    }

    @PutMapping ("/info")
    public ResponseEntity<?> setSchoolInfo(@RequestHeader("Authorization") String token,@RequestBody School updateschool) {
        // 解析Token获取学校ID
        String schoolId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"SCHOOL".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 更新学校信息
        School school = schoolService.findBySchoolId(schoolId);
        school.setSchoolName(updateschool.getSchoolName());
        school.setLocation(updateschool.getLocation());
        school.setContactPhone(updateschool.getContactPhone());
        school.setContactEmail(updateschool.getContactEmail());
        school.setWebsite(updateschool.getWebsite());
        school.setDescription(updateschool.getDescription());
        school.setApplyrequest(updateschool.getApplyrequest());
        school.setMajors(updateschool.getMajors());
        schoolService.save(school);

        return ResponseEntity.ok(school);
    }

    @PostMapping("/avatar")
    public ResponseEntity<?> uploadAvatar(@RequestParam("file") MultipartFile file, @RequestHeader("Authorization") String token) {
        String schoolId = jwtUtil.getLoginIdFromToken(token);
        try {
            // 创建存储目录
            Path uploadPath = Paths.get("avatars");
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // 保存文件
            String filename = schoolId + "." +
                    file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
            Path filePath = uploadPath.resolve(filename);

            // 覆盖已存在的文件
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            // 更新数据库
            School school = schoolService.findBySchoolId(schoolId);
            school.setAvatar(filePath.toString());
            schoolService.save(school);

            Map<String, String> responseMap = new HashMap<>();
            responseMap.put("avatarUrl", filePath.toString());
            return ResponseEntity.ok(responseMap);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("文件上传失败");
        }
    }

    @PutMapping("/applications/{id}/approve")
    public Application approveApplication(@PathVariable Long id, @RequestHeader("Authorization") String token) {
        // 解析Token获取学校ID
        String schoolId = jwtUtil.getLoginIdFromToken(token);

        // 获取申请信息
        Application application = applicationService.findById(id);

        // 验证申请是否属于该学校
        if (!application.getSchool().getSchoolId().equals(schoolId.toString())) {
            throw new RuntimeException("无权限批准该申请");
        }

        application.setStatus("APPROVED");
        application.setProcessedDate(LocalDate.now());
        return applicationService.saveApplication(application);
    }

    @PutMapping("/applications/{id}/reject")
    public Application rejectApplication(@PathVariable Long id, @RequestHeader("Authorization") String token) {
        // 解析Token获取学校ID
        String schoolId = jwtUtil.getLoginIdFromToken(token);

        // 获取申请信息
        Application application = applicationService.findById(id);

        // 验证申请是否属于该学校
        if (!application.getSchool().getSchoolId().equals(schoolId.toString())) {
            throw new RuntimeException("无权限拒绝该申请");
        }

        application.setStatus("REJECTED");
        application.setProcessedDate(LocalDate.now());
        return applicationService.saveApplication(application);
    }

    // 新增方法：获取指定申请的附件列表
    @GetMapping("/applications/{id}/files")
    public ResponseEntity<?> getApplicationFiles(@PathVariable Long id, @RequestHeader("Authorization") String token) {
        // 解析Token获取学校ID并验证角色
        String schoolIdFromToken = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        if (!"SCHOOL".equals(role)) {
            return ResponseEntity.status(403).body("无权限访问");
        }

        // 获取申请信息
        Application application = applicationService.findById(id);
        if (application == null) {
            return ResponseEntity.notFound().build();
        }

        // 验证申请是否属于该学校
        if (!application.getSchool().getSchoolId().equals(schoolIdFromToken)) {
            return ResponseEntity.status(403).body("无权限查看该申请的文件");
        }

        List<String> applicationFiles = application.getApplicationFiles();
        if (applicationFiles == null) {
            applicationFiles = new ArrayList<>(); 
        }
        
        

        return ResponseEntity.ok(applicationFiles); 
    }

    // 新增方法：下载指定文件名的附件
    @GetMapping("/applications/files/{filename:.+}")
    public ResponseEntity<Resource> downloadApplicationFile(@PathVariable String filename, @RequestHeader("Authorization") String token) {
        // 验证学校用户权限
        String role = jwtUtil.getRoleFromToken(token);
        if (!"SCHOOL".equals(role)) {
            return ResponseEntity.status(403).body(null); 
        }

        try {
            Path fileStorageLocation = Paths.get("application_files").toAbsolutePath().normalize();
            Path filePath = fileStorageLocation.resolve(filename).normalize();
            
            Resource resource = new UrlResource(filePath.toUri());

            if (resource.exists() && resource.isReadable()) {
                // 获取文件的 MIME 类型
                String mimeType = Files.probeContentType(filePath);
                if (mimeType == null) {
                    mimeType = "application/octet-stream"; // 默认 MIME 类型
                }

                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                        .header(HttpHeaders.CONTENT_TYPE, mimeType)
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            
            return ResponseEntity.status(500).body(null); 
        }
    }
}