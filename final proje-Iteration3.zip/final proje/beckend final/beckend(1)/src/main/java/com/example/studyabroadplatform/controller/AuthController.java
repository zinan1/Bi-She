package com.example.studyabroadplatform.controller;
import com.example.studyabroadplatform.model.*;
import com.example.studyabroadplatform.repository.SchoolRepository;
import com.example.studyabroadplatform.repository.StudentRepository;
import com.example.studyabroadplatform.repository.UserRepository;

import java.util.*;

import com.example.studyabroadplatform.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserRepository UserRepository;

    @Autowired
    private StudentRepository StudentRepository;

    @Autowired
    private SchoolRepository SchoolRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        // 登录验证
        User user = UserRepository.findByLoginId(request.getLoginId())
                .orElseThrow(() -> new RuntimeException("用户不存在"));

        if (!user.getPassword().equals(request.getPassword())) {
            return ResponseEntity.status(401).body("密码错误");
        }
        if(!user.getRole().equalsIgnoreCase(request.getRole())){
            return ResponseEntity.status(403).body("角色不匹配");
        }

        // 生成JWT Token时传入loginId
        String token = jwtUtil.generateToken(user.getLoginId(), user.getRole());

        // 返回包含用户角色信息和Token的响应
        Map<String, Object> response = new HashMap<>();
        response.put("user", user);
        response.put("role", user.getRole());
        response.put("token", token);
//        // 根据角色重定向
//        String redirectUrl;
//        switch (user.getRole()) {
//            case "STUDENT":
//                redirectUrl = "/student/dashboard";
//                break;
//            case "SCHOOL":
//                redirectUrl = "/school/dashboard";
//                break;
//            default:
//                redirectUrl = "/";
//                break;
//        }
//
//        // 返回包含重定向URL的响应
//        response.put("redirectUrl", redirectUrl);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody LoginRequest request) {
        String role = request.getRole().toUpperCase();

        // 检查用户是否已存在
        if (UserRepository.existsByLoginIdAndRole(request.getLoginId(), role)) {
            return ResponseEntity.status(400).body("用户已存在");
        }

        // 创建新用户
        User newUser = new User();
        newUser.setLoginId(request.getLoginId());
        newUser.setPassword(request.getPassword());
        newUser.setRole(role);
        UserRepository.save(newUser);

        // 根据角色创建对应实体
        switch(role) {
            case "STUDENT":
                Student student = new Student();
                student.setStudentId(newUser.getLoginId());
                student.setCurrentschool(request.getCurrentschool());
                student.setName(request.getName());
                student.setGender(request.getGender());
                student.setBirthDate(request.getBirthDate());
                student.setContactPhone(request.getContactPhone());
                student.setContactEmail(request.getContactEmail());
                student.setAddress(request.getAddress());
                StudentRepository.save(student);
                break;
            case "SCHOOL":
                School school = new School();
                school.setSchoolId(newUser.getLoginId());
                school.setSchoolName(request.getSchoolName());
                school.setLocation(request.getLocation());
                school.setDescription(request.getDescription());
                school.setContactPhone(request.getContactPhone());
                school.setContactEmail(request.getContactEmail());
                school.setWebsite(request.getWebsite());
                school.setApplyrequest(request.getApplyrequest());
                school.setAvatar("/avatars/default_school.png");
                school.setMajors(request.getMajors());
                SchoolRepository.save(school);
                break;
            case "ADMIN":
                // 管理员无需额外处理，因为管理员在注册时已经创建了用户和角色
                break;
        }
        return ResponseEntity.ok("注册成功");
    }

    @PostMapping("/resetPassword")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) {
        String loginId = request.get("loginId");
        String role = request.get("role").toUpperCase();
        String newPassword = request.get("newPassword");
        String confirmPassword = request.get("confirmPassword");

        // 验证用户是否存在
        User user = UserRepository.findByLoginId(loginId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));

        if (!user.getRole().equals(role)) {
            return ResponseEntity.status(400).body("角色不匹配");
        }

        // 更新密码
        user.setPassword(newPassword);

        // 验证两次输入的密码是否一致
        if (!newPassword.equals(confirmPassword)) {
            return ResponseEntity.status(400).body("两次输入的密码不一致");
        }

        UserRepository.save(user);
        return ResponseEntity.ok("密码重置成功");
    }
}
