package com.example.studyabroadplatform.model;
import javax.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.example.studyabroadplatform.converter.StringListConverter;
import java.util.List;

@Entity
@Table(name = "applications")
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "student_id", referencedColumnName = "student_id", insertable = true, updatable = false)
    private Student student;

    @Column(name ="currentschool")
    private String currentschool;

    @ManyToOne
    @JoinColumn(name = "school_id", referencedColumnName = "school_id", insertable = true, updatable = false)
    private School school;

    @Column(name ="major")
    private String major;

    @Column
    private Double gpa; // 绩点

    @Column
    private String grades; // 成绩

    @Column(name ="enrolled")
    private String enrolled; // 是否在读
    
    @Column
    private String status; // PENDING, APPROVED, REJECTED
    
    @Column
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate applicationDate;

    @Column
    @JsonFormat(pattern = "yyyy-MM-dd")
    private  LocalDate processedDate;

    @Column(name = "application_files", columnDefinition = "TEXT")
    @Convert(converter = StringListConverter.class)
    private List<String> applicationFiles; // 存储申请文件路径列表
    
    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String getCurrentschool() {
        return currentschool;
    }

    public void setCurrentschool(String currentschool) {
        this.currentschool = currentschool;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public Double getGpa() {
        return gpa;
    }

    public void setGpa(Double gpa) {
        this.gpa = gpa;
    }

    public String getGrades() {
        return grades;
    }

    public void setGrades(String grades) {
        this.grades = grades;
    }

    public String getEnrolled() {
        return enrolled;
    }

    public void setEnrolled(String enrolled) {
        this.enrolled = enrolled;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(LocalDate applicationDate) {
        this.applicationDate = applicationDate;
    }

    public LocalDate getProcessedDate() {
        return processedDate;
    }

    public void setProcessedDate(LocalDate processedDate) {
        this.processedDate = processedDate;
    }

    public List<String> getApplicationFiles() {
        return applicationFiles;
    }

    public void setApplicationFiles(List<String> applicationFiles) {
        this.applicationFiles = applicationFiles;
    }
}