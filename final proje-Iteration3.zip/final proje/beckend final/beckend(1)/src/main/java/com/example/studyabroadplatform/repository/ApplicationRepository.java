package com.example.studyabroadplatform.repository;

import com.example.studyabroadplatform.model.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    boolean existsByStudentStudentIdAndSchoolSchoolIdAndMajorAndStatus(
            String studentId,
            String schoolId,
            String major,
            String status
    );

    List<Application> findBySchoolSchoolId(String schoolId);

    List<Application> findByStudentStudentId(String studentId);
}