package com.example.studyabroadplatform.model;

public class RecommendationRequest {
    private Double gpa;
    private String grades; // 平均分
    private String major; // 专业
    private String currentSchool; // 当前就读大学

    // Getters and Setters
    public Double getGpa() {
        return gpa;
    }

    public void setGpa(Double gpa) {
        this.gpa = gpa;
    }

    public String getGrades() {
        return grades;
    }

    public void setGrades(String grades) {
        this.grades = grades;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getCurrentSchool() {
        return currentSchool;
    }

    public void setCurrentSchool(String currentSchool) {
        this.currentSchool = currentSchool;
    }
}