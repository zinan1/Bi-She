package com.example.studyabroadplatform.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Converter
public class StringListConverter implements AttributeConverter<List<String>, String> {

    private final ObjectMapper objectMapper = new ObjectMapper();// 创建一个Jackson的ObjectMapper实例。ObjectMapper用于将Java对象序列化为JSON字符串，以及将JSON字符串反序列化为Java对象。

    @Override
    public String convertToDatabaseColumn(List<String> attribute) { // 将List<String>类型的属性转换为数据库列的字符串表示形式。
        if (attribute == null || attribute.isEmpty()) {
            return "[]";  // 如果属性为空或为null，返回一个空的JSON数组字符串"[]",这样做是为了在数据库中保持一致的JSON格式。
        }
        try {
            return objectMapper.writeValueAsString(attribute);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error converting list to JSON", e);
        }
    }

    @Override
    public List<String> convertToEntityAttribute(String dbData) { // 将数据库列的字符串表示形式转换为List<String>类型的属性。
        if (dbData == null || dbData.isEmpty()) {
            return new ArrayList<>();  // 如果数据库列的值为空或为null，返回一个空的ArrayList。
        }
        try {
            return objectMapper.readValue(dbData, objectMapper.getTypeFactory().constructCollectionType(List.class, String.class));
            // 调用ObjectMapper的readValue方法，将数据库列的字符串表示形式（JSON格式）解析为List<String>类型的属性。
        } catch (IOException e) {
            throw new IllegalArgumentException("Error converting JSON to list", e);
        }
    }
}