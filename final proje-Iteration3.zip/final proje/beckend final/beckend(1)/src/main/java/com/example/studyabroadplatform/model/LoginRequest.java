package com.example.studyabroadplatform.model;

import java.time.LocalDate;
import java.util.List;


public class LoginRequest {
    private String loginId;
    private String password;
    private String role;
    private String name;
    private String currentschool;
    private Student.Gender gender;
    private LocalDate birthDate;
    private String contactPhone;
    private String contactEmail;
    private String address;
    private String schoolName;
    private String location;
    private String description;
    private String website;
    private List<String> majors;
    private String applyrequest;

    private boolean isAdmin;

    // Getters and Setters
    public String getLoginId() {
        return loginId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrentschool() {
        return currentschool;
    }

    public void setCurrentschool(String currentschool) {
        this.currentschool = currentschool;
    }

    public Student.Gender getGender() {
        return gender;
    }

    public void setGender(Student.Gender gender) {
        this.gender = gender;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public java.util.List<String> getMajors() {
        return majors;
    }

    public void setMajors(java.util.List<String> majors) {
        this.majors = majors;
    }

    public String getApplyrequest() {
        return applyrequest;
    }

    public void setApplyrequest(String applyrequest) {
        this.applyrequest = applyrequest;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}