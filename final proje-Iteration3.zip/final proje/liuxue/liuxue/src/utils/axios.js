import axios from 'axios';
import { ElMessage } from "element-plus";

const service = axios.create({
    baseURL: 'http://localhost:8082',
    timeout: 50000
});

// Request interceptor
service.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token') || '';
        if (token) {
            config.headers['Authorization'] = token;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor
service.interceptors.response.use(
    response => {
        if(!response.status === 200){
            ElMessage.error('Response error')
        }else {
            return response;
        }
    },
    error => {
        ElMessage.error(error.message);
        return Promise.reject(error);
    }
);

export default service;