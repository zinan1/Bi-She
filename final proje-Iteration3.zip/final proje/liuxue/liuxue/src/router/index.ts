import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import Home from '../views/Home.vue'
import adminRoutes from './adminRoutes'
import studentRoutes from "@/router/studentRoutes";
import schoolRoutes from "@/router/schoolRoutes";

const routes: Array<RouteRecordRaw> = [
    ...studentRoutes,
    ...adminRoutes,
    ...schoolRoutes,
    {
    path: '/',
    name: 'Home',
    component: Home
    },
    {
        path:'/login',
        name:'Login',
        component:()=>import('@/components/LoginDialog.vue')
    },
    {
        path:'/resetPassword',
        name:'Reset Password',
        component:()=>import('@/components/ResetPasswordDialog.vue')
    },
    {
        path:'/resourceCenter',
        name:'Resource Center',
        component:()=>import('@/views/resourceCenter.vue')
    }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})
export default router
