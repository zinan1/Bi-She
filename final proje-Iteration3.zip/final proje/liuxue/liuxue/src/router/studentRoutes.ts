import type { RouteRecordRaw } from 'vue-router';

const studentRoutes: Array<RouteRecordRaw> = [
    {
        path: '/studentPage',
        name:'Student',
        redirect:'/studentPage/studentInfo',
        component: () => import('../views/studentPage/student.vue'),
        children:[
            {
                path:'/studentPage/studentInfo',
                name:'Student Home',
                component:()=>import('../views/studentPage/studentInfo.vue')
            },
            {
                path:'/studentPage/ViewAllSchool',
                name:'View All School',
                component:()=>import('../views/studentPage/ViewAllSchool.vue')
            },
            {
                path:'/studentPage/viewApplication',
                name:'Application Details',
                component:()=>import('../views/studentPage/viewApplication.vue')
            },
            {
                path: '/studentPage/studentResetPassword',
                name: 'Change Password',
                component: () => import('../views/studentPage/studentResetPassword.vue')
            },
            {
                path: '/studentPage/helpInfo',
                name: 'Help Information',
                component: () => import('../views/studentPage/helpInfo.vue')
            },
            {
                path: '/studentPage/IntelligentServices',
                name: 'Intelligent Services',
                component:() => import('../views/studentPage/IntelligentServices.vue')
            }
        ]
    }
];
export default studentRoutes;