
import type { RouteRecordRaw } from 'vue-router';

const adminRoutes: Array<RouteRecordRaw> = [
    {
        path: '/adminPage',
        name:'Admin',
        component: () => import('../views/adminPage/admin.vue'),
        redirect: '/adminPage/studentManagement',
        children:[
            {
                path:'/adminPage/studentManagement',
                name:'Student Management',
                component:()=>import('../views/adminPage/studentManagement.vue')
            },
            {
                path:'/adminPage/schoolManagement',
                name:'School Management',
                component:()=>import('../views/adminPage/schoolManagement.vue')
            }
        ]
    }
];
export default adminRoutes;