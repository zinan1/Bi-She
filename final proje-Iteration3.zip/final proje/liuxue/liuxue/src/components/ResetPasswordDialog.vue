<template>
  <div class="login-container">
    <el-card class="login-card">
      <h2 class="login-title">Password Reset</h2>
      <el-form
          ref="loginFormRef"
          :model="loginForm"
          :rules="formRules"
          label-position="top"
          @submit.prevent="submitForm"
      >
        <el-form-item label="Username" prop="loginId">
          <el-input
              v-model="loginForm.loginId"
              placeholder="Enter your username"
              prefix-icon="User"
              clearable
          />
        </el-form-item>
        <el-form-item label="Identity" prop="role">
          <el-select
              v-model="loginForm.role"
              placeholder="Select your identity"
              style="width: 100%"
          >
            <el-option label="Student" value="STUDENT" />
            <el-option label="School" value="SCHOOL" />
          </el-select>
        </el-form-item>

        <el-form-item label="New Password" prop="newPassword">
          <el-input
              v-model="loginForm.newPassword"
              type="password"
              placeholder="Enter new password"
              autocomplete="new-password"
              prefix-icon="Lock"
              show-password
              clearable
          />
          <div class="password-hint">
            Password must be 6-20 characters, containing letters and numbers
          </div>
        </el-form-item>
        <el-form-item label="Confirm Password" prop="confirmPassword">
          <el-input
              v-model="loginForm.confirmPassword"
              type="password"
              placeholder="Confirm your new password"
              autocomplete="new-password"
              prefix-icon="Lock"
              show-password
              clearable
          />
        </el-form-item>
        <el-form-item>
          <el-button
              type="primary"
              native-type="submit"
              :loading="submitting"
              class="submit-btn"
          >
            Reset Password
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>
<script setup>
import { reactive, ref } from 'vue'
import { ResetPassword } from "@/api/loginApi"
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const router = useRouter()
const loginFormRef = ref(null)
const submitting = ref(false)

const loginForm = reactive({
  loginId: '',
  role: '',
  newPassword: '',
  confirmPassword: ''
})

// Password rules
const validatePassword = (rule, value, callback) => {
  if (!value) {
    callback(new Error('Please input password'))
  } else if (value.length < 6 || value.length > 20) {
    callback(new Error('Password length should be 6-20 characters'))
  } else if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) {
    callback(new Error('Password must contain both letters and numbers'))
  } else {
    callback()
  }
}

// Confirm password validation
const validateConfirmPassword = (rule, value, callback) => {
  if (!value) {
    callback(new Error('Please confirm your password'))
  } else if (value !== loginForm.newPassword) {
    callback(new Error('Two passwords do not match!'))
  } else {
    callback()
  }
}

const formRules = reactive({
  loginId: [
    { required: true, message: 'Please input username', trigger: 'blur' },
    { min: 3, max: 16, message: 'Length should be 4-16 characters', trigger: 'blur' }
  ],
  role: [
    { required: true, message: 'Please select identity', trigger: 'change' }
  ],
  newPassword: [
    { required: true, validator: validatePassword, trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, validator: validateConfirmPassword, trigger: 'blur' }
  ]
})

const submitForm = async () => {
  try {
    const valid = await loginFormRef.value.validate()
    if (!valid) return

    submitting.value = true

    const response = await ResetPassword(loginForm)

    ElMessage.success(response.message || 'Password reset successfully')
    await router.push('/login')
  } catch (error) {
    ElMessage.error(error.response?.data?.message || error.message || 'Password reset failed')
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 97vh;
}

.login-card {
  width: 100%;
  max-width: 450px;
  padding: 30px;
  border-radius: 8px;
  border: 1px solid #ebeef5;
}

.login-title {
  margin-bottom: 24px;
  text-align: center;
  color: #303133;
}

.submit-btn {
  width: 100%;
  margin-top: 10px;
}

.password-hint {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

:deep(.el-form-item__label) {
  font-weight: 500;
}
</style>