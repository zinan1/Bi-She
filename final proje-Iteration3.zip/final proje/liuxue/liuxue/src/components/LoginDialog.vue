<template>
  <div class="login-container">
    <div class="login-box" :class="{'shake': loginError}">
      <div class="login-header">
        <h2>Welcome Back</h2>
        <p>Please login to your account</p>
      </div>

      <el-form
          :model="loginForm"
          ref="loginFormRef"
          class="login-form"
          @keyup.enter="handleLogin"
      >
        <el-form-item class="form-group" prop="username">
          <el-input
              v-model="loginForm.loginId"
              placeholder="Username"
              prefix-icon="User"
              @focus="inputFocus('username')"
              @blur="inputBlur"
          />
        </el-form-item>

        <el-form-item class="form-group" prop="password">
          <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="Password"
              prefix-icon="Lock"
              show-password
              @focus="inputFocus('password')"
              @blur="inputBlur"
          />
        </el-form-item>

        <el-form-item class="form-group" prop="role" required>
          <el-select
              v-model="loginForm.role"
              placeholder="Select Identity"
              @focus="inputFocus('role')"
              @blur="inputBlur"
          >
            <el-option label="STUDENT" value="STUDENT" />
            <el-option label="SCHOOL" value="SCHOOL" />
            <el-option label="ADMIN" value="ADMIN" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button
              type="primary"
              @click="handleLogin"
              class="login-btn"
              :loading="loading"
          >
            <span v-if="!loading">Login</span>
            <span v-else>Logging in...</span>
          </el-button>
        </el-form-item>
      </el-form>

      <div class="switch-auth">
        <router-link to="/resetPassword">
          <el-button class="auth-link" @mouseenter="hoverEffect('reset')">Password Reset</el-button>
        </router-link>
        <el-button class="auth-link" @click="studentRegisterForm" @mouseenter="hoverEffect('student')">Student Register</el-button>
        <el-button class="auth-link" @click="schoolRegisterForm" @mouseenter="hoverEffect('school')">School Register</el-button>
      </div>

      <!-- Floating decoration elements -->
      <div class="floating-elements">
        <div class="circle circle-1"></div>
        <div class="circle circle-2"></div>
        <div class="circle circle-3"></div>
      </div>
    </div>

    <!-- Student Dialog -->
    <el-dialog
        v-model="dialogVisible"
        width="50%"
        :show-close="false"
        :close-on-click-modal="false"
        custom-class="animated-dialog"
    >
      <template #header>
        <div class="dialog-header">
          <h3>Student Registration</h3>
        </div>
      </template>
      <el-form
          :model="studentForm"
          ref="studentFormRef"
          label-width="120px"
          class="animated-form"
      >
        <el-form-item label="Username" prop="loginId" required>
          <el-input v-model="studentForm.loginId" />
        </el-form-item>
        <el-form-item label="Password" prop="password" required>
          <el-input v-model="studentForm.password" type="password" show-password />
        </el-form-item>
        <el-form-item label="Name" prop="name" required>
          <el-input v-model="studentForm.name" />
        </el-form-item>
        <el-form-item label="Gender" prop="gender" required>
          <el-select v-model="studentForm.gender" placeholder="Select gender">
            <el-option label="MALE" value="MALE" />
            <el-option label="FEMALE" value="FEMALE" />
            <el-option label="OTHER" value="OTHER" />
          </el-select>
        </el-form-item>
        <el-form-item label="Birth Date" prop="birthDate">
          <el-date-picker
              v-model="studentForm.birthDate"
              type="date"
              placeholder="Select birth date"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="Contact Phone" prop="contactPhone">
          <el-input v-model="studentForm.contactPhone" />
        </el-form-item>
        <el-form-item label="Contact Email" prop="contactEmail">
          <el-input v-model="studentForm.contactEmail" />
        </el-form-item>
        <el-form-item label="Address" prop="address">
          <el-input v-model="studentForm.address" type="textarea" />
        </el-form-item>
        <el-form-item label="Current School" prop="currentschool">
          <el-input v-model="studentForm.currentschool" type="textarea" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false" class="cancel-btn">Cancel</el-button>
        <el-button type="primary" @click="submitStudentForm" class="confirm-btn">Confirm</el-button>
      </template>
    </el-dialog>

    <!-- School Dialog -->
    <el-dialog
        v-model="schoolDialog"
        width="50%"
        :show-close="false"
        :close-on-click-modal="false"
        custom-class="animated-dialog"
    >
      <template #header>
        <div class="dialog-header">
          <h3>School Registration</h3>
        </div>
      </template>
      <el-form
          ref="schoolForm"
          :model="school"
          label-width="120px"
          label-position="right"
          class="animated-form"
      >
        <el-form-item label="Username" prop="loginId" required>
          <el-input v-model="school.loginId" />
        </el-form-item>
        <el-form-item label="Password" prop="password" required>
          <el-input v-model="school.password" type="password" show-password />
        </el-form-item>

        <el-form-item label="School Name" prop="schoolName">
          <el-input v-model="school.schoolName" />
        </el-form-item>

        <el-form-item label="Location" prop="location">
          <el-input v-model="school.location" />
        </el-form-item>

        <el-form-item label="Description" prop="description">
          <el-input
              v-model="school.description"
              type="textarea"
              :rows="2"
          />
        </el-form-item>
        <el-form-item label="Majors" prop="majors">
          <el-input
              v-model="school.majors"
              type="textarea"
              :rows="2"
          />
          <div class="majors-hint">
            Enter a major, separated by commas or Spaces (e.g., XX College-XX Department-XX Major.)
          </div>
        </el-form-item>

        <el-form-item label="Contact Phone" prop="contactPhone">
          <el-input v-model="school.contactPhone" />
        </el-form-item>

        <el-form-item label="Contact Email" prop="contactEmail">
          <el-input v-model="school.contactEmail" />
        </el-form-item>

        <el-form-item label="Website" prop="website">
          <el-input v-model="school.website" />
        </el-form-item>
        <el-form-item label="Apply request" prop="applyrequest">
          <el-input v-model="school.applyrequest" />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="schoolDialog = false" class="cancel-btn">Cancel</el-button>
        <el-button type="primary" @click="submitSchoolForm" class="confirm-btn">Confirm</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { LoginData, RegisterData } from "@/api/loginApi";
import cookie from 'js-cookie'

const router = useRouter()

// Animation states
const loginError = ref(false)
const activeInput = ref('')
const hoveredButton = ref('')

// Dialog box control
const dialogVisible = ref(false);
const schoolDialog = ref(false);

// Form references
const studentFormRef = ref(null)
const schoolForm = ref(null)

// Student Form
const studentForm = ref({
  loginId: '',
  password: '',
  role: 'STUDENT',
  name: '',
  gender: '',
  birthDate: '',
  contactPhone: '',
  contactEmail: '',
  address: '',
  currentschool: ''
})

// School Form
const school = ref({
  loginId: '',
  password: '',
  role: 'SCHOOL',
  schoolName: '',
  location: '',
  majors: '',
  description: '',
  contactPhone: '',
  contactEmail: '',
  website: '',
  applyrequest: ''
})

// Login Form
const loginForm = ref({
  loginId: '',
  password: '',
  role: ''
})

const loading = ref(false)
const loginFormRef = ref(null)

// Animation methods
const inputFocus = (field) => {
  activeInput.value = field
}

const inputBlur = () => {
  activeInput.value = ''
}

const hoverEffect = (button) => {
  hoveredButton.value = button
}

// Login handling
const handleLogin = async () => {
  const { loginId, password, role } = loginForm.value
  if (!loginId?.trim() || !password?.trim()) {
    loginError.value = true
    setTimeout(() => loginError.value = false, 500)
    ElMessage.error('Username and password are required!')
    return
  }

  if (!role) {
    loginError.value = true
    setTimeout(() => loginError.value = false, 500)
    ElMessage.error('Please select your role!')
    return
  }

  loading.value = true

  try {
    const { data: resp } = await LoginData(loginForm.value)
    const { user, token } = resp

    // Store user data
    localStorage.setItem('name', user.loginId)
    localStorage.setItem('token', token)
    localStorage.setItem('role', user.role)

    ElMessage.success(`Login successful as ${role}`)

    // Redirect based on role
    switch (role) {
      case 'STUDENT':
        await router.push('/studentPage')
        break
      case 'SCHOOL':
        await router.push('/schoolPage')
        break
      case 'ADMIN':
        await router.push('/adminPage')
        break
    }
  } catch (error) {
    loginError.value = true
    setTimeout(() => loginError.value = false, 500)
    ElMessage.error('Login failed. Please check your credentials.')
  } finally {
    loading.value = false
  }
}

// Student registration
const studentRegisterForm = async () => {
  try {
    await ElMessageBox.confirm(
        'Attention please! Students are not allowed to change their username and gender once they are registered.',
        'Tips',
        {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
    )
    studentFormRef.value?.resetFields()
    dialogVisible.value = true
  } catch (error) {
    ElMessage.info('Registration canceled')
  }
}

const submitStudentForm = async () => {
  try {
    await RegisterData(studentForm.value)
    ElMessage.success('Student registration successful!')
    dialogVisible.value = false
  } catch (error) {
    ElMessage.error('Student registration failed. Please try again.')
  }
}

// School registration
const schoolRegisterForm = async () => {
  try {
    await ElMessageBox.confirm(
        'Attention please! Username cannot be changed after school registration.',
        'Tips',
        {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          type: 'warning'
        }
    )
    schoolForm.value?.resetFields()
    schoolDialog.value = true
  } catch (error) {
    ElMessage.info('Registration canceled')
  }
}

const submitSchoolForm = async () => {
  try {
    // Process majors input
    const majorsArray = school.value.majors
        ?.split(/[,，\s]+/)
        ?.map(item => item.trim())
        ?.filter(item => item !== '')

    const payload = {
      ...school.value,
      majors: majorsArray
    }

    await RegisterData(payload)
    ElMessage.success('School registration successful!')
    schoolDialog.value = false
  } catch (error) {
    ElMessage.error('School registration failed. Please try again.')
  }
}
</script>

<style scoped>
/* Base styles */
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  overflow: hidden;
  position: relative;
}

.login-box {
  width: 420px;
  padding: 40px;
  background-color: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 1;
  transition: all 0.3s ease;
  transform: translateY(0);
  backdrop-filter: blur(5px);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.login-box:hover {
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.login-header h2 {
  color: #303133;
  font-size: 24px;
  margin-bottom: 8px;
  font-weight: 600;
}

.login-header p {
  color: #909399;
  font-size: 14px;
}

/* Form styles */
.login-form {
  width: 100%;
  margin: 0 auto;
}

.form-group {
  margin-bottom: 24px;
  transition: all 0.3s ease;
}

.form-group:hover {
  transform: translateX(5px);
}

/* Input focus effects */
:deep(.el-input__wrapper) {
  transition: all 0.3s ease;
  border-radius: 8px;
  background-color: rgba(245, 247, 250, 0.8);
}

:deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 1px #409eff, 0 0 8px 2px rgba(64, 158, 255, 0.3);
  background-color: #fff;
}

/* Button styles */
.login-btn {
  width: 100%;
  height: 48px;
  border-radius: 8px;
  font-weight: 500;
  letter-spacing: 0.5px;
  transition: all 0.3s ease;
  background: linear-gradient(90deg, #409eff, #66b1ff);
  border: none;
  box-shadow: 0 4px 6px rgba(64, 158, 255, 0.2);
  margin-left: 0px;
}

.login-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(64, 158, 255, 0.3);
}

.login-btn:active {
  transform: translateY(0);
}

/* Link buttons */
.switch-auth {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

.auth-link {
  border: none;
  background: transparent;
  color: #606266;
  transition: all 0.3s ease;
  padding: 8px 12px;
  font-size: 13px;
}

.auth-link:hover {
  color: #409eff;
  transform: translateY(-2px);
  background-color: rgba(64, 158, 255, 0.05);
}

/* Animation classes */
.shake {
  animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
  20%, 40%, 60%, 80% { transform: translateX(5px); }
}

/* Floating decoration */
.floating-elements {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  overflow: hidden;
  z-index: -1;
  pointer-events: none;
}

.circle {
  position: absolute;
  border-radius: 50%;
  background: rgba(64, 158, 255, 0.1);
  animation: float 15s infinite linear;
}

.circle-1 {
  width: 150px;
  height: 150px;
  top: -50px;
  left: -50px;
  animation-delay: 0s;
}

.circle-2 {
  width: 200px;
  height: 200px;
  bottom: -80px;
  right: -80px;
  animation-delay: 3s;
}

.circle-3 {
  width: 100px;
  height: 100px;
  top: 40%;
  right: -30px;
  animation-delay: 6s;
}

@keyframes float {
  0% { transform: translate(0, 0) rotate(0deg); }
  25% { transform: translate(20px, 20px) rotate(90deg); }
  50% { transform: translate(0, 40px) rotate(180deg); }
  75% { transform: translate(-20px, 20px) rotate(270deg); }
  100% { transform: translate(0, 0) rotate(360deg); }
}

/* Dialog animations */
:deep(.animated-dialog) {
  animation: fadeInUp 0.4s ease;
  border-radius: 12px;
  overflow: hidden;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dialog-header {
  text-align: center;
  padding-bottom: 16px;
  border-bottom: 1px solid #ebeef5;
  margin-bottom: 20px;
}

.dialog-header h3 {
  color: #303133;
  font-size: 20px;
  margin: 0;
}

.cancel-btn {
  transition: all 0.3s ease;
  padding: 10px 20px;
}

.cancel-btn:hover {
  color: #409eff;
  border-color: #c6e2ff;
  background-color: #ecf5ff;
}

.confirm-btn {
  transition: all 0.3s ease;
  background: linear-gradient(90deg, #409eff, #66b1ff);
  border: none;
  padding: 10px 20px;
}

.confirm-btn:hover {
  background: linear-gradient(90deg, #66b1ff, #409eff);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(64, 158, 255, 0.3);
}

/* Form item styles in dialogs */
:deep(.el-form-item__label) {
  font-weight: 500;
  color: #606266;
}

/* Majors hint style */
.majors-hint {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
  line-height: 1.4;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .login-box {
    width: 90%;
    padding: 30px 20px;
  }

  .switch-auth {
    flex-direction: column;
    gap: 10px;
  }

  :deep(.animated-dialog) {
    width: 90% !important;
  }
}

@media (max-width: 480px) {
  .login-header h2 {
    font-size: 20px;
  }

  .login-header p {
    font-size: 13px;
  }

  .form-group {
    margin-bottom: 18px;
  }
}
</style>