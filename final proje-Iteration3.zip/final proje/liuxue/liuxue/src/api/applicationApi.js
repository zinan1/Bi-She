import request from "@/utils/axios";

//String concatenation should use backquotes, not single quotes.
// Student application
export const studentApplication = (student) => {
    return request({
        url:'/api/student/applications',
        method:'post',
        data: student
    });
};
//Student view application
export const applicationStudent = () => {
    return request({
        url:'/api/student/applications',
        method:'get'
    });
};
//School View Application
export const viewApplication = () => {
    return request({
        url:'/api/school/applications',
        method:'get'
    });
};
//School consent
export const agreeApplication = (id) => {
    return request({
        url:`/api/school/applications/${id}/approve`,
        method:'put'
    });
};
//The school refused
export const refuseApplication = (id) => {
    return request({
        url:`/api/school/applications/${id}/reject`,
        method:'put'
    });
};
//Gets a list of attachments for the specified application
export const getApplicationFile = (id) => {
    return request({
        url:`/api/school/applications/${id}/files`,
        method:'get'
    })
}
// Download file method
export const downloadApplicationFile = (filename) => {
    return request({
        url: `/api/school/applications/files/${filename}`,
        method: 'get',
        responseType: 'blob'
    })
}