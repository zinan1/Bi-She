<template>
    <div class="app-container">
      <div class="header-container">
        <div class="total-count">
          Total number of students: {{ total }}
        </div>
        <div class="search-container">
          <el-input
              class="search-input"
              v-model="searchStudentId"
              placeholder="Please enter ID"
              @keyup.enter="studentSearch"
          ></el-input>
          <el-button
              class="search-btn"
              type="primary"
              :icon="Search"
              @click="studentSearch "
          >Search</el-button>
        </div>
      </div>
      <div class="table-container">
        <el-table
            :data="studentData"
            style="width: 100%"
            stripe
            border
            highlight-current-row
            v-loading="loading"
        >
          <el-table-column
              label="ID"
              prop="id"
              width="80"
              align="center"
          />
          <el-table-column
              label="Student ID"
              prop="studentId"
              width="100"
              align="center"
          />
          <el-table-column
              label="Name"
              prop="name"
              width="100"
              align="center"
          />
          <el-table-column
              label="Gender"
              prop="gender"
              width="100"
              align="center"
          />
          <el-table-column
              label="Birth Date"
              prop="birthDate"
              width="150"
              align="center"
          />
          <el-table-column
              label="Contact Phone"
              prop="contactPhone"
              width="150" align="center"
          />
          <el-table-column
              label="Contact Email"
              prop="contactEmail"
              align="center"
              show-overflow-tooltip
          />
          <el-table-column
              label="Address"
              prop="address"
              align="center"
              show-overflow-tooltip
          />
          <el-table-column label="Operations" width="150">
            <template #default="scope">
              <el-button
                  size="small"
                  type="info"
                  @click="handleEdit(scope.row)"
              >
                Detail
              </el-button>
              <el-button
                  size="small"
                  type="danger"
                  @click="handleDelete(scope.$index, scope.row)"
              >
                Delete
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="student-pagination-block" v-if="showPaginated">
        <el-pagination
            v-model:current-page="currentPage"
            v-model:page-size="pageSize"
            :page-sizes="[10, 20]"
            :background="background"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
        >
          </el-pagination>
        <div class="data-backup">
          <div class="operation-buttons">
            <el-button
                type="primary"
                @click="showBackup"
                :loading="backupLoading"
            >
              Data backup
            </el-button>
            <el-button
                type="warning"
                @click="showRestore"
                :loading="restoreLoading"
            >
              Data recovery
            </el-button>
          </div>
        </div>
      </div>
      <el-dialog
          v-model="dialogVisible"
          width="30%"
      >
        <template #header>
          <div style="text-align: center">
            <span class="el-dialog__title">{{dialogTitle}}</span>
          </div>
        </template>
        <el-form
            :model="studentForm"
            ref="studentFormRef"
            label-width="120px"
        >
          <el-form-item label="ID" prop="id">
            {{studentForm.id}}
          </el-form-item>
          <el-form-item label="Student ID" prop="studentId">
            {{studentForm.studentId}}
          </el-form-item>
          <el-form-item label="Name" prop="name">
            {{studentForm.name}}
          </el-form-item>
          <el-form-item label="Gender" prop="gender">
            {{studentForm.gender}}
          </el-form-item>
          <el-form-item label="Birth Date" prop="birthDate">
            {{studentForm.birthDate}}
          </el-form-item>
          <el-form-item label="Contact Phone" prop="contactPhone">
            {{studentForm.contactPhone}}
          </el-form-item>
          <el-form-item label="Contact Email" prop="contactEmail">
            {{studentForm.contactEmail}}
          </el-form-item>
          <el-form-item label="Address" prop="address">
            {{studentForm.address}}
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button type="primary" @click="dialogVisible = false">Confirm</el-button>
        </template>
      </el-dialog>
      </div>
</template>

<script setup>
import { getStudentData,getStudentById,deleteStudentData } from '@/api/studentApi'
import {onMounted, ref, computed, watch, onUnmounted} from "vue";
import { Search } from '@element-plus/icons-vue'
import { debounce } from 'lodash';
import { ElMessage, ElMessageBox } from 'element-plus'
import {databaseBackup, databaseRestore} from "@/api/schoolApi";

//data
const allStudentData = ref([])
const studentData = ref([])
const loading = ref(false)
//pagination
const currentPage = ref(1)
const pageSize = ref(10)
const background = ref(true)
const total = ref(0)
//search id
const searchStudentId = ref('');
// Dialog box control
const dialogVisible = ref(false)
const dialogTitle = ref('')
const isEdit = ref(false)
// Form references
const studentFormRef = ref(null)

//backup and restore
const backupLoading = ref(false)
const restoreLoading = ref(false)

const studentForm = ref({
  id:'',
  studentId: '',
  name: '',
  gender: '',
  birthDate: '',
  contactPhone: '',
  contactEmail: '',
  address: ''
})

onMounted( () => {
  showStudents()
});

const showPaginated = computed(() => {
  return searchStudentId.value ? '' : showStudents()
})

const handleEdit = (row) => {
  dialogTitle.value = 'View Student'
  isEdit.value = true
  studentForm.value = JSON.parse(JSON.stringify(row))
  dialogVisible.value = true
}


const showStudents = async  () => {
  loading.value = true;
  try {
    const resp = await getStudentData();
    allStudentData.value = resp.data;
    total.value = resp.data.length;
    updatePaginatedData();
  } catch (error) {
    console.error("Failed to fetch data:", error);
  } finally {
    loading.value = false;
  }
}
const updatePaginatedData = () => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  studentData.value = allStudentData.value.slice(start, end)
}

const studentSearch = debounce( async  () =>{
  if (!searchStudentId.value) {
    showStudents()
    return
  }
  try {
    const res = await getStudentById(searchStudentId.value)
    studentData.value = res.data ? [res.data] : []
    if (studentData.value.length === 0) {
      ElMessage.warning('The student information was not found')
    }
  } catch (error) {
    ElMessage.info('Search failure: Without the student,' + error.message)
    studentData.value = []
  }
},500)

const handleDelete = async (index, row) => {
  try {
    await ElMessageBox.confirm(`Confirm deletion ${row.studentId}?`, 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    await deleteStudentData(row.id)
    ElMessage.success('Student deleted successfully')
    await showStudents()
  } catch (error) {
    ElMessage.info(`Cancel deletion ${row.studentId}`)
  }
}

const showBackup = async () => {
  try {
    backupLoading.value = true
    await ElMessageBox.confirm('Are you sure you want to perform a data backup?', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    const resp = await databaseBackup()
    const fullUrl = `${resp.data?.backupPath?.replace(/\\/g, '/')}`
    storagePath(fullUrl)
    console.log(fullUrl)
    ElMessage.success('Backup successful！')
  } catch (error) {
    ElMessage.info(`Canceling a backup`)
  } finally {
    backupLoading.value = false
  }
}

const showRestore = async () => {
  try {
    restoreLoading.value = true
    await ElMessageBox.confirm('Are you sure you want to recover your data? This operation overwrites the existing data', 'Warnings', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    const fullUrl = localStorage.getItem('fullUrl')
    const restore = {
      backupPath:fullUrl
    }
    await databaseRestore(restore)
    ElMessage.success('Recovery successful! The system may need a refresh')
  } catch (error) {
    ElMessage.info(`Cancel recovery data`)
  } finally {
    restoreLoading.value = false
  }
}

const storagePath = (fullUrl) => {
  localStorage.setItem('fullUrl',fullUrl)
}


watch([currentPage, pageSize], () => {
  if (!searchStudentId.value) {
    updatePaginatedData()
  }
})

onUnmounted(() => {
  studentSearch?.cancel();
});

</script>

<style>
.header-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding: 0 10px;
}

.total-count {
  font-weight: bold;
  font-size: 14px;
  color: #606266;
}

.search-container {
  display: flex;
  gap: 8px;
}


.search-input {
  width: 200px;
}

.search-btn {
  width: 120px;
}
.student-pagination-block  {
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.table-container {
  margin-top: 15px;
}
</style>