<template>
  <el-container class="admin-layout">
    <!-- Sidebar Navigation -->
    <el-aside class="sidebar">
      <div class="user-profile">
        <el-avatar
            class="user-avatar"
            :size="48"
            :src="circleUrl"
            @mouseenter="startAvatarAnimation"
            @mouseleave="stopAvatarAnimation"
            :style="avatarStyle"
        />
        <div class="user-info">
          <span class="username">{{ name }}</span>
          <span class="user-role">Administrator</span>
        </div>
      </div>

      <el-menu
          class="nav-menu"
          router
          :default-active="activePath"
          @mouseenter.native="onMenuHover"
          @mouseleave.native="onMenuLeave"
      >
        <el-menu-item
            v-for="route in adminRoutes[0].children"
            :key="route.path"
            :index="route.path"
            :class="{ 'is-active': $route.path === route.path }"
        >
          <el-icon class="menu-icon">
            <component :is="route.meta?.icon || 'Menu'" />
          </el-icon>
          <span class="menu-title">{{ route.meta?.title || route.name }}</span>
          <div class="menu-highlight"></div>
        </el-menu-item>
      </el-menu>

      <div class="logout-btn-container">
        <el-button
            class="logout-btn"
            type="danger"
            plain
            round
            @click="ShowExit"
            @mouseenter="onLogoutHover"
            @mouseleave="onLogoutLeave"
        >
          <el-icon class="logout-icon"><SwitchButton /></el-icon>
          <span>Logout</span>
        </el-button>
      </div>

      <div class="sidebar-footer">
        <div class="animated-dots">
          <div
              v-for="i in 3"
              :key="i"
              class="dot"
              :style="{ animationDelay: `${i * 0.2}s` }"
          ></div>
        </div>
      </div>
    </el-aside>

    <!-- Main Content Area -->
    <el-container class="main-container">
      <el-header class="main-header">
        <div class="page-title">
          <h1 class="title-text">{{ $route.meta?.title || $route.name }}</h1>
          <div class="breadcrumb">
            <el-breadcrumb separator="/">
              <el-breadcrumb-item
                  v-for="(item, index) in $route.matched"
                  :key="index"
              >
                {{ item.meta?.title || item.name }}
              </el-breadcrumb-item>
            </el-breadcrumb>
          </div>
        </div>
        <div class="header-decoration">
          <div class="decoration-circle"></div>
          <div class="decoration-wave"></div>
        </div>
      </el-header>

      <el-main class="main-content">
        <router-view v-slot="{ Component }">
          <transition name="fade-slide" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { ElMessage } from "element-plus";
import { SwitchButton, Menu } from '@element-plus/icons-vue';
import adminRoutes from '@/router/adminRoutes';

const route = useRoute();
const router = useRouter();
const name = ref(null);

// Animation states
const avatarScale = ref(1);
const avatarRotation = ref(0);
const avatarAnimation = ref(null);
const isMenuHovered = ref(false);
const isLogoutHovered = ref(false);

// Set active path for menu highlighting
const activePath = computed(() => route.matched[0]?.path || '');

// User avatar
const circleUrl = ref('https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png');

// Computed avatar style
const avatarStyle = computed(() => ({
  transform: `scale(${avatarScale.value}) rotate(${avatarRotation.value}deg)`,
  transition: 'transform 0.5s ease'
}));

onMounted(() => {
  getName();
});

const getName = () => {
  try {
    const username = localStorage.getItem('name');
    if (!username) {
      return router.replace('/login');
    }
    name.value = username;
  } catch (error) {
    console.error('Failed to get username:', error);
    router.replace('/login');
  }
};

const ShowExit = () => {
  try {
    // Clear all local storage items
    ['token', 'name', 'role', 'path'].forEach(item => localStorage.removeItem(item));
    router.replace('/');
    ElMessage.success('Logged out successfully');
  } catch (error) {
    // Fallback in case of error
    ['token', 'name', 'role', 'path'].forEach(item => localStorage.removeItem(item));
    router.replace('/');
  }
};

// Avatar animation
const startAvatarAnimation = () => {
  avatarScale.value = 1.1;
  avatarAnimation.value = setInterval(() => {
    avatarRotation.value = (avatarRotation.value + 2) % 360;
  }, 50);
};

const stopAvatarAnimation = () => {
  avatarScale.value = 1;
  avatarRotation.value = 0;
  clearInterval(avatarAnimation.value);
};

// Menu hover effects
const onMenuHover = () => {
  isMenuHovered.value = true;
};

const onMenuLeave = () => {
  isMenuHovered.value = false;
};

// Logout button effects
const onLogoutHover = () => {
  isLogoutHovered.value = true;
};

const onLogoutLeave = () => {
  isLogoutHovered.value = false;
};
</script>

<style scoped>
.admin-layout {
  min-height: 100vh;
  background-color: #f5f7fa;
}

/* Sidebar Styles */
.sidebar {
  width: 220px !important;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  z-index: 1000;
  background: linear-gradient(180deg, #304156 0%, #1f2d3d 100%);
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  color: #bfcbd9;
  display: flex;
  flex-direction: column;
}

.user-profile {
  display: flex;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  position: relative;
  overflow: hidden;
}

.user-profile::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  animation: rainbow 8s linear infinite;
}

@keyframes rainbow {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

.user-avatar {
  margin-right: 12px;
  border: 2px solid rgba(255, 255, 255, 0.2);
  transition: all 0.3s ease;
  cursor: pointer;
}

.user-info {
  display: flex;
  flex-direction: column;
}

.username {
  font-weight: 600;
  font-size: 16px;
  color: white;
  margin-bottom: 2px;
  transition: all 0.3s;
}

.user-role {
  font-size: 12px;
  color: #9aabb8;
  transition: all 0.3s;
}

.nav-menu {
  border-right: none;
  background-color: transparent;
  padding: 10px 0;
  flex-grow: 1;
  position: relative;
}

.nav-menu::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
}

.nav-menu :deep(.el-menu-item) {
  height: 48px;
  line-height: 48px;
  margin: 4px 10px;
  border-radius: 4px;
  color: #bfcbd9;
  transition: all 0.3s;
  position: relative;
  overflow: hidden;
  background-color: transparent !important;
}

.nav-menu :deep(.el-menu-item:hover) {
  color: #ffffff;
  transform: translateX(5px);
}

.nav-menu :deep(.el-menu-item:hover) .menu-highlight {
  width: 100%;
}

.nav-menu :deep(.el-menu-item.is-active) {
  color: #409eff;
  font-weight: 500;
}

.nav-menu :deep(.el-menu-item.is-active) .menu-highlight {
  width: 100%;
  background: rgba(64, 158, 255, 0.3);
}

.menu-icon {
  font-size: 18px;
  margin-right: 8px;
  vertical-align: middle;
  transition: all 0.3s;
}

.nav-menu :deep(.el-menu-item:hover) .menu-icon {
  transform: scale(1.2);
}

.menu-title {
  vertical-align: middle;
  position: relative;
  z-index: 1;
}

.menu-highlight {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 100%;
  background: rgba(255, 255, 255, 0.1);
  transition: width 0.3s ease;
  z-index: 0;
}

.logout-btn-container {
  padding: 20px;
  margin-top: auto;
}

.logout-btn {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: all 0.3s;
  position: relative;
  overflow: hidden;
}

.logout-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(245, 108, 108, 0.3);
}

.logout-btn::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
  transition: all 0.6s;
}

.logout-btn:hover::before {
  left: 100%;
}

.logout-icon {
  transition: all 0.3s;
}

.logout-btn:hover .logout-icon {
  transform: rotate(180deg);
}

.sidebar-footer {
  padding: 10px;
  text-align: center;
}

.animated-dots {
  display: flex;
  justify-content: center;
  gap: 6px;
}

.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: rgba(255,255,255,0.3);
  animation: bounce 1.4s infinite ease-in-out;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-6px); }
}

/* Main Content Styles */
.main-container {
  margin-left: 220px;
  min-height: 100vh;
  transition: all 0.3s;
}

.main-header {
  height: auto;
  padding: 0;
  background-color: white;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden;
}

.page-title {
  padding: 20px;
  text-align: left;
  position: relative;
  z-index: 1;
}

.title-text {
  font-size: 24px;
  font-weight: 600;
  color: #303133;
  margin: 0 0 8px 0;
  position: relative;
  display: inline-block;
}

.title-text::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 0;
  width: 100%;
  height: 3px;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.5s ease;
}

.main-header:hover .title-text::after {
  transform: scaleX(1);
}

.breadcrumb {
  font-size: 14px;
  color: #606266;
}

.header-decoration {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 200px;
  overflow: hidden;
  opacity: 0.1;
  z-index: 0;
}

.decoration-circle {
  position: absolute;
  top: -50px;
  right: -50px;
  width: 200px;
  height: 200px;
  border-radius: 50%;
  background: radial-gradient(circle, #409EFF, transparent 70%);
}

.decoration-wave {
  position: absolute;
  bottom: -20px;
  right: -100px;
  width: 300px;
  height: 100px;
  background: radial-gradient(ellipse, #67C23A, transparent 70%);
  border-radius: 50%;
}

.main-content {
  padding: 20px;
  min-height: calc(100vh - 120px);
}

/* Transition Effects */
.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.3s ease;
}

.fade-slide-enter-from {
  opacity: 0;
  transform: translateY(10px);
}

.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

/* Responsive Adjustments */
@media (max-width: 992px) {
  .sidebar {
    transform: translateX(-100%);
  }

  .sidebar.show {
    transform: translateX(0);
  }

  .main-container {
    margin-left: 0;
  }
}
</style>