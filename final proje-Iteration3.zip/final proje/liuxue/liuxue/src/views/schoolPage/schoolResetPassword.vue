<template>
  <div class="reset-page">
    <el-card class="reset-card" :class="{'card-animate': animateCard}">
      <div class="reset-container">
        <transition name="fade" mode="out-in">
          <el-form
              ref="resetFormRef"
              :model="resetForm"
              :rules="formRules"
              label-position="top"
              @submit.prevent="submitForm"
              key="resetForm"
          >
            <el-form-item>
              <h2 class="form-title">
                <span class="title-text">Password Reset</span>
                <span class="title-icon">🔒</span>
              </h2>
            </el-form-item>

            <el-form-item label="Username" prop="loginId">
              <el-input
                  v-model="resetForm.loginId"
                  placeholder="Enter your username"
                  prefix-icon="User"
                  clearable
                  @focus="handleInputFocus"
                  @blur="handleInputBlur"
              />
            </el-form-item>

            <el-form-item label="Identity" prop="role">
              <el-select
                  v-model="resetForm.role"
                  placeholder="Select your identity"
                  style="width: 100%"
                  @focus="handleInputFocus"
                  @blur="handleInputBlur"
              >
                <el-option label="Student" value="STUDENT" />
                <el-option label="School" value="SCHOOL" />
              </el-select>
            </el-form-item>

            <el-form-item label="New Password" prop="newPassword">
              <el-input
                  v-model="resetForm.newPassword"
                  type="password"
                  placeholder="Enter new password"
                  autocomplete="new-password"
                  prefix-icon="Lock"
                  show-password
                  clearable
                  @focus="handleInputFocus"
                  @blur="handleInputBlur"
              />
              <transition name="slide-fade">
                <div class="password-hint" v-if="resetForm.newPassword">
                  Password must be 6-20 characters, containing letters and numbers
                </div>
              </transition>
            </el-form-item>

            <el-form-item label="Confirm Password" prop="confirmPassword">
              <el-input
                  v-model="resetForm.confirmPassword"
                  type="password"
                  placeholder="Confirm your new password"
                  autocomplete="new-password"
                  prefix-icon="Lock"
                  show-password
                  clearable
                  @focus="handleInputFocus"
                  @blur="handleInputBlur"
              />
            </el-form-item>

            <el-form-item>
              <el-button
                  type="primary"
                  native-type="submit"
                  :loading="submitting"
                  class="submit-btn"
                  @mouseenter="handleButtonHover"
              >
                <span class="btn-text">Reset Password</span>
                <span class="btn-icon">→</span>
              </el-button>
            </el-form-item>
          </el-form>
        </transition>
      </div>
    </el-card>

    <!-- 背景装饰元素 -->
    <div class="bg-circle-1"></div>
    <div class="bg-circle-2"></div>
    <div class="bg-circle-3"></div>
  </div>
</template>

<script setup>
import { reactive, ref, onMounted } from 'vue'
import { ResetPassword } from "@/api/loginApi"
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'

const router = useRouter()
const resetFormRef = ref(null)
const submitting = ref(false)
const animateCard = ref(false)

onMounted(() => {
  // 卡片入场动画
  setTimeout(() => {
    animateCard.value = true
  }, 100)
})

const resetForm = reactive({
  loginId: '',
  role: '',
  newPassword: '',
  confirmPassword: ''
})

// password rule
const validatePassword = (rule, value, callback) => {
  if (!value) {
    callback(new Error('Please input password'))
  } else if (value.length < 6 || value.length > 20) {
    callback(new Error('Password length should be 6-20 characters'))
  } else if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) {
    callback(new Error('Password must contain both letters and numbers'))
  } else {
    callback()
  }
}

// Confirm password validation
const validateConfirmPassword = (rule, value, callback) => {
  if (!value) {
    callback(new Error('Please confirm your password'))
  } else if (value !== resetForm.newPassword) {
    callback(new Error('Two passwords do not match!'))
  } else {
    callback()
  }
}

const formRules = reactive({
  loginId: [
    { required: true, message: 'Please input username', trigger: 'blur' },
    { min: 3, max: 16, message: 'Length should be 4-16 characters', trigger: 'blur' }
  ],
  role: [
    { required: true, message: 'Please select identity', trigger: 'change' }
  ],
  newPassword: [
    { required: true, validator: validatePassword, trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, validator: validateConfirmPassword, trigger: 'blur' }
  ]
})

const submitForm = async () => {
  try {
    await ElMessageBox.confirm('Are you sure you want to reset your password?', 'Confirmation', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning',
      customClass: 'confirm-box'
    })
    const valid = await resetFormRef.value.validate()
    if (!valid){
      ElMessage.warning("Please check your input")
    } else {
      submitting.value = true
      await ResetPassword(resetForm)
      ElMessage.success('Password reset successfully')
      await router.push('/login')
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('Password reset failed')
    }
  } finally {
    submitting.value = false
  }
}

const handleInputFocus = (event) => {
  event.target.parentElement.classList.add('input-focused')
}

const handleInputBlur = (event) => {
  event.target.parentElement.classList.remove('input-focused')
}

const handleButtonHover = (event) => {
  event.target.classList.add('btn-hover')
  setTimeout(() => {
    event.target.classList.remove('btn-hover')
  }, 500)
}
</script>

<style scoped>
.reset-page {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  position: relative;
  overflow: hidden;
}

.reset-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100%;
  width: 100%;
}

.reset-card {
  width: 420px;
  padding: 40px;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  background-color: rgba(255, 255, 255, 0.95);
  transform: translateY(20px);
  opacity: 0;
  transition: all 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  z-index: 10;
}

.reset-card.card-animate {
  transform: translateY(0);
  opacity: 1;
}

.form-title {
  color: #2c3e50;
  text-align: center;
  margin-bottom: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.title-text {
  font-size: 24px;
  font-weight: 600;
}

.title-icon {
  font-size: 22px;
  transform: scale(1);
  transition: transform 0.3s ease;
}

.form-title:hover .title-icon {
  transform: scale(1.2) rotate(15deg);
}

:deep(.el-form-item__label) {
  font-weight: 500;
  color: #5a6a85;
  margin-bottom: 6px;
}

:deep(.el-input__wrapper) {
  border-radius: 8px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

:deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2) !important;
}

.input-focused :deep(.el-input__wrapper) {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.password-hint {
  font-size: 12px;
  color: #909399;
  margin-top: 6px;
  padding: 6px 10px;
  background-color: #f8f9fa;
  border-radius: 6px;
  border-left: 3px solid #409eff;
}

.submit-btn {
  width: 100%;
  margin-top: 20px;
  height: 44px;
  border-radius: 8px;
  font-weight: 500;
  letter-spacing: 0.5px;
  transition: all 0.3s ease;
  overflow: hidden;
  position: relative;
}

.submit-btn .btn-text {
  display: inline-block;
  transition: all 0.3s ease;
}

.submit-btn .btn-icon {
  position: absolute;
  right: 20px;
  opacity: 0;
  transform: translateX(-10px);
  transition: all 0.3s ease;
}

.submit-btn.btn-hover .btn-text {
  transform: translateX(-8px);
}

.submit-btn.btn-hover .btn-icon {
  opacity: 1;
  transform: translateX(0);
}

/* 背景装饰元素 */
.bg-circle-1, .bg-circle-2, .bg-circle-3 {
  position: absolute;
  border-radius: 50%;
  background: rgba(100, 149, 237, 0.1);
  z-index: 1;
}

.bg-circle-1 {
  width: 300px;
  height: 300px;
  top: -100px;
  left: -100px;
  animation: float 8s ease-in-out infinite;
}

.bg-circle-2 {
  width: 200px;
  height: 200px;
  bottom: -50px;
  right: -50px;
  animation: float 6s ease-in-out infinite 2s;
}

.bg-circle-3 {
  width: 150px;
  height: 150px;
  top: 50%;
  right: 20%;
  animation: float 5s ease-in-out infinite 1s;
}

/* 动画效果 */
@keyframes float {
  0%, 100% {
    transform: translateY(0) rotate(0deg);
  }
  50% {
    transform: translateY(-20px) rotate(5deg);
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
}

.slide-fade-enter-from,
.slide-fade-leave-to {
  transform: translateY(10px);
  opacity: 0;
}
</style>

<style>
/* 全局弹窗样式 */
.confirm-box {
  border-radius: 12px !important;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15) !important;
}

.confirm-box .el-message-box__header {
  padding: 20px 20px 10px;
}

.confirm-box .el-message-box__content {
  padding: 20px;
}

.confirm-box .el-message-box__btns {
  padding: 10px 20px 20px;
  justify-content: center;
}

.confirm-box .el-button {
  padding: 10px 24px;
  border-radius: 8px;
  font-weight: 500;
}
</style>