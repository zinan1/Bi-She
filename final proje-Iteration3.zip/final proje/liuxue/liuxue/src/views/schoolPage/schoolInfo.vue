<template>
  <div class="school-info-container">
    <div class="header">
      <h1 class="title">School Information</h1>
    </div>

    <!-- Main Information Card -->
    <el-card class="info-card" shadow="hover">
      <div class="card-content">
        <div class="avatar-section">
          <el-image
              class="avatar hoverable-image"
              :src="getFullAvatarUrl(schoolData.avatar)"
              fit="cover"
              @click="triggerFileInput"
          />
          <input
              type="file"
              ref="fileInput"
              style="display: none"
              accept="image/*"
              @change="handleFileChange"
          />
          <div class="avatar-hint" v-if="!loading">Click to change</div>
          <el-progress v-else type="circle" :percentage="50" :width="100" />
        </div>

        <div class="details-section">
          <div class="detail-row">
            <div class="detail-item">
              <span class="detail-label">ID</span>
              <span class="detail-value">{{ schoolData.id }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Username</span>
              <span class="detail-value">{{ schoolData.schoolId }}</span>
            </div>
          </div>

          <div class="detail-row">
            <div class="detail-item">
              <span class="detail-label">School Name</span>
              <span class="detail-value">{{ schoolData.schoolName }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Location</span>
              <span class="detail-value">{{ schoolData.location }}</span>
            </div>
          </div>

          <div class="detail-row">
            <div class="detail-item">
              <span class="detail-label">Contact Phone</span>
              <span class="detail-value">{{ schoolData.contactPhone }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Contact Email</span>
              <span class="detail-value">{{ schoolData.contactEmail }}</span>
            </div>
          </div>

          <div class="detail-row">
            <div class="detail-item full-width">
              <span class="detail-label">Website</span>
              <span class="detail-value">{{ schoolData.website }}</span>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- Description Card -->
    <el-card class="section-card" shadow="hover">
      <div class="section-header">
        <el-icon class="section-icon"><Document /></el-icon>
        <h3>Description</h3>
      </div>
      <div class="section-content">
        <p>{{ schoolData.description }}</p>
      </div>
    </el-card>

    <!-- Apply Request Card -->
    <el-card class="section-card" shadow="hover">
      <div class="section-header">
        <el-icon class="section-icon"><Memo /></el-icon>
        <h3>Apply Request</h3>
      </div>
      <div class="section-content">
        <p>{{ schoolData.applyrequest }}</p>
      </div>
    </el-card>

    <!-- Majors Card -->
    <el-card class="section-card" shadow="hover">
      <div class="section-header">
        <el-icon class="section-icon"><Collection /></el-icon>
        <h3>The majors offered by the school</h3>
      </div>
      <div class="section-content majors-list">
        <el-tag
            v-for="(major, index) in schoolData?.majors"
            :key="index"
            class="major-tag"
            effect="plain"
            round
        >
          {{ major }}
        </el-tag>
      </div>
    </el-card>

    <!-- Edit Button -->
    <div class="edit-button-container">
      <el-button
          type="primary"
          round
          size="large"
          @click="showEdit"
          class="edit-button"
      >
        <span>Change school information</span>
        <el-icon class="button-icon"><Right /></el-icon>
      </el-button>
    </div>

    <!-- Edit Dialog -->
    <el-dialog
        v-model="dialogVisible"
        :title="dialogTitle"
        width="50%"
        align="center"
        class="edit-dialog"
    >
      <el-form
          :model="schoolForm"
          ref="schoolFormRef"
          label-width="120px"
          label-position="top"
      >
        <div class="form-grid">
          <el-form-item label="ID" prop="id" required>
            <el-input v-model="schoolForm.id" readonly />
          </el-form-item>
          <el-form-item label="School ID" prop="schoolId" required>
            <el-input v-model="schoolForm.schoolId" readonly />
          </el-form-item>
          <el-form-item label="School Name" prop="schoolName" required>
            <el-input v-model="schoolForm.schoolName" />
          </el-form-item>
          <el-form-item label="Location" prop="location">
            <el-input v-model="schoolForm.location" />
          </el-form-item>
          <el-form-item label="Contact Phone" prop="contactPhone">
            <el-input v-model="schoolForm.contactPhone" />
          </el-form-item>
          <el-form-item label="Contact Email" prop="contactEmail">
            <el-input v-model="schoolForm.contactEmail" />
          </el-form-item>
          <el-form-item label="Website" prop="website">
            <el-input v-model="schoolForm.website" />
          </el-form-item>
        </div>

        <el-form-item label="Description" prop="description">
          <el-input v-model="schoolForm.description" type="textarea" rows="3" />
        </el-form-item>

        <el-form-item label="Apply Request" prop="applyrequest">
          <el-input v-model="schoolForm.applyrequest" type="textarea" rows="3" />
        </el-form-item>

        <el-form-item label="Majors" prop="majors">
          <el-input
              v-model="schoolForm.majors"
              type="textarea"
              :rows="2"
              placeholder="Enter majors separated by commas"
          />
          <div class="majors-hint">
            Enter a major, separated by commas or Spaces (e.g., XX College-XX Department-XX Major.)
          </div>
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="dialogVisible = false" class="dialog-button">Cancel</el-button>
        <el-button type="primary" @click="submitForm" class="dialog-button">Confirm</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from "element-plus";
import { editSingleSchoolData, SingleSchoolData } from "@/api/schoolApi";
import axios from "axios";
import { Document, Memo, Collection, Right } from '@element-plus/icons-vue';

// Dialog box control
const dialogVisible = ref(false);
const dialogTitle = ref('');
const showName = ref('');
// Form references
const schoolFormRef = ref(null);

const fileInput = ref(null);
const loading = ref(false);
// School Form
const schoolForm = ref({});

const schoolData = ref({
  avatar: '',
  id: '',
  schoolId: '',
  schoolName: '',
  location: '',
  description: '',
  contactPhone: '',
  contactEmail: '',
  website: '',
  majors: '',
  applyrequest: ''
});

onMounted(() => {
  getSchoolData();
});

const getSchoolData = async () => {
  try {
    const { data } = await SingleSchoolData();
    schoolData.value = data;
    showName.value = data.schoolName;
    schoolForm.value = { ...data };
    console.log(schoolData.value);
  } catch (error) {
    ElMessage.error('Failed to fetch data');
  }
};

const getFullAvatarUrl = (path) => {
  setLocalUrl(path);
  const BaseUrl = 'http://localhost:8082';
  switch (path) {
    case '/avatars/default_school.png':
      return `${BaseUrl}/avatars/default_school.png`;
    default:
      return `${BaseUrl}/${path}`;
  }
};

const setLocalUrl = (path) => {
  localStorage.setItem('path', path);
};

const triggerFileInput = () => {
  fileInput.value.click();
};

// Handling file selection
const handleFileChange = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  // Checking the file type
  if (!file.type.startsWith('image/')) {
    ElMessage.error('Please select the image file');
    return;
  }

  // Checking file size
  if (file.size > 2 * 1024 * 1024) {
    ElMessage.error('Images cannot exceed 2MB in size');
    return;
  }

  try {
    loading.value = true;

    const token = localStorage.getItem('token');
    // 1. Upload images to the backend
    const formData = new FormData();
    formData.append('file', file);
    console.log(formData);

    const response = await axios.post('http://localhost:8082/api/school/avatar', formData, {
      headers: {
        'Authorization': token,
        'Content-Type': 'multipart/form-data'
      }
    });

    const avatarUrl = response.data?.avatarUrl;
    console.log('school ' + avatarUrl);
    const fullUrl = `${avatarUrl?.replace(/\\/g, '/')}`;
    console.log('school ' + fullUrl);

    schoolData.value.avatar = fullUrl;

    ElMessage.success('Avatar updated successfully');
  } catch (error) {
    ElMessage.error('Failed to update avatar');
  } finally {
    loading.value = false;
    // Clear the input so that you can select the same file to upload again
    event.target.value = '';
  }
};

const showEdit = async () => {
  try {
    await ElMessageBox.confirm('The ID and username cannot be modified', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    });
    dialogTitle.value = showName.value;
    dialogVisible.value = true;
  } catch (error) {
    ElMessage.info('Canceling changes');
  }
};

const submitForm = async () => {
  try {
    await ElMessageBox.confirm('Confirm to modify school information!', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    });
    //Split by commas or Spaces, and remove whitespace characters. Already an array, use it directly. If it's a string, split it by comma/space
    const majorsArray = Array.isArray(schoolForm.value.majors)
        ? schoolForm.value.majors
        : (schoolForm.value.majors || '')
            .split(/[,，]/)
            .map(item => item.trim())
            .filter(item => item !== '');
    //Construct commit data
    const payload = {
      ...schoolForm.value,
      majors: majorsArray
    };
    const { data } = await editSingleSchoolData(payload);
    schoolData.value = data;
    ElMessage.success('Changes saved successfully');
    dialogVisible.value = false;
  } catch (error) {
    ElMessage.error('Failed to save changes');
  }
};
</script>

<style scoped>
.school-info-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  animation: fadeIn 0.5s ease-in-out;
}

.header {
  text-align: center;
  margin-bottom: 30px;
}

.title {
  font-size: 2.2rem;
  color: #303133;
  font-weight: 600;
  margin-bottom: 10px;
  position: relative;
  display: inline-block;
}

.title::after {
  content: '';
  position: absolute;
  bottom: -8px;
  left: 50%;
  transform: translateX(-50%);
  width: 80px;
  height: 3px;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  border-radius: 3px;
}

.info-card {
  margin-bottom: 25px;
  transition: all 0.3s ease;
  border-radius: 12px;
}

.info-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.card-content {
  display: flex;
  padding: 20px;
}

.avatar-section {
  flex: 0 0 200px;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-right: 30px;
}

.avatar {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  object-fit: cover;
  border: 4px solid #fff;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

.avatar:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
}

.avatar-hint {
  margin-top: 10px;
  font-size: 0.9rem;
  color: #909399;
  text-align: center;
  opacity: 0.8;
  transition: all 0.3s ease;
}

.avatar-section:hover .avatar-hint {
  opacity: 1;
  color: #409EFF;
}

.details-section {
  flex: 1;
}

.detail-row {
  display: flex;
  margin-bottom: 15px;
  gap: 20px;
}

.detail-item {
  flex: 1;
  padding: 15px;
  background-color: #f5f7fa;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.detail-item:hover {
  background-color: #ebf5ff;
  transform: translateY(-2px);
}

.detail-label {
  display: block;
  font-size: 0.9rem;
  color: #909399;
  margin-bottom: 5px;
  font-weight: 500;
}

.detail-value {
  font-size: 1rem;
  color: #303133;
  font-weight: 600;
}

.full-width {
  flex: 0 0 100%;
}

.section-card {
  margin-bottom: 25px;
  border-radius: 12px;
  transition: all 0.3s ease;
}

.section-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
}

.section-header {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 1px solid #ebeef5;
}

.section-icon {
  margin-right: 10px;
  font-size: 1.4rem;
  color: #409EFF;
}

.section-header h3 {
  margin: 0;
  font-size: 1.2rem;
  color: #303133;
}

.section-content {
  padding: 10px 5px;
  line-height: 1.6;
  color: #606266;
}

.majors-list {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.major-tag {
  transition: all 0.3s ease;
}

.major-tag:hover {
  transform: scale(1.05);
  background-color: #ecf5ff;
  color: #409EFF;
}

.edit-button-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 30px;
}

.edit-button {
  padding: 12px 24px;
  font-weight: 500;
  transition: all 0.3s ease;
}

.edit-button:hover {
  transform: translateX(5px);
}

.button-icon {
  margin-left: 8px;
  transition: all 0.3s ease;
}

.edit-button:hover .button-icon {
  transform: translateX(3px);
}

.edit-dialog {
  border-radius: 12px;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
}

.dialog-button {
  padding: 10px 24px;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.dialog-button:hover {
  transform: translateY(-2px);
}

.majors-hint {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .card-content {
    flex-direction: column;
    align-items: center;
  }

  .avatar-section {
    margin-right: 0;
    margin-bottom: 20px;
  }

  .detail-row {
    flex-direction: column;
    gap: 10px;
  }

  .form-grid {
    grid-template-columns: 1fr;
  }
}
</style>