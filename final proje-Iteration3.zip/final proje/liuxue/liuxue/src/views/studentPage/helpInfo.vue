<template>
  <div class="faq-container">
    <div class="faq-header">
      <h1 class="faq-title">Study Abroad Application Help Center</h1>
    </div>

    <!-- FAQ Sections with Transition Group -->
    <transition-group name="fade-slide" tag="div">
      <!-- Application Process Related -->
      <el-collapse
          v-show="showSection1"
          v-model="activeNames"
          accordion
          key="1"
          class="section-card"
      >
        <el-collapse-item name="1" title="I. Application Process Related">
          <div class="faq-section">
            <h3 class="section-subtitle">Application Timeline</h3>
            <div class="faq-item" @click="toggleItem('timeline')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'timeline' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: When should I start preparing my study abroad application?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'timeline'">
                  A: Begin preparations one year in advance. For Fall 2026 admission, start in Fall 2025.
                </div>
              </transition>
            </div>

            <h3 class="section-subtitle">Application Materials</h3>
            <div class="faq-item" @click="toggleItem('materials')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'materials' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: What materials are needed for study abroad applications?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'materials'">
                  A:
                  <ul>
                    <li><strong>Basic Materials</strong>: Personal Statement, Recommendation Letters (2-3), Academic Transcripts</li>
                    <li><strong>Language Tests</strong>: IELTS, TOEFL, GRE, etc. (varies by target country and program)</li>
                    <li><strong>Additional Materials</strong>: Portfolio (for arts programs), Resume, Research Proposal, etc.</li>
                  </ul>
                </div>
              </transition>
            </div>

            <h3 class="section-subtitle">Application System</h3>
            <div class="faq-item" @click="toggleItem('system')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'system' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: How to use the application system?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'system'">
                  A: Create account → Fill in personal and application information → Upload documents → Review and submit
                </div>
              </transition>
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>

      <!-- University and Program Selection -->
      <el-collapse
          v-show="showSection2"
          v-model="activeNames"
          accordion
          key="2"
          class="section-card"
      >
        <el-collapse-item name="2" title="II. University and Program Selection">
          <div class="faq-section">
            <h3 class="section-subtitle">Program Selection</h3>
            <div class="faq-item" @click="toggleItem('program')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'program' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: How should I choose my study abroad program?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'program'">
                  A: Consider your interests, career goals, and employment prospects. Choose a program that aligns with both your passions and professional objectives.
                </div>
              </transition>
            </div>

            <h3 class="section-subtitle">University Rankings</h3>
            <div class="faq-item" @click="toggleItem('rankings')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'rankings' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: Should I always choose higher ranked universities?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'rankings'">
                  A: Rankings matter, but also consider the university's specialized programs, location, and cultural environment.
                </div>
              </transition>
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>

      <!-- Language Tests Related -->
      <el-collapse
          v-show="showSection3"
          v-model="activeNames"
          accordion
          key="3"
          class="section-card"
      >
        <el-collapse-item name="3" title="III. Language Tests Related">
          <div class="faq-section">
            <h3 class="section-subtitle">Test Preparation</h3>
            <div class="faq-item" @click="toggleItem('preparation')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'preparation' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: How to prepare for IELTS or TOEFL?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'preparation'">
                  A: Build vocabulary, familiarize yourself with test formats, practice with past papers, and consider preparatory courses or online resources.
                </div>
              </transition>
            </div>

            <h3 class="section-subtitle">Score Requirements</h3>
            <div class="faq-item" @click="toggleItem('requirements')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'requirements' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: What are the language requirements for studying abroad?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'requirements'">
                  A:
                  <ul>
                    <li><strong>UK</strong>: Undergraduate IELTS 6.0-6.5, Graduate 6.5-7.0</li>
                    <li><strong>USA</strong>: Undergraduate TOEFL 80-100, Graduate around 100</li>
                    <li>Specific requirements vary by institution and program</li>
                  </ul>
                </div>
              </transition>
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>

      <!-- Visa Application Related -->
      <el-collapse
          v-show="showSection4"
          v-model="activeNames"
          accordion
          key="4"
          class="section-card"
      >
        <el-collapse-item name="4" title="IV. Visa Application Related">
          <div class="faq-section">
            <h3 class="section-subtitle">Visa Documentation</h3>
            <div class="faq-item" @click="toggleItem('documentation')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'documentation' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: What documents are needed for a student visa?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'documentation'">
                  A: Valid passport, visa photos, admission letter, financial proof, academic transcripts, etc. Required documents vary by country.
                </div>
              </transition>
            </div>

            <h3 class="section-subtitle">Visa Interview</h3>
            <div class="faq-item" @click="toggleItem('interview')">
              <div class="question">
                <span class="question-icon">
                  <el-icon :class="{ 'rotate-icon': activeItem === 'interview' }">
                    <ArrowRight />
                  </el-icon>
                </span>
                Q: What questions are asked during student visa interviews?
              </div>
              <transition name="expand">
                <div class="answer" v-show="activeItem === 'interview'">
                  A: Questions about study plans, financial sources, etc. Prepare honest, logical answers in advance and maintain confidence and politeness.
                </div>
              </transition>
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>
    </transition-group>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import {
  Search,
  ArrowRight,
  ChatDotRound,
  Promotion
} from '@element-plus/icons-vue';

// Controls the expansion item of the accordion panel
const activeNames = ref(['1']);
const activeItem = ref(null);
const searchQuery = ref('');
const showChatDialog = ref(false);
const chatMessage = ref('');

// Filter sections based on search query
const showSection1 = computed(() => shouldShowSection('Application Process Related'));
const showSection2 = computed(() => shouldShowSection('University and Program Selection'));
const showSection3 = computed(() => shouldShowSection('Language Tests Related'));
const showSection4 = computed(() => shouldShowSection('Visa Application Related'));

const toggleItem = (item) => {
  activeItem.value = activeItem.value === item ? null : item;
};

const filterFAQs = () => {
  // Reset all sections to closed when searching
  if (searchQuery.value) {
    activeNames.value = [];
  } else {
    activeNames.value = ['1'];
  }
};

const shouldShowSection = (sectionTitle) => {
  if (!searchQuery.value) return true;

  const sectionContent = getSectionContent(sectionTitle);
  return sectionContent.toLowerCase().includes(searchQuery.value.toLowerCase());
};

const getSectionContent = (sectionTitle) => {
  // This would be more comprehensive in a real implementation
  return sectionTitle;
};

const sendMessage = () => {
  if (chatMessage.value.trim()) {
    // In a real app, this would send to a backend
    console.log('Message sent:', chatMessage.value);
    chatMessage.value = '';
  }
};
</script>

<style scoped>
.faq-container {
  max-width: 1000px;
  margin: 0 auto;
  padding: 30px 20px;
  position: relative;
}

.faq-header {
  text-align: center;
  margin-bottom: 40px;
  position: relative;
}

.faq-title {
  color: #2c3e50;
  margin-bottom: 20px;
  font-size: 32px;
  font-weight: 600;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  display: inline-block;
  position: relative;
}

.faq-title::after {
  content: '';
  position: absolute;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
  width: 80px;
  height: 4px;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  border-radius: 2px;
}

.search-box {
  max-width: 500px;
  margin: 0 auto;
}

.section-card {
  margin-bottom: 20px;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
}

.section-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
}

:deep(.el-collapse-item__header) {
  font-size: 18px;
  font-weight: bold;
  padding: 16px 20px;
  background-color: #f8fafc;
  border-radius: 12px 12px 0 0 !important;
  transition: all 0.3s ease;
}

:deep(.el-collapse-item__header):hover {
  background-color: #f1f5f9;
}

:deep(.el-collapse-item__content) {
  padding: 0;
}

.faq-section {
  padding: 20px;
  background-color: white;
}

.section-subtitle {
  color: #444;
  margin: 20px 0 15px;
  padding-bottom: 8px;
  border-bottom: 1px solid #eee;
  font-size: 16px;
  font-weight: 600;
  position: relative;
}

.section-subtitle::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  width: 40px;
  height: 2px;
  background: linear-gradient(90deg, #409EFF, #67C23A);
}

.faq-item {
  margin-bottom: 15px;
  padding: 15px;
  background-color: #f9f9f9;
  border-radius: 8px;
  transition: all 0.3s ease;
  cursor: pointer;
  border-left: 3px solid transparent;
}

.faq-item:hover {
  background-color: #f0f0f0;
  border-left: 3px solid #409EFF;
  transform: translateX(5px);
}

.question {
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 8px;
  font-size: 16px;
  display: flex;
  align-items: center;
}

.question-icon {
  margin-right: 10px;
  transition: transform 0.3s ease;
}

.rotate-icon {
  transform: rotate(90deg);
}

.answer {
  color: #666;
  line-height: 1.6;
  padding-top: 10px;
  margin-top: 10px;
  border-top: 1px dashed #ddd;
}

ul {
  padding-left: 20px;
  margin: 10px 0;
}

li {
  margin-bottom: 8px;
  position: relative;
}

li::before {
  content: '•';
  color: #409EFF;
  font-weight: bold;
  display: inline-block;
  width: 1em;
  margin-left: -1em;
}

/* Transition Effects */
.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: all 0.3s ease;
}

.fade-slide-enter-from,
.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(20px);
}

.expand-enter-active,
.expand-leave-active {
  transition: all 0.3s ease;
  overflow: hidden;
}

.expand-enter-from,
.expand-leave-to {
  max-height: 0;
  opacity: 0;
  padding-top: 0;
  margin-top: 0;
  border-top: 0;
}

.expand-enter-to,
.expand-leave-from {
  max-height: 500px;
  opacity: 1;
}

/* Floating Help Button */
.floating-help {
  position: fixed;
  bottom: 40px;
  right: 40px;
  z-index: 1000;
}

.floating-help .el-button {
  width: 60px;
  height: 60px;
  box-shadow: 0 4px 12px rgba(64, 158, 255, 0.3);
  transition: all 0.3s ease;
}

.floating-help .el-button:hover {
  transform: scale(1.1);
  box-shadow: 0 6px 16px rgba(64, 158, 255, 0.4);
}

/* Chat Dialog Styles */
.chat-container {
  height: 400px;
  display: flex;
  flex-direction: column;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #eee;
  border-radius: 8px;
}

.chat-message {
  margin-bottom: 15px;
  max-width: 80%;
  padding: 10px 15px;
  border-radius: 18px;
  line-height: 1.4;
}

.chat-message.agent {
  align-self: flex-start;
  background-color: #f5f7fa;
  border-top-left-radius: 4px;
}

.chat-message.user {
  align-self: flex-end;
  background-color: #409EFF;
  color: white;
  border-top-right-radius: 4px;
}

.message-content {
  word-wrap: break-word;
}

.chat-input {
  margin-top: 10px;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
  .faq-container {
    padding: 20px 15px;
  }

  .faq-title {
    font-size: 24px;
  }

  :deep(.el-collapse-item__header) {
    font-size: 16px;
    padding: 12px 15px;
  }

  .floating-help {
    bottom: 20px;
    right: 20px;
  }

  .floating-help .el-button {
    width: 50px;
    height: 50px;
  }
}
</style>