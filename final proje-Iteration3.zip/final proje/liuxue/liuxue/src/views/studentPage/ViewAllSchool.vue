<template>
  <div class="school-container">
    <div class="header-section">
      <h1 class="animated-title">All School Information</h1>
    </div>
    <div class="search-section">
      <el-input
          class="search-input animated-input"
          v-model="searchSchoolLocation"
          placeholder="Search school Location"
          @keyup.enter="schoolSearch"
      ></el-input>
      <el-input
          class="search-input animated-input"
          v-model="searchSchoolName"
          placeholder="Search school Name"
          @keyup.enter="schoolSearch"
      ></el-input>
      <el-input
          class="search-input animated-input"
          v-model="searchSchoolId"
          placeholder="Search school ID or major"
          @keyup.enter="schoolSearch"
      ></el-input>
      <el-button
          class="search-btn animated-btn"
          type="primary"
          :icon="Search"
          @click="schoolSearch"
      >Search</el-button>
    </div>

    <div class="cards-container">
      <transition-group name="card-list" tag="div" class="card-grid">
        <div
            v-for="item in schoolList"
            :key="item.id"
            class="card-item"
            @mouseenter="hoverCard = item.id"
            @mouseleave="hoverCard = null"
        >
          <el-card
              :class="['school-card', { 'card-hover': hoverCard === item.id }]"
              shadow="hover"
          >
            <div class="tupian">
              <el-image
                  style="width: 100px; height: 100px"
                  :src="getFullAvatarUrl(item.avatar)"
                  fit="cover"
              />
            </div>
            <template #footer>
              <span class="school-name">{{item.id}} {{ item.schoolName }}</span>
              <el-button
                  class="btn-Apply"
                  size="small"
                  round
                  @click="showApply(item)"
              >
                Open: School Details
              </el-button>
            </template>
          </el-card>
        </div>
      </transition-group>
    </div>

    <!-- School Details Dialog (unchanged) -->
    <el-dialog
        v-model="dialogVisible"
        :title="currentSchool?.schoolName"
        width="55%"
    >
      <el-form
          ref="schoolForm"
          :model="formData"
          label-width="120px"
          label-position="right"
      >
        <el-form-item label="ID">
          {{formData.id}}
        </el-form-item>
        <el-form-item label="School ID">
          {{formData.schoolId}}
        </el-form-item>
        <el-form-item label="School Name">
          {{formData.schoolName}}
        </el-form-item>
        <el-form-item label="Location">
          {{formData.location}}
        </el-form-item>
        <el-form-item label="Description">
          {{formData.description}}
        </el-form-item>
        <el-form-item label="Contact Phone">
          {{formData.contactPhone}}
        </el-form-item>
        <el-form-item label="Contact Email">
          {{formData.contactEmail}}
        </el-form-item>
        <el-form-item label="Website">
          {{formData.website}}
        </el-form-item>
        <el-form-item label="Apply Request">
          {{formData.applyrequest}}
        </el-form-item>
        <el-form-item label="Optional major">
          <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            <span v-for="(major, index) in formData.majors" :key="index" style="margin-right: 8px;">
              {{ major }}
            </span>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="ApplySchool">Apply School</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- Application Dialog (unchanged) -->
    <el-dialog
        v-model="applyDialogVisible"
        :title="currentSchool?.schoolName"
        width="50%"
        class="center-title-dialog"
        @closed="resetForm"
    >
      <el-form
          ref="studentFormRef"
          :model="student"
          :rules="studentApplicationFormRules"
          label-width="175px"
      >
        <el-form-item label="Student ID" prop="student_id" required>
          <el-input v-model="student.student_id" />
        </el-form-item>
        <el-form-item label="GPA" prop="gpa" required>
          <el-input v-model="student.gpa" />
        </el-form-item>
        <el-form-item label="Grades" prop="grades" required>
          <el-input v-model="student.grades" />
        </el-form-item>
        <el-form-item label="Current School" prop="currentschool" required>
          <el-input v-model="student.currentschool" />
        </el-form-item>
        <el-form-item label="Major" prop="major" required>
          <el-select
              v-model="student.major"
              placeholder="Please select a major"
              style="width: 100%"
          >
            <el-option
                v-for="(major, index) in currentSchool?.majors || []"
                :key="index"
                :label="major"
                :value="major"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Graduation(Yes or No)" prop="enrolled" required>
          <el-select v-model="student.enrolled">
            <el-option label="YES" value="YES" />
            <el-option label="NO" value="NO" />
          </el-select>
        </el-form-item>
        <el-form-item label="Application Files" prop="applicationFiles">
          <input
              type="file"
              ref="fileInput"
              style="display: none"
              @change="handleFileChange"
          />
          <el-button type="primary" @click.prevent="triggerFileInput">
            Upload application documents
          </el-button>
          <p v-if="selectedFile" style="margin-top: 10px;margin-left: 20px;">Selected: {{ selectedFile.name }}</p>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="applyDialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="submitForm">Confirm</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import {getSchoolData, getSchoolById} from '@/api/schoolApi';
import {ref, onMounted, onUnmounted} from "vue";
import {studentApplication} from "@/api/applicationApi";
import {ElMessage} from "element-plus";
import { Search } from '@element-plus/icons-vue';
import { debounce } from 'lodash';
import {studentSearchMajors} from "@/api/studentApi";

//Storing a list of schools
const schoolList = ref([]);
const hoverCard = ref(null);

//School details dialog box
const dialogVisible = ref(false)
const currentSchool = ref(null);
const formData = ref({});

//Request dialog box
const applyDialogVisible = ref(false)
const studentFormRef = ref(null)

//Search box
const searchSchoolName = ref('')
const searchSchoolLocation = ref('')
const searchSchoolId = ref('')

// Stores the files selected by the user
const fileInput = ref(null);
const selectedFile = ref(null);

//Initialize the student application information
const student = ref({
  student_id:'',
  school_id:'',
  gpa:'',
  grades:'',
  currentschool:'',
  major:'',
  enrolled:'',
});

//Getting school data
const loadSchoolData = async () => {
  try {
    const { data } = await getSchoolData();
    console.log(data);
    schoolList.value = data || [];
  } catch (error) {
    console.error('Failed to fetch school data:', error);
    schoolList.value = [];
  }
};

onMounted(()=>{
  loadSchoolData()
})

// Validation rules
const studentApplicationFormRules = {
  student_id: [
    { required: true, message: 'The Student ID cannot be null', trigger: ['blur', 'change'] },
  ],
  gpa: [
    { required: true, message: 'The GPA cannot be null', trigger: ['blur', 'change'] }
  ],
  grades: [
    { required: true, message: 'The grade cannot be null', trigger: ['blur', 'change'] },
  ],
  major: [
    { required: true, message: 'Please select a major', trigger: 'blur' }
  ],
}

const resetForm = () => {
  // Resetting form data
  Object.assign(student, {
    student_id: '',
    gpa: '',
    grades: '',
    major:'',
    enrolled: ''
  })

  selectedFile.value = null;
  if (fileInput.value) {
    fileInput.value.value = '';
  }
  // Clear validation state
  studentFormRef.value?.resetFields()
}

const showApply = (item) => {
  try {
    console.log(item?.majors)
    const { schoolId } = item;
    student.value.school_id = schoolId;
    currentSchool.value = item;
    formData.value = { ...item };
    dialogVisible.value = true;
  }catch (error){
    console.log('Failed to open the request dialog box')
  }
}

const ApplySchool = () => {
  dialogVisible.value = false;
  applyDialogVisible.value = true;
}

// Add a file selection handler
const handleFileChange = (e) => {
  const files = e.target.files;
  if (files && files.length > 0) {
    selectedFile.value = files[0];
  } else {
    selectedFile.value = null;
  }
};

const submitForm = async () => {
  try {
    console.log(student.value)
    await studentFormRef.value?.validate();

    if (!selectedFile.value) {
      ElMessage.warning('Please upload the application documents');
      return;
    }

    const formData = new FormData();
    // add data
    formData.append('file', selectedFile.value);
    formData.append('applicationData', JSON.stringify(student.value));

    await studentApplication(formData);
    ElMessage.success('Application submitted successfully');
    applyDialogVisible.value = false;
  }catch (error){
    console.error('Validation failure:', error);
  }
}

const schoolSearch = debounce( async () =>{
  try {
    const isSchoolId = /^\d+$/.test(searchSchoolId.value);
    if(isSchoolId){
      const res = await getSchoolById(searchSchoolId.value)
      schoolList.value = res.data ? [res.data] : []
      if (schoolList.value.length === 0) {
        ElMessage.warning('The school information was not found')
      }
      return;
    }
    const requestData = {
      location: searchSchoolLocation.value || undefined,
      schoolName: searchSchoolName.value || undefined,
      major: searchSchoolId.value || undefined
    };

    // 移除undefined字段，只保留有值的字段
    const searchParams = Object.fromEntries(
        Object.entries(requestData).filter(([_, value]) => value !== undefined)
    );

    // 检查是否至少有一个搜索条件
    if (Object.keys(searchParams).length === 0) {
      ElMessage.warning('请至少提供一个搜索条件');
      return;
    }

    const res = await studentSearchMajors(searchParams);
    if (res.data.message) {
      ElMessage.warning('No school was found to offer this major')
      return;
    }
    schoolList.value = res.data || [];

  } catch (error) {
    ElMessage.error('Search failure: Without this school,' )
    schoolList.value = []
  }
},500)

const getFullAvatarUrl = (path) => {
  const BaseUrl = 'http://localhost:8082';
  switch (path) {
    case '/avatars/default_school.png':
      return `${BaseUrl}/avatars/default_school.png`;
    default:
      const fullUrl = `${path?.replace(/\\/g, '/')}`
      return `${BaseUrl}/${fullUrl}`;
  }
}

const triggerFileInput = (e) => {
  e?.preventDefault(); // 添加这行确保阻止默认行为
  fileInput.value.click();
};

onUnmounted(() => {
  schoolSearch?.cancel();
});
</script>

<style scoped>
.school-container {
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}

.header-section {
  text-align: center;
  margin-bottom: 30px;
  animation: fadeInDown 0.8s ease-out;
}

.animated-title {
  font-size: 2.5rem;
  color: #2c3e50;
  margin-bottom: 20px;
  position: relative;
  display: inline-block;
}

.animated-title::after {
  content: '';
  position: absolute;
  width: 60%;
  height: 4px;
  bottom: -10px;
  left: 20%;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  border-radius: 2px;
  animation: expandLine 1s ease-out forwards;
}

.search-section {
  display: flex;
  justify-content: flex-end;
  gap: 15px;
  margin-bottom: 30px;
  padding-right: 30px;
}

.search-input {
  width: 300px;
  transition: all 0.3s ease;
}

.search-input:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.search-btn {
  padding: 10px 20px;
  transition: all 0.3s ease;
}

.search-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.cards-container {
  margin-top: 30px;
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 25px;
  padding: 10px 30px;
}

.card-item {
  transition: all 0.3s ease;
}

.card-item:hover {
  transform: translateY(-5px);
}

.school-card {
  height: 100%;
  display: flex;
  flex-direction: column;
  transition: all 0.3s ease;
  border-radius: 10px;
  overflow: hidden;
}

.card-hover {
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
}

.tupian {
  width: 100%;
  height: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #f5f7fa;
}

.school-name {
  font-size: 1.1rem;
  font-weight: 600;
  color: #2c3e50;
  margin-bottom: 15px;
  text-align: center;
  display: block;
}

.btn-Apply {
  width: 80%;
  margin: 0 auto;
  transition: all 0.3s ease;
  background: linear-gradient(135deg, #409EFF, #67C23A);
  color: white;
  border: none;
}

.btn-Apply:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(64, 158, 255, 0.3);
}

/* Animations */
.card-list-move,
.card-list-enter-active,
.card-list-leave-active {
  transition: all 0.5s ease;
}

.card-list-enter-from,
.card-list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}

.card-list-leave-active {
  position: absolute;
}

@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes expandLine {
  from {
    width: 0;
  }
  to {
    width: 60%;
  }
}

/* Responsive adjustments */
@media (max-width: 992px) {
  .card-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  }
}

@media (max-width: 768px) {
  .header-section {
    margin-bottom: 20px;
  }

  .search-section {
    flex-direction: column;
    align-items: flex-end;
    gap: 10px;
    padding-right: 20px;
  }

  .search-input {
    width: 100%;
  }

  .card-grid {
    padding: 10px 20px;
  }
}
</style>