<template>
  <div class="student-layout">
    <el-aside class="aside-nav" width="220px">
      <div class="user-profile">
        <div class="avatar-container">
          <el-avatar
              class="user-avatar"
              :size="50"
              :src="circleUrl"
              :fit="cover"
              @mouseenter="showAvatarHover = true"
              @mouseleave="showAvatarHover = false"
          />
          <transition name="fade">
            <div v-if="showAvatarHover" class="avatar-hover">
              <el-icon><Camera /></el-icon>
              <span>Change Avatar</span>
            </div>
          </transition>
        </div>
        <div class="user-info">
          <h3 class="username">{{ name }}</h3>
          <p class="user-role">Student</p>
        </div>
      </div>

      <el-menu
          class="menu-nav"
          router
          :default-active="activePath"
          :collapse-transition="false"
      >
        <el-menu-item
            v-for="route in studentRoutes[0].children"
            :key="route.path"
            :index="route.path"
            :class="{ 'is-active': $route.path === route.path }"
            @mouseenter="handleMenuItemHover(route.path)"
        >
          <el-icon class="menu-icon">
            <component :is="route.meta?.icon || 'Menu'" />
          </el-icon>
          <span class="menu-text">{{ route.meta?.title || route.name }}</span>
          <div class="menu-highlight" :class="{ 'active': $route.path === route.path }"></div>
        </el-menu-item>
      </el-menu>

      <el-button
          class="logout-btn"
          @click="ShowExit"
          @mouseenter="logoutHover = true"
          @mouseleave="logoutHover = false"
      >
        <el-icon class="logout-icon" :class="{ 'hover': logoutHover }">
          <SwitchButton />
        </el-icon>
        <span class="logout-text">Log Out</span>
        <div class="logout-highlight" :class="{ 'hover': logoutHover }"></div>
      </el-button>
    </el-aside>

    <main class="content">
      <router-view v-slot="{ Component }">
        <transition name="fade-slide" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { ElMessage } from "element-plus";
import studentRoutes from '@/router/studentRoutes';
import { Camera, SwitchButton } from '@element-plus/icons-vue';

const route = useRoute();
const router = useRouter();
const name = ref(null);
const showAvatarHover = ref(false);
const logoutHover = ref(false);
const hoveredMenuItem = ref(null);

const activePath = computed(() => route.matched[0].path);

onMounted(() => {
  getName();
});

const getName = () => {
  try {
    const username = localStorage.getItem('name');
    if (!username) {
      return router.replace('/login');
    }
    name.value = username;
  } catch (error) {
    console.error('Failed to get the username:', error);
    router.replace('/login');
  }
};

const HeadUrl = () => {
  const path = localStorage.getItem('path');
  if (!path) return 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png';
  let fullUrl = path.replace(/\\/g, '/');
  return `http://localhost:8082/${fullUrl}`;
};

const circleUrl = computed(() => HeadUrl());

const ShowExit = () => {
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('path');
    router.replace('/');
    ElMessage.success('Logged out successfully');
  } catch (error) {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('path');
    router.replace('/');
  }
};

const handleMenuItemHover = (path) => {
  hoveredMenuItem.value = path;
};
</script>

<style scoped>
.student-layout {
  display: flex;
  min-height: 100vh;
  background-color: #f5f7fa;
}

.aside-nav {
  background: linear-gradient(135deg, #3a7bd5 0%, #00d2ff 100%);
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  width: 220px;
  box-shadow: 4px 0 15px rgba(0, 0, 0, 0.1);
  z-index: 1000;
  display: flex;
  flex-direction: column;
  transition: all 0.3s ease;
}

.content {
  flex-grow: 1;
  padding: 30px;
  margin-left: 220px;
  min-height: 100vh;
  background-color: #f5f7fa;
  transition: margin-left 0.3s ease;
}

.user-profile {
  padding: 25px 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  z-index: 1;
}

.avatar-container {
  position: relative;
  margin-bottom: 15px;
  cursor: pointer;
}

.user-avatar {
  border: 3px solid rgba(255, 255, 255, 0.2);
  transition: all 0.3s ease;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.user-avatar:hover {
  transform: scale(1.05);
  border-color: rgba(255, 255, 255, 0.5);
}

.avatar-hover {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 12px;
}

.avatar-hover .el-icon {
  font-size: 18px;
  margin-bottom: 5px;
}

.user-info {
  text-align: center;
}

.username {
  color: white;
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.user-role {
  color: rgba(255, 255, 255, 0.8);
  margin: 5px 0 0;
  font-size: 13px;
}

.menu-nav {
  flex-grow: 1;
  background: transparent !important;
  border-right: none;
  padding: 0 10px;
  margin-top: 10px;
}

.menu-nav :deep(.el-menu-item) {
  height: 50px;
  line-height: 50px;
  margin: 5px 0;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.8);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(5px);
}

.menu-nav :deep(.el-menu-item:hover) {
  background: rgba(255, 255, 255, 0.2);
  color: white;
}

.menu-nav :deep(.el-menu-item.is-active) {
  background: rgba(255, 255, 255, 0.3);
  color: white;
  font-weight: 500;
}

.menu-icon {
  margin-right: 10px;
  font-size: 18px;
}

.menu-text {
  font-size: 14px;
}

.menu-highlight {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background: white;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.menu-highlight.active {
  transform: translateX(0);
}

.menu-nav :deep(.el-menu-item:hover) .menu-highlight:not(.active) {
  transform: translateX(0);
  opacity: 0.5;
}

.logout-btn {
  margin: 20px 10px;
  height: 50px;
  width: calc(100% - 20px);
  border: none;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.1) !important;
  backdrop-filter: blur(5px);
  color: rgba(255, 255, 255, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 20px;
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
}

.logout-btn:hover {
  background: rgba(255, 255, 255, 0.2) !important;
  color: white;
}

.logout-icon {
  margin-right: 10px;
  font-size: 18px;
  transition: all 0.3s ease;
}

.logout-icon.hover {
  transform: rotate(180deg);
}

.logout-text {
  font-size: 14px;
  flex-grow: 1;
  text-align: left;
}

.logout-highlight {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background: white;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.logout-highlight.hover {
  transform: translateX(0);
}

/* Transition effects */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.fade-slide-enter-active {
  transition: all 0.3s ease-out;
}

.fade-slide-leave-active {
  transition: all 0.2s ease-in;
}

.fade-slide-enter-from {
  opacity: 0;
  transform: translateX(20px);
}

.fade-slide-leave-to {
  opacity: 0;
  transform: translateX(-20px);
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .aside-nav {
    width: 70px;
    overflow: hidden;
  }

  .content {
    margin-left: 70px;
  }

  .user-profile {
    padding: 15px 5px;
  }

  .username, .user-role {
    display: none;
  }

  .menu-text {
    display: none;
  }

  .menu-nav :deep(.el-menu-item) {
    justify-content: center;
  }

  .menu-icon {
    margin-right: 0;
    font-size: 20px;
  }

  .logout-text {
    display: none;
  }

  .logout-btn {
    justify-content: center;
  }

  .logout-icon {
    margin-right: 0;
  }
}
</style>