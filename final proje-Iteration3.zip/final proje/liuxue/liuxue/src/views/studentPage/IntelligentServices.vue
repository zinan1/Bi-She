<template>
  <div class="university-recommender">
    <div class="header">
      <h1 class="title">🎓 University Recommendation Assistant</h1>
      <p class="subtitle">Find the best universities based on your academic background</p>
    </div>

    <div class="chat-container" ref="chatContainer">
      <transition-group name="message" tag="div">
        <div v-for="(message, index) in chatMessages" :key="index"
             :class="['chat-message', message.type]">
          <div v-if="message.type === 'bot'" class="bot-avatar">
            <svg viewBox="0 0 24 24" width="24" height="24">
              <path fill="currentColor" d="M12,2A2,2 0 0,1 14,4C14,4.74 13.6,5.39 13,5.73V7H14A7,7 0 0,1 21,14H22A1,1 0 0,1 23,15V18A1,1 0 0,1 22,19H21V20A2,2 0 0,1 19,22H5A2,2 0 0,1 3,20V19H2A1,1 0 0,1 1,18V15A1,1 0 0,1 2,14H3A7,7 0 0,1 10,7H11V5.73C10.4,5.39 10,4.74 10,4A2,2 0 0,1 12,2M7.5,13A2.5,2.5 0 0,0 5,15.5A2.5,2.5 0 0,0 7.5,18A2.5,2.5 0 0,0 10,15.5A2.5,2.5 0 0,0 7.5,13M16.5,13A2.5,2.5 0 0,0 14,15.5A2.5,2.5 0 0,0 16.5,18A2.5,2.5 0 0,0 19,15.5A2.5,2.5 0 0,0 16.5,13Z" />
            </svg>
          </div>
          <div class="message-content">
            <div class="message-text">{{ message.text }}</div>
            <div v-if="message.type === 'bot' && index === chatMessages.length - 1" class="message-time">
              {{ formatTime(new Date()) }}
            </div>
          </div>
          <div v-if="message.type === 'user'" class="user-avatar">
            <svg viewBox="0 0 24 24" width="24" height="24">
              <path fill="currentColor" d="M12,4A4,4 0 0,1 16,8A4,4 0 0,1 12,12A4,4 0 0,1 8,8A4,4 0 0,1 12,4M12,14C16.42,14 20,15.79 20,18V20H4V18C4,15.79 7.58,14 12,14Z" />
            </svg>
          </div>
        </div>
      </transition-group>
      <div v-if="isLoading" class="typing-indicator">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
      </div>
    </div>

    <div class="search-form fixed-bottom">
      <div class="form-grid">
        <div class="form-group floating">
          <input v-model.number="searchParams.gpa" type="number" id="gpa" step="0.1" min="0" max="4" placeholder=" " required>
          <label for="gpa">GPA</label>
          <div class="input-border"></div>
        </div>

        <div class="form-group floating">
          <input v-model="searchParams.grades" type="text" id="grades" placeholder=" " required>
          <label for="grades">Average Grades</label>
          <div class="input-border"></div>
        </div>

        <div class="form-group floating">
          <input v-model="searchParams.major" type="text" id="major" placeholder=" " required>
          <label for="major">Major</label>
          <div class="input-border"></div>
        </div>

        <div class="form-group floating">
          <input v-model="searchParams.currentSchool" type="text" id="currentSchool" placeholder=" " required>
          <label for="currentSchool">Current School</label>
          <div class="input-border"></div>
        </div>
      </div>

      <div class="action-buttons">
        <button @click="clearForm" class="clear-button" :disabled="isLoading">
          <svg viewBox="0 0 24 24" width="18" height="18">
            <path fill="currentColor" d="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z" />
          </svg>
          Clear
        </button>
        <button @click="getRecommendations" class="search-button" :disabled="isLoading">
          <span v-if="!isLoading">
            <svg viewBox="0 0 24 24" width="18" height="18">
              <path fill="currentColor" d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z" />
            </svg>
            Get Recommendations
          </span>
          <span v-else class="loading-text">
            <svg class="spinner" viewBox="0 0 50 50" width="18" height="18">
              <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
            </svg>
            Searching...
          </span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, watch, nextTick } from 'vue';
import {recommender} from "@/api/studentApi";

const searchParams = reactive({
  gpa: '',
  grades: '',
  major: '',
  currentSchool: ''
});

const chatMessages = ref([
  { type: 'bot', text: 'Hello! I am your university recommendation assistant. I can help you find suitable universities based on your academic background.\n\nPlease provide the following information to get personalized recommendations.' }
]);

const isLoading = ref(false);
const chatContainer = ref(null);

const formatTime = (date) => {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

const scrollToBottom = () => {
  nextTick(() => {
    if (chatContainer.value) {
      chatContainer.value.scrollTop = chatContainer.value.scrollHeight;
    }
  });
};

watch(chatMessages, () => {
  scrollToBottom();
}, { deep: true });

const getRecommendations = async () => {
  // Add user message to chat
  chatMessages.value.push({
    type: 'user',
    text: `GPA: ${searchParams.gpa || 'Not provided'}, Grades: ${searchParams.grades || 'Not provided'}, Major: ${searchParams.major || 'Not provided'}, Current School: ${searchParams.currentSchool || 'Not provided'}`
  });

  isLoading.value = true;

  try {
    // Prepare request parameters
    const paramsToSend = {
      gpa: searchParams.gpa,
      grades: searchParams.grades,
      major: searchParams.major,
      currentSchool: searchParams.currentSchool
    };

    console.log('Sending request with params:', paramsToSend);
    const { data } = await recommender(paramsToSend);

    console.log('Received response data:', data);

    // Add recommendations to chat
    if (data && data.schools && data.schools.length > 0) {
      let message = `🎯 Based on your profile, ${data.message || 'here are our recommendations'}:\n\n`;
      data.schools.forEach((school, index) => {
        message += `🏫 ${index + 1}. ${school.schoolName}\n`;
        message += `📍 Location: ${school.location}\n`;
        message += `📚 About: ${school.description.substring(0, 100)}...\n\n`;
      });

      chatMessages.value.push({
        type: 'bot',
        text: message
      });
    } else {
      chatMessages.value.push({
        type: 'bot',
        text: data?.message || 'No matching universities found. Please try adjusting your search criteria.'
      });
    }
  } catch (error) {
    console.error('Error:', error);
    chatMessages.value.push({
      type: 'bot',
      text: 'Sorry, an error occurred while getting recommendations. Please try again later.'
    });
  } finally {
    isLoading.value = false;
  }
};

// Clear form method
const clearForm = () => {
  if (isLoading.value) return;

  searchParams.gpa = '';
  searchParams.grades = '';
  searchParams.major = '';
  searchParams.currentSchool = '';

  // Add clear confirmation message
  chatMessages.value.push({
    type: 'user',
    text: 'Cleared all search criteria'
  });
};
</script>

<style scoped>
.university-recommender {
  font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  max-width: 1000px;  /* Wider container */
  margin: 0 auto;
  padding: 20px;
  background-color: #f8f9fa;
  border-radius: 16px;
  height: 100vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  position: relative;
}

.header {
  text-align: center;
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

.title {
  font-size: 24px;
  font-weight: 600;
  color: #2c3e50;
  margin-bottom: 5px;
  background: linear-gradient(90deg, #3498db, #2ecc71);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.subtitle {
  font-size: 14px;
  color: #7f8c8d;
  margin: 0;
}

.chat-container {
  background-color: white;
  border-radius: 12px;
  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.05);
  padding: 20px;
  flex-grow: 1;
  overflow-y: auto;
  margin-bottom: 180px; /* Space for fixed form */
  display: flex;
  flex-direction: column;
  gap: 16px;
  scroll-behavior: smooth;
  width: 100%;
}

.chat-message {
  display: flex;
  width: 100%;
  position: relative;
  transition: all 0.3s ease;
  align-items: flex-start;
}

.user {
  justify-content: flex-end;
}

.user .message-content {
  background-color: #007bff;
  color: white;
  border-bottom-right-radius: 4px;
  margin-right: 10px;
}

.bot {
  justify-content: flex-start;
}

.bot .message-content {
  background-color: #f1f3f4;
  color: #202124;
  border-bottom-left-radius: 4px;
  margin-left: 10px;
}

.message-content {
  padding: 14px 18px;
  border-radius: 18px;
  font-size: 15px;
  line-height: 1.5;
  white-space: pre-wrap;
  word-break: break-word;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  max-width: 80%;  /* Wider message bubbles */
}

.user-avatar, .bot-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: 4px;
}

.user-avatar {
  background-color: #e3f2fd;
  color: #007bff;
  order: 1; /* Right side for user */
  margin-left: 10px;
}

.bot-avatar {
  background-color: #f1f3f4;
  color: #5f6368;
  order: -1; /* Left side for bot */
  margin-right: 10px;
}

.message-time {
  font-size: 11px;
  color: #70757a;
  text-align: right;
  margin-top: 4px;
}

.search-form.fixed-bottom {
  position: fixed;
  bottom: 0;
  left: 57%;
  transform: translateX(-50%);
  width: 100%;
  max-width: 1250px;
  background-color: white;
  padding: 15px 20px;
  border-radius: 12px 12px 0 0;
  box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.1);
  z-index: 100;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 12px;
  margin-bottom: 15px;
}

.form-group {
  position: relative;
}

.form-group.floating input {
  width: 100%;
  padding: 16px 12px 6px;
  font-size: 14px;
  border: none;
  border-bottom: 1px solid #ddd;
  background-color: transparent;
  transition: all 0.3s;
}

.form-group.floating input:focus {
  outline: none;
  border-color: transparent;
}

.form-group.floating label {
  position: absolute;
  top: 12px;
  left: 12px;
  color: #999;
  font-size: 14px;
  transition: all 0.3s;
  pointer-events: none;
}

.form-group.floating input:focus + label,
.form-group.floating input:not(:placeholder-shown) + label {
  top: 4px;
  left: 12px;
  font-size: 11px;
  color: #007bff;
}

.input-border {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0;
  height: 2px;
  background-color: #007bff;
  transition: width 0.3s;
}

.form-group.floating input:focus ~ .input-border {
  width: 100%;
}

.action-buttons {
  display: flex;
  gap: 10px;
}

button {
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: all 0.2s;
}

.search-button {
  background-color: #007bff;
  color: white;
  flex: 1;
}

.search-button:hover {
  background-color: #0069d9;
  transform: translateY(-1px);
}

.search-button:disabled {
  background-color: #b3d7ff;
  cursor: not-allowed;
  transform: none;
}

.clear-button {
  background-color: #f8f9fa;
  color: #6c757d;
  border: 1px solid #dee2e6;
}

.clear-button:hover {
  background-color: #e9ecef;
  color: #495057;
}

.clear-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.typing-indicator {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 12px 16px;
  background-color: #f1f3f4;
  border-radius: 18px;
  width: fit-content;
  margin-left: 60px;
  margin-bottom: 8px;
}

.dot {
  width: 8px;
  height: 8px;
  background-color: #5f6368;
  border-radius: 50%;
  animation: typingAnimation 1.4s infinite ease-in-out;
}

.dot:nth-child(1) {
  animation-delay: 0s;
}

.dot:nth-child(2) {
  animation-delay: 0.2s;
}

.dot:nth-child(3) {
  animation-delay: 0.4s;
}

.spinner {
  animation: rotate 2s linear infinite;
}

.spinner .path {
  stroke: white;
  stroke-linecap: round;
  animation: dash 1.5s ease-in-out infinite;
}

.loading-text {
  display: flex;
  align-items: center;
  gap: 6px;
}

.message-enter-active,
.message-leave-active {
  transition: all 0.3s ease;
}

.message-enter-from,
.message-leave-to {
  opacity: 0;
  transform: translateY(10px);
}

@keyframes typingAnimation {
  0%, 60%, 100% {
    transform: translateY(0);
  }
  30% {
    transform: translateY(-5px);
  }
}

@keyframes rotate {
  100% {
    transform: rotate(360deg);
  }
}

@keyframes dash {
  0% {
    stroke-dasharray: 1, 150;
    stroke-dashoffset: 0;
  }
  50% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -35;
  }
  100% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -124;
  }
}

@media (max-width: 1024px) {
  .university-recommender {
    max-width: 95%;
    padding: 15px;
  }

  .search-form.fixed-bottom {
    max-width: 95%;
  }
}

@media (max-width: 768px) {
  .form-grid {
    grid-template-columns: 1fr 1fr;
  }

  .chat-message {
    max-width: 95%;
  }

  .message-content {
    max-width: 75%;
  }
}

@media (max-width: 480px) {
  .form-grid {
    grid-template-columns: 1fr;
  }

  .title {
    font-size: 20px;
  }

  .chat-message {
    gap: 8px;
  }

  .user-avatar, .bot-avatar {
    width: 32px;
    height: 32px;
  }

  .search-form.fixed-bottom {
    padding: 10px 15px;
  }
}
</style>