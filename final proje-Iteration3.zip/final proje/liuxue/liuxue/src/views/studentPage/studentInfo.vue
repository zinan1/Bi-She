<template>
  <div class="personal-info-container">
    <div class="header">
      <h1 class="title">Personal Information</h1>
      <div class="decoration">
        <div class="circle circle-1"></div>
        <div class="circle circle-2"></div>
        <div class="circle circle-3"></div>
      </div>
    </div>

    <div class="info-card">
      <el-descriptions title=" " border :column="2" class="info-descriptions">
        <el-descriptions-item
            :rowspan="2"
            :width="140"
            label="Photo"
            align="center"
        >
          <div class="avatar-container" @mouseenter="showUploadHint = true" @mouseleave="showUploadHint = false">
            <el-image
                style="width: 100px; height: 100px"
                :src="getFullAvatarUrl(studentData.avatar)"
                fit="cover"
                @click="triggerFileInput"
                class="hoverable-image"
            />
            <transition name="fade">
              <div v-if="showUploadHint" class="upload-hint">
                <el-icon><Upload /></el-icon>
                <span>Click to upload</span>
              </div>
            </transition>
            <input
                type="file"
                ref="fileInput"
                style="display: none"
                accept="image/*"
                @change="handleFileChange"
            />
          </div>
        </el-descriptions-item>
        <el-descriptions-item label="ID" align="center">
          <span class="info-value">{{ studentData.id }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="username" align="center">
          <span class="info-value">{{ studentData.studentId }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="Name" align="center">
          <span class="info-value">{{ studentData.name }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="Gender" align="center">
          <span class="info-value">{{ studentData.gender }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="Birth Date" align="center">
          <span class="info-value">{{ studentData.birthDate }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="Contact Phone" align="center">
          <span class="info-value">{{ studentData.contactPhone }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="Contact Email" align="center">
          <span class="info-value">{{ studentData.contactEmail }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="Current School" align="center">
          <span class="info-value">{{ studentData.currentschool }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="Address">
          <span class="info-value">{{ studentData.address }}</span>
        </el-descriptions-item>
      </el-descriptions>

      <div class="edit-btn-container">
        <el-button
            round
            size="large"
            @click="showEdit"
            class="edit-btn"
        >
          <span>Edit Information</span>
          <el-icon class="arrow-icon"><Right /></el-icon>
        </el-button>
      </div>
    </div>

    <el-dialog
        v-model="dialogVisible"
        :title="dialogTitle"
        width="50%"
        align="center"
        class="edit-dialog"
        :close-on-click-modal="false"
    >
      <el-form
          :model="studentForm"
          ref="studentFormRef"
          label-width="120px"
          class="edit-form"
      >
        <el-form-item label="ID" prop="id">
          <el-input v-model="studentForm.id" readonly class="readonly-input"/>
        </el-form-item>
        <el-form-item label="Student ID" prop="studentId">
          <el-input v-model="studentForm.studentId" readonly class="readonly-input"/>
        </el-form-item>
        <el-form-item label="Gender" prop="gender">
          <el-input v-model="studentForm.gender" readonly class="readonly-input"/>
        </el-form-item>
        <el-form-item label="Name" prop="name">
          <el-input v-model="studentForm.name" class="editable-input"/>
        </el-form-item>
        <el-form-item label="Birth Date" prop="birthDate">
          <el-date-picker
              v-model="studentForm.birthDate"
              type="date"
              placeholder="Select birth date"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              style="width: 100%"
              class="editable-input"
          />
        </el-form-item>
        <el-form-item label="Contact Phone" prop="contactPhone">
          <el-input v-model="studentForm.contactPhone" class="editable-input"/>
        </el-form-item>
        <el-form-item label="Contact Email" prop="contactEmail">
          <el-input v-model="studentForm.contactEmail" class="editable-input"/>
        </el-form-item>
        <el-form-item label="Address" prop="address">
          <el-input v-model="studentForm.address" type="textarea" class="editable-input"/>
        </el-form-item>
        <el-form-item label="Current School" prop="currentschool">
          <el-input v-model="studentForm.currentschool" type="textarea" class="editable-input"/>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogVisible = false" class="cancel-btn">Cancel</el-button>
          <el-button type="primary" @click="submitForm" class="confirm-btn">Confirm</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import {editSingleStudentData, SingleStudentData} from "@/api/studentApi";
import {ElMessage, ElMessageBox} from "element-plus";
import { Upload, Right } from '@element-plus/icons-vue'
import axios from "axios";

const fileInput = ref(null);
const loading = ref(false);
const showUploadHint = ref(false);

// Dialog box control
const dialogVisible = ref(false)
const dialogTitle = ref('')
const showName = ref('')

// Form references
const studentFormRef = ref(null)
// Student Form
const studentForm = ref({})

const studentData = ref({
  avatar:'',
  id: '',
  studentId: '',
  name: '',
  gender: '',
  birthDate: '',
  contactPhone: '',
  contactEmail: '',
  address: ''
});

onMounted( ()=>{
  getPersonalData()
})

const getFullAvatarUrl = (relativePath) =>{
  setLocalUrl(relativePath)
  if(!relativePath) return 'http://localhost:8082/avatars/default_school.png';
  let fullUrl = relativePath?.replace(/\\/g, '/');
  console.log(`http://localhost:8082/${fullUrl}`);
  return `http://localhost:8082/${fullUrl}`;
};

const setLocalUrl = (path) => {
  localStorage.setItem('path',path)
}

const triggerFileInput = () => {
  fileInput.value.click();
};

// Handle file selection
const handleFileChange = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  // Checking the file type
  if (!file.type.startsWith('image/')) {
    ElMessage.error('Please select an image file');
    return;
  }

  // file size
  if (file.size > 2 * 1024 * 1024) {
    ElMessage.error('Image size cannot exceed 2MB');
    return;
  }

  try {
    loading.value = true;
    ElMessage.info('Uploading avatar...');

    const token = localStorage.getItem('token')
    // 1. Upload images to the backend
    const formData = new FormData();
    formData.append('file', file);

    const response = await axios.post('http://localhost:8082/api/student/avatar', formData, {
      headers: {
        'Authorization': token,
        'Content-Type': 'multipart/form-data'
      }
    });

    const avatarUrl = response.data?.avatarUrl
    const fullUrl = `${avatarUrl.replace(/\\/g, '/')}`

    studentData.value.avatar = fullUrl
    ElMessage.success('Avatar updated successfully');
    await getPersonalData()
  } catch (error) {
    ElMessage.error('Avatar update failed: ' + error.message);
  } finally {
    loading.value = false;
    // Clear the input so that you can select the same file to upload again
    event.target.value = '';
  }
};

const getPersonalData = async () => {
  try {
    const {data} = await SingleStudentData();
    studentData.value = data;
    showName.value = data.name;
    studentForm.value = {...data}
    console.log(data)
  }catch (error) {
    ElMessage.error('Failed to fetch data');
  }
}

const showEdit = async () =>{
  try {
    await ElMessageBox.confirm('Only these contents can be modified: Name, Birth Date, Contact Phone, Contact Email, Address.', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning',
      customClass: 'custom-message-box'
    })
    dialogTitle.value = showName.value
    dialogVisible.value = true
  } catch (error) {
    ElMessage.info('Canceling changes');
  }
}

const submitForm = async () => {
  try {
    await ElMessageBox.confirm('Confirm to modify personal information!', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning',
      customClass: 'custom-message-box'
    })
    const {data} = await editSingleStudentData(studentForm.value);
    studentData.value = data
    ElMessage.success('Information updated successfully');
    dialogVisible.value = false;
  } catch (error) {
    ElMessage.error('Update failed');
  }
}
</script>

<style scoped>
.personal-info-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 30px;
  position: relative;
}

.header {
  position: relative;
  margin-bottom: 40px;
  text-align: center;
}

.title {
  font-size: 2.2rem;
  color: #333;
  margin-bottom: 20px;
  position: relative;
  display: inline-block;
  padding-bottom: 10px;
}

.title::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 80px;
  height: 3px;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  border-radius: 3px;
}

.decoration {
  position: absolute;
  top: 0;
  right: 0;
  display: flex;
  gap: 10px;
}

.circle {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  opacity: 0.7;
}

.circle-1 {
  background-color: #409EFF;
  animation: float 3s ease-in-out infinite;
}

.circle-2 {
  background-color: #67C23A;
  animation: float 3s ease-in-out infinite 0.5s;
}

.circle-3 {
  background-color: #E6A23C;
  animation: float 3s ease-in-out infinite 1s;
}

@keyframes float {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-15px);
  }
}

.info-card {
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  padding: 30px;
  position: relative;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.info-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
}

.info-descriptions {
  margin-bottom: 30px;
}

.info-descriptions :deep(.el-descriptions__body) {
  background-color: transparent;
}

.info-descriptions :deep(.el-descriptions__label) {
  font-weight: 500;
  color: #555;
}

.info-value {
  font-weight: 400;
  color: #333;
}

.avatar-container {
  position: relative;
  display: inline-block;
}

.hoverable-image {
  transition: all 0.3s ease;
  cursor: pointer;
  border-radius: 8px;
  border: 2px solid #f0f0f0;
}

.hoverable-image:hover {
  transform: scale(1.05);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  border-color: #409EFF;
}

.upload-hint {
  position: absolute;
  bottom: -30px;
  left: 50%;
  transform: translateX(-50%);
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 5px;
}

.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from, .fade-leave-to {
  opacity: 0;
}

.edit-btn-container {
  text-align: right;
  margin-top: 30px;
}

.edit-btn {
  background: linear-gradient(90deg, #409EFF, #67C23A);
  color: white;
  border: none;
  padding: 12px 25px;
  font-weight: 500;
  transition: all 0.3s ease;
  display: inline-flex;
  align-items: center;
  gap: 10px;
}

.edit-btn:hover {
  transform: translateX(5px);
  box-shadow: 0 5px 15px rgba(64, 158, 255, 0.3);
}

.arrow-icon {
  transition: transform 0.3s ease;
}

.edit-btn:hover .arrow-icon {
  transform: translateX(3px);
}

.edit-dialog :deep(.el-dialog__header) {
  border-bottom: 1px solid #eee;
  padding-bottom: 15px;
  margin-bottom: 20px;
}

.edit-dialog :deep(.el-dialog__title) {
  font-size: 1.5rem;
  color: #333;
}

.edit-form {
  padding: 0 20px;
}

.readonly-input :deep(.el-input__inner) {
  background-color: #f5f7fa;
  color: #909399;
  cursor: not-allowed;
}

.editable-input :deep(.el-input__inner) {
  transition: border-color 0.3s ease;
}

.editable-input :deep(.el-input__inner):focus {
  border-color: #409EFF;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}

.dialog-footer {
  display: flex;
  justify-content: center;
  gap: 20px;
}

.cancel-btn {
  padding: 10px 25px;
  transition: all 0.3s ease;
}

.cancel-btn:hover {
  color: #409EFF;
  border-color: #c6e2ff;
  background-color: #ecf5ff;
}

.confirm-btn {
  padding: 10px 25px;
  background: linear-gradient(90deg, #409EFF, #67C23A);
  border: none;
  transition: all 0.3s ease;
}

.confirm-btn:hover {
  opacity: 0.9;
  transform: translateY(-2px);
  box-shadow: 0 5px 10px rgba(64, 158, 255, 0.3);
}
</style>

<style>
.custom-message-box {
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
}

.custom-message-box .el-message-box__header {
  border-bottom: 1px solid #eee;
}

.custom-message-box .el-message-box__content {
  padding: 20px;
}

.custom-message-box .el-message-box__btns {
  justify-content: center;
  gap: 15px;
}
</style>