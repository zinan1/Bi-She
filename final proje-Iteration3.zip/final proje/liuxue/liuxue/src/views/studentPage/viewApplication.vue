<template>
  <div>
    <h1>Individual Application for school</h1>
    <div class="table-container">
      <el-table
          :data="applicationData"
          style="width: 100%"
          stripe
          border
          highlight-current-row
          row-key="id"
      >
        <el-table-column
            label="ID"
            prop="id"
            width="80"
            align="center"
        />
        <el-table-column
            label="Student ID"
            prop="student.studentId"
            width="100"
            align="center"
        />
        <el-table-column
            label="School Name"
            prop="school.schoolName"
            align="center"
        />
        <el-table-column
            label="GPA"
            prop="gpa"
            width="90"
            align="center"
        />
        <el-table-column
            label="Grades"
            prop="grades"
            width="90"
            align="center"
        />
        <el-table-column
            label="Major"
            prop="major"
            width="100"
            align="center"
            show-overflow-tooltip
        />
        <el-table-column
            label="Graduation(Yes or No)"
            prop="enrolled"
            width="85"
            align="center"
        />
        <el-table-column label="Status" prop="status" width="135" align="center">
          <template #default="{ row }">
            <el-tag
                :type="getStatusTagType(row.status)"
                effect="light"
            >
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
            label="Application Date"
            prop="applicationDate"
            width="150"
            align="center"
        />
        <el-table-column
            label="Processed Date"
            prop="processedDate"
            width="150"
            align="center"
        />
      </el-table>
    </div>
  </div>

</template>

<script setup>
import {applicationStudent} from '@/api/applicationApi'
import {ref,onMounted} from "vue";
import {ElMessage} from "element-plus";

const applicationData = ref([])

onMounted(()=>{
  showApplication()
})

const showApplication = async ()=>{
  try {
    const {data} = await applicationStudent()
    applicationData.value = data;
  }catch(error){
    ElMessage.error('Failed to retrieve application data。');
  }
}

const getStatusTagType = (status) => {
  switch (status) {
    case 'APPROVED':
      return 'success';
    case 'REJECTED':
      return 'danger';
    default:
      return 'warning';
  }
}
</script>

<style scoped>
h1{
  text-align: center;
}
</style>