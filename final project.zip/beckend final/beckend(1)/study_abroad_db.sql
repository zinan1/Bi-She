SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- 用户表（users）
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
                         `id` int NOT NULL AUTO_INCREMENT,
                         `login_id` VARCHAR(50) NOT NULL UNIQUE,
                         `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                         `role` enum('STUDENT','SCHOOL','ADMIN') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                         PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- 学生表（students）
-- ----------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
                            `id` int NOT NULL AUTO_INCREMENT,
                            `student_id` varchar(50) NOT NULL,
                            `currentschool` varchar(50) DEFAULT NULL,
                            `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                            `gender` enum('MALE','FEMALE','OTHER') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                            `birth_date` date DEFAULT NULL,
                            `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                            `contact_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                            `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                            `avatar` VARCHAR(255) DEFAULT NULL,
                            PRIMARY KEY (`id`),
                            FOREIGN KEY (`student_id`) REFERENCES `users`(`login_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- 学校表（schools）
-- ----------------------------
DROP TABLE IF EXISTS `schools`;
CREATE TABLE `schools` (
                           `id` int NOT NULL AUTO_INCREMENT,
                           `school_id` varchar(50) NOT NULL,
                           `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                           `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                           `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                           `contact_phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                           `contact_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                           `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                           `avatar` VARCHAR(255) DEFAULT NULL,
                           `applyrequest` varchar(5000) DEFAULT NULL,
                           `majors` JSON,
                           PRIMARY KEY (`id`),
                           FOREIGN KEY (`school_id`) REFERENCES `users`(`login_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- 申请记录表（applications）
-- ----------------------------
DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
                                `id` int NOT NULL AUTO_INCREMENT,
                                `student_id` VARCHAR(50) NOT NULL,
                                `currentschool` VARCHAR(50) DEFAULT NULL,
                                `school_id` VARCHAR(50) NOT NULL,
                                `major` VARCHAR(5000) DEFAULT NULL,
                                `status` enum('PENDING','APPROVED','REJECTED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
                                `application_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
                                `gpa` DOUBLE DEFAULT NULL,
                                `grades` VARCHAR(50) DEFAULT NULL,
                                `enrolled` VARCHAR(50) DEFAULT NULL,
                                `processed_date` timestamp NULL DEFAULT NULL,
                                `application_files` TEXT DEFAULT NULL,
                                `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                                PRIMARY KEY (`id`),
                                INDEX `fk_student_id` (`student_id`),
                                INDEX `fk_school_id` (`school_id`),
                                CONSTRAINT `fk_student_id`
                                    FOREIGN KEY (`student_id`)
                                        REFERENCES `students` (`student_id`)
                                        ON DELETE CASCADE
                                        ON UPDATE CASCADE,
                                CONSTRAINT `fk_school_id`
                                    FOREIGN KEY (`school_id`)
                                        REFERENCES `schools` (`school_id`)
                                        ON DELETE CASCADE
                                        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- 管理员表（admins）
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
                          `id` int NOT NULL,
                          `admin_id` int NOT NULL,
                          `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                          `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                          `contact_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                          PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `login_id`, `password`, `role`)
VALUES (1, 'admin', 'admin123', 'ADMIN');
INSERT INTO `admins` (`id`, `admin_id`, `name`, `contact_phone`, `contact_email`)
VALUES (1, 1, 'Admin', '010-12345678', 'admin@example.com');
SET FOREIGN_KEY_CHECKS = 1;