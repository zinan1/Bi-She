package com.example.studyabroadplatform.model;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;



@Entity
@Table(name = "students")
public class Student implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 主键

    @Column(name = "student_id", nullable = false)
    private String studentId; // 学生ID

    @Column(name = "currentschool")
    private String currentschool;

    @Column(nullable = false, length = 50)
    private String name; // 姓名

    @Enumerated(EnumType.STRING)
    private Gender gender; // 性别

    @Column(name = "birth_date")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate birthDate; // 出生日期

    @Column(name = "contact_phone", length = 20)
    private String contactPhone; // 联系电话

    @Column(name = "contact_email", length = 100)
    private String contactEmail; // 联系邮箱

    @Column
    private String address; // 地址

    @ManyToOne
    @JoinColumn(name = "student_id", referencedColumnName = "login_id", insertable = false, updatable = false)
    private User user;

    @Column(name = "avatar", length = 255)
    private String avatar;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getCurrentschool() {
        return currentschool;
    }

    public void setCurrentschool(String currentschool) {
        this.currentschool = currentschool;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    // 性别枚举
    public enum Gender {
        MALE,
        FEMALE,
        OTHER
    }
}