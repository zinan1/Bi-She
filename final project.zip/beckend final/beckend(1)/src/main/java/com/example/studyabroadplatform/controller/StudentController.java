package com.example.studyabroadplatform.controller;
import com.example.studyabroadplatform.model.Application;
import com.example.studyabroadplatform.model.ApplicationVo;
import com.example.studyabroadplatform.model.School;
import com.example.studyabroadplatform.model.Student;
import com.example.studyabroadplatform.service.ApplicationService;

import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.*;

import com.example.studyabroadplatform.service.SchoolService;
import com.example.studyabroadplatform.service.StudentService;
import com.example.studyabroadplatform.util.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


@RestController
@RequestMapping("/api/student")
public class StudentController {
    @Autowired
    private ApplicationService applicationService;
    
    @Autowired
    private StudentService studentService;

    @Autowired
    private SchoolService schoolService;

    @Autowired
    private JwtUtil jwtUtil;

    
    @PostMapping("/applications")
    public ResponseEntity<?> submitApplication(
            @RequestParam("file") MultipartFile file,
            @RequestParam("applicationData") String applicationDataJson,
            @RequestHeader("Authorization") String token) {
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);
        
        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }
        
        try {
            // 将JSON字符串转换为ApplicationVo对象
            ObjectMapper mapper = new ObjectMapper();
            ApplicationVo vo = mapper.readValue(applicationDataJson, ApplicationVo.class);
            
            // 检查学生是否存在
            Student student = studentService.findByStudentId(vo.getStudent_id());
            if (student == null) {
                throw new RuntimeException("学生不存在");
            }
        
            School school = schoolService.findBySchoolId(vo.getSchool_id());
            if (school == null) {
                throw new RuntimeException("学校不存在");
            }
        
            // 检查该学生是否已有该学校的某专业PENDING申请
            if (applicationService.existsPendingApplication(
                    student.getStudentId(),
                    school.getSchoolId(),
                    vo.getMajor()
            )) {
                throw new RuntimeException("已有待处理请求");
            }
            
            // 处理文件上传
            Path uploadPath = Paths.get("application_files");
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }
            
            // 保存文件
            String originalFilename = file.getOriginalFilename();
            String filename = studentId + "_" + originalFilename;
            Path filePath = uploadPath.resolve(filename);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            
            // 设置学生对象时使用托管实体
            Student managedStudent = studentService.getStudentById(student.getId());
        
            // 设置申请对象
            Application application = new Application();
            application.setStudent(managedStudent);
            application.setSchool(school);
            
            //验证选填专业的正确性
            List<String> schoolMajors = school.getMajors();
            if (schoolMajors == null || !schoolMajors.contains(vo.getMajor())) {
                throw new RuntimeException("所选专业不在该学校提供的专业列表中");
            }
            
            application.setCurrentschool(vo.getCurrentschool());
            application.setMajor(vo.getMajor());
            application.setGpa(vo.getGpa());
            application.setGrades(vo.getGrades());
            application.setEnrolled(vo.getEnrolled());
            application.setStatus("PENDING");
            application.setApplicationDate(LocalDate.now());
            application.setApplicationFiles(Collections.singletonList(filePath.toString()));
            
            Application savedApplication = applicationService.saveApplication(application);
            
            Map<String, Object> response = new HashMap<>();
            response.put("application", savedApplication);
            response.put("filePath", filePath.toString());
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.status(500).body("申请提交失败: " + e.getMessage());
        }
    }

    @PostMapping("/schools/search")
    public ResponseEntity<?> searchSchoolsByMajor(@RequestBody Map<String, String> requestBody, @RequestHeader("Authorization") String token) {
        // 解析Token获取学生ID和角色
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 从请求体中获取专业名称
        String major = requestBody.get("major");
        if (major == null || major.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("专业名称不能为空");
        }

        // 查找包含该专业名称的学校（部分匹配）
        List<School> allSchools = schoolService.findAll();
        List<School> matchedSchools = new ArrayList<>();
        
        for (School school : allSchools) {
            List<String> majors = school.getMajors();
            if (majors != null) {
                for (String schoolMajor : majors) {
                    if (schoolMajor.contains(major)) {
                        matchedSchools.add(school);
                        break; // 找到一个匹配就跳出内循环，避免重复添加
                    }
                }
            }
        }

        // 如果没有找到任何学校，返回空列表和适当的消息
        if (matchedSchools.isEmpty()) {
            Map<String, Object> response = new HashMap<>();
            response.put("schools", matchedSchools);
            response.put("message", "没有找到提供该专业的学校");
            return ResponseEntity.ok(response);
        }

        return ResponseEntity.ok(matchedSchools);
    }
    
    @GetMapping("/applications")
    public List<Application> getStudentApplications(@RequestHeader("Authorization") String token) {
        // 解析Token获取学生ID
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);
    
        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }
    
        // 获取学生的申请记录
        return applicationService.findByStudentId(studentId.toString());
    }

    @GetMapping("/info")
    public ResponseEntity<?> getStudentInfo(@RequestHeader("Authorization") String token) {
        // 解析Token获取学生ID
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 获取学生信息
        Student student = studentService.findByStudentId(studentId);
        if (student == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(student);
    }

    @PutMapping ("/info")
    public ResponseEntity<?> setStudentInfo(@RequestHeader("Authorization") String token,@RequestBody Student updatestudent) {
        // 解析Token获取学生ID
        String studentId = jwtUtil.getLoginIdFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // 验证用户角色
        if (!"STUDENT".equals(role)) {
            throw new RuntimeException("无权限访问");
        }

        // 更新学生信息
        Student student = studentService.findByStudentId(studentId);
        student.setCurrentschool(updatestudent.getCurrentschool());
        student.setName(updatestudent.getName());
        student.setBirthDate(updatestudent.getBirthDate());
        student.setContactPhone(updatestudent.getContactPhone());
        student.setContactEmail(updatestudent.getContactEmail());
        student.setAddress(updatestudent.getAddress());
        studentService.save(student);
        return ResponseEntity.ok(student);
    }

    @PostMapping("/avatar")
    public ResponseEntity<?> uploadAvatar(@RequestParam("file") MultipartFile file, @RequestHeader("Authorization") String token) {
        String studentId = jwtUtil.getLoginIdFromToken(token);
        try {
            // 创建存储目录
            Path uploadPath = Paths.get("avatars");
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            // 保存文件
            String filename = studentId + "." + 
                    file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
            Path filePath = uploadPath.resolve(filename);
            
            // 覆盖已存在的文件
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);


            // 更新数据库
            Student student = studentService.findByStudentId(studentId);
            student.setAvatar(filePath.toString());
            studentService.save(student);

            Map<String, String> responseMap = new HashMap<>();
            responseMap.put("avatarUrl", filePath.toString());
            return ResponseEntity.ok(responseMap);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("文件上传失败");
        }
    }
}