package com.example.studyabroadplatform.model;

import java.util.List;

public class ApplicationVo {
    private String student_id;
    private String school_id;
    private String currentschool;
    private Double gpa;
    private String grades;
    private String enrolled;
    private String major;
    private List<String> applicationFiles; // 添加文件路径列表

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    public String getCurrentschool() {
        return currentschool;
    }

    public void setCurrentschool(String currentschool) {
        this.currentschool = currentschool;
    }

    public Double getGpa() {
        return gpa;
    }

    public void setGpa(Double gpa) {
        this.gpa = gpa;
    }

    public String getGrades() {
        return grades;
    }

    public void setGrades(String grades) {
        this.grades = grades;
    }

    public String getEnrolled() {
        return enrolled;
    }

    public void setEnrolled(String enrolled) {
        this.enrolled = enrolled;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }
    
    public List<String> getApplicationFiles() {
        return applicationFiles;
    }

    public void setApplicationFiles(List<String> applicationFiles) {
        this.applicationFiles = applicationFiles;
    }
}
