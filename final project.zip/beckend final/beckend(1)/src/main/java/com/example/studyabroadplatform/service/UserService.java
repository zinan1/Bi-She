package com.example.studyabroadplatform.service;
import com.example.studyabroadplatform.model.User;
import com.example.studyabroadplatform.repository.StudentRepository;
import com.example.studyabroadplatform.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

}
