package com.example.studyabroadplatform.model;
import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "users")
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "login_id",nullable = false, unique = true)
    private String loginId;
    
    @Column(name = "password",nullable = false)
    private String password;
    
    @Column(name = "role",nullable = false)
    private String role; // STUDENT, SCHOOL, ADMIN
    
    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId (String loginId) {
        this.loginId = loginId;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}