package com.example.studyabroadplatform.model;
import com.example.studyabroadplatform.converter.StringListConverter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;



@Entity
@Table(name = "schools")
public class School implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 主键

    @Column(name = "school_id", nullable = false)
    private String schoolId; //学校ID

    @Column(name = "name")
    private String schoolName;

    @Column(name = "location")
    private String location;

    @Column(name = "description")
    private String description;

    @Column(name = "contact_phone")
    private String contactPhone;

    @Column(name = "contact_email")
    private String contactEmail ;

    @Column(name = "website")
    private String website;

    @Column(name = "applyrequest")
    private String applyrequest;

    @Column(name = "majors", columnDefinition = "TEXT")
    @Convert(converter = StringListConverter.class)
    private List<String> majors;

    @ManyToOne
    @JoinColumn(name = "school_id", referencedColumnName = "Login_id", insertable = false, updatable = false)
    private User user;

    @Column(name = "avatar", length = 255)
    private String avatar;

    // Getters and Setters

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getSchoolId() {
        return schoolId;
    }
    public void setSchoolId(String schoolId) {
        this.schoolId = schoolId;
    }

    public String getSchoolName() {
        return schoolName;
    }
    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }

    public String getContactEmail() {
        return contactEmail;
    }
    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactPhone() {
        return contactPhone;
    }
    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getWebsite() {
        return website;
    }
    public void setWebsite(String website) {
        this.website = website;
    }

    public String getApplyrequest() {
        return applyrequest;
    }

    public void setApplyrequest(String applyrequest) {
        this.applyrequest = applyrequest;
    }

    public List<String> getMajors() {
        return majors;
    }

    public void setMajors(List<String> majors) {
        this.majors = majors;
    }

    public User getUser() {return user;}
    public void setUser(User user) {this.user = user;}

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }
}