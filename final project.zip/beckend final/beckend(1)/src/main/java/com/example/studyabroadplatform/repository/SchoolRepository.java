package com.example.studyabroadplatform.repository;
import com.example.studyabroadplatform.model.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {
    Optional<School> findBySchoolId(String schoolId);

    @Modifying
    @Query(value = "DELETE FROM school_majors WHERE school_id = ?1", nativeQuery = true)
    void deleteMajorsBySchoolId(String schoolId);

    @Modifying
    @Query(value = "INSERT INTO school_majors (school_id, major) VALUES (?1, ?2)", nativeQuery = true)
    void insertMajor(String schoolId, String major);

    default void insertMajors(String schoolId, List<String> majors) {
        majors.forEach(m -> insertMajor(schoolId, m));
    }
}