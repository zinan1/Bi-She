package com.example.studyabroadplatform.service;
import com.example.studyabroadplatform.model.Application;
import com.example.studyabroadplatform.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ApplicationService {
    @Autowired
    private ApplicationRepository applicationRepository;

    public Application saveApplication(Application application) {
        return applicationRepository.save(application);
    }

    public List<Application> findAll() {
        return applicationRepository.findAll();
    }

    public Application findById(Long id) {
        return applicationRepository.findById(id).orElse(null);
    }

    public List<Application> findBySchoolId(String schoolId) {
        return applicationRepository.findBySchoolSchoolId(schoolId);
    }

    public List<Application> findByStudentId(String studentId) {
        return applicationRepository.findByStudentStudentId(studentId);
    }

    public boolean existsPendingApplication(String studentId, String schoolId,String major) {
        return applicationRepository.existsByStudentStudentIdAndSchoolSchoolIdAndMajorAndStatus(
                studentId,
                schoolId,
                major,
                "PENDING"
        );
    }
}