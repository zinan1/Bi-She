import type { RouteRecordRaw } from 'vue-router';

const schoolRoutes: Array<RouteRecordRaw> = [
    {
        path: '/schoolPage',
        name:'School',
        redirect:'/schoolPage/schoolInfo',
        component: () => import('../views/schoolPage/school.vue'),
        children:[
            {
                path: '/schoolPage/schoolInfo',
                name: 'School Home',
                component:() => import('../views/schoolPage/schoolInfo.vue')
            },
            {
                path: '/schoolPage/viewStudentApplication',
                name: 'View Student Application',
                component:() => import('../views/schoolPage/viewStudentApplication.vue')
            },
            {
                path:'/schoolPage/schoolResetPassword',
                name:'School Reset Password',
                component:() => import('../views/schoolPage/schoolResetPassword.vue')
            }
        ]
    }
]

export default schoolRoutes;