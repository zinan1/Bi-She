import type { RouteRecordRaw } from 'vue-router';

const studentRoutes: Array<RouteRecordRaw> = [
    {
        path: '/studentPage',
        name:'Student',
        redirect:'/studentPage/studentInfo',
        component: () => import('../views/studentPage/student.vue'),
        children:[
            {
                path:'/studentPage/studentInfo',
                name:'Student Home',
                component:()=>import('../views/studentPage/studentInfo.vue')
            },
            {
                path:'/studentPage/ViewAllSchool',
                name:'View All School',
                component:()=>import('../views/studentPage/ViewAllSchool.vue')
            },
            {
                path:'/studentPage/viewApplication',
                name:'View Application',
                component:()=>import('../views/studentPage/viewApplication.vue')
            },
            {
                path: '/studentPage/studentResetPassword',
                name: 'Student Reset Password',
                component: () => import('../views/studentPage/studentResetPassword.vue')
            },
            {
                path: '/studentPage/helpInfo',
                name: 'Help Information',
                component: () => import('../views/studentPage/helpInfo.vue')
            }
        ]
    }
];
export default studentRoutes;