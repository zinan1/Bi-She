import { createApp } from 'vue'
import App from './App.vue'
import './registerServiceWorker'
import router from './router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'


const  app = createApp(App)

window.addEventListener('error', function(e) {
    if (e.message && /ResizeObserver/.test(e.message)) {
        e.preventDefault();
        e.stopImmediatePropagation();
        return false;
    }
});

app.use(router)
app.use(ElementPlus)
app.mount('#app')

