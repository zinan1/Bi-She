<template>
  <div class="login-container">
    <div class="login-box">
      <el-form
          :model="loginForm"
          ref="loginFormRef"
          class="login-form"
      >
        <el-form-item class="form-group" prop="username">
          <el-input
              v-model="loginForm.loginId"
              placeholder="username"
              prefix-icon="User"
          />
        </el-form-item>

        <el-form-item class="form-group" prop="password">
          <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="password"
              prefix-icon="Lock"
              show-password
          />
        </el-form-item>
        <el-form-item class="form-group" prop="role" required>
          <el-select v-model="loginForm.role" placeholder="Select Identity">
            <el-option label="STUDENT" value="STUDENT" />
            <el-option label="SCHOOL" value="SCHOOL" />
            <el-option label="ADMIN" value="ADMIN" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button
              type="primary"
              @click="handleLogin"
              class="login-btn"
              :loading="loading"
          >
            Login
          </el-button>
        </el-form-item>
      </el-form>
      <div class="switch-auth">
        <router-link to="/resetPassword">
          <el-button  class="auth-link">Password Reset</el-button>
        </router-link>
        <el-button  class="auth-link" @click="studentRegisterForm">Student Register</el-button>
        <el-button  class="auth-link" @click="schoolRegisterForm">School Register</el-button>
      </div>
      <el-dialog v-model="dialogVisible" width="50%">
        <template #header>
          <div style="text-align: center">
            <span class="el-dialog__title">Student</span>
          </div>
        </template>
        <el-form
            :model="studentForm"
            ref="studentFormRef"
            label-width="120px"
        >
          <el-form-item label="username" prop="loginId" required>
            <el-input v-model="studentForm.loginId" />
          </el-form-item>
          <el-form-item label="password" prop="password" required>
            <el-input v-model="studentForm.password" />
          </el-form-item>
          <el-form-item label="Name" prop="name" required>
            <el-input v-model="studentForm.name" />
          </el-form-item>
          <el-form-item label="Gender" prop="gender" required>
            <el-select v-model="studentForm.gender" placeholder="Select gender">
              <el-option label="MALE" value="MALE" />
              <el-option label="FEMALE" value="FEMALE" />
              <el-option label="OTHER" value="OTHER" />
            </el-select>
          </el-form-item>
          <el-form-item label="Birth Date" prop="birthDate">
            <el-date-picker
                v-model="studentForm.birthDate"
                type="date"
                placeholder="Select birth date"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                style="width: 100%"
            />
          </el-form-item>
          <el-form-item label="Contact Phone" prop="contactPhone">
            <el-input v-model="studentForm.contactPhone" />
          </el-form-item>
          <el-form-item label="Contact Email" prop="contactEmail">
            <el-input v-model="studentForm.contactEmail" />
          </el-form-item>
          <el-form-item label="Address" prop="address">
            <el-input v-model="studentForm.address" type="textarea" />
          </el-form-item>
          <el-form-item label="Current School" prop="currentschool">
            <el-input v-model="studentForm.currentschool" type="textarea" />
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitStudentForm">Confirm</el-button>
        </template>
      </el-dialog>
      <el-dialog v-model="schoolDialog" width="50%">
        <template #header>
          <div style="text-align: center">
            <span class="el-dialog__title">School</span>
          </div>
        </template>
        <el-form
            ref="schoolForm"
            :model="school"
            label-width="120px"
            label-position="right"
        >
          <el-form-item label="username" prop="loginId" required>
            <el-input v-model="school.loginId" />
          </el-form-item>
          <el-form-item label="password" prop="password" required>
            <el-input v-model="school.password" />
          </el-form-item>

          <el-form-item label="School Name" prop="schoolName">
            <el-input v-model="school.schoolName" />
          </el-form-item>

          <el-form-item label="Location" prop="location">
            <el-input v-model="school.location" />
          </el-form-item>

          <el-form-item label="Description" prop="description">
            <el-input
                v-model="school.description"
                type="textarea"
                :rows="2"
            />
          </el-form-item>
          <el-form-item label="Majors" prop="majors">
            <el-input
                v-model="school.majors"
                type="textarea"
                :rows="2"
            />
            <div class="majors-hint">
              Enter a major, separated by commas or Spaces (e.g., XX College-XX Department-XX Major.)
            </div>
          </el-form-item>

          <el-form-item label="Contact Phone" prop="contactPhone">
            <el-input v-model="school.contactPhone" />
          </el-form-item>

          <el-form-item label="Contact Email" prop="contactEmail">
            <el-input v-model="school.contactEmail" />
          </el-form-item>

          <el-form-item label="Website" prop="website">
            <el-input v-model="school.website" />
          </el-form-item>
          <el-form-item label="Apply request" prop="applyrequest">
            <el-input v-model="school.applyrequest" />
          </el-form-item>
        </el-form>

        <template #footer>
        <span class="dialog-footer">
          <el-button @click="schoolDialog = false">Cancel</el-button>
          <el-button type="primary" @click="submitSchoolForm">Confirm</el-button>
        </span>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { ref} from 'vue'
import { useRouter} from 'vue-router'
import {ElMessage, ElMessageBox} from 'element-plus'
import {LoginData,RegisterData} from "@/api/loginApi";
import cookie from 'js-cookie'

const router = useRouter()
// Dialog box control
const dialogVisible =ref(false);
const schoolDialog =ref(false);
// Form references
const studentFormRef = ref(null)
const schoolForm = ref(null)
// Student Form
const studentForm = ref({
  loginId: '',
  password: '',
  role: 'STUDENT',
  name: '',
  gender: '',
  birthDate: '',
  contactPhone: '',
  contactEmail: '',
  address: '',
  currentschool:''
})

const school = ref({
  id: '',
  schoolId: '',
  role: 'SCHOOL',
  schoolName: '',
  location: '',
  majors:'',
  description: '',
  contactPhone: '',
  contactEmail: '',
  website: '',
  applyrequest:''
});

// data
const loginForm = ref({
  username: '',
  password: '',
  role: ''
})

const loading = ref(false)
const loginFormRef = ref(null)

// Login handling
const handleLogin = async () => {
  const {loginId,password,role} = loginForm.value
  if (!loginId?.trim() || !password?.trim()) {
    ElMessage.error('Username and password are required!');
  }else {
    switch (role){
      case 'STUDENT':
        try {
          const { data: studentResp } = await LoginData(loginForm.value);
          const { user,token } = studentResp;
          getLocalStorage(user.loginId, token,user.role);
          ElMessage.success('Student login success')
          await router.push('/studentPage')
        } catch (error) {
          ElMessage.error('Input error, please enter the correct content!');
        }
        break;
      case 'SCHOOL':
        try {
          const { data: schoolResp } = await LoginData(loginForm.value);
          const { user,token } = schoolResp;
          getLocalStorage(user.loginId, token,user.role);
          ElMessage.success('School login success')
          await router.push('/schoolPage')
        }catch (error) {
          ElMessage.error('Input error, please enter the correct content!');
        }
        break;
      case 'ADMIN':
        try {
          const { data: adminResp } = await LoginData(loginForm.value);
          const { user,token } = adminResp;
          getLocalStorage(user.loginId, token,user.role);
          ElMessage.success('Admin login success')
          await router.push('/adminPage')
        }catch (error) {
          ElMessage.error('Input error, please enter the correct content!');
        }
        break;
      case '':
        ElMessage.error('Please select identity!');
        break;
    }
  }
}
//学生注册
const studentRegisterForm = async ()=>{
  try {
    await ElMessageBox.confirm('Attention please!  Students are not allowed to change their username and gender once they are registered.', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    studentFormRef.value?.resetFields()
    dialogVisible.value = true
  } catch (error) {
    ElMessage.info('Cancel registration');
  }
}

const submitStudentForm = async ()=>{
  try {
    console.log(studentForm.value)
    await RegisterData(studentForm.value)
    ElMessage.success('Student Registration Success')
    dialogVisible.value = false;
  }catch (error){
    ElMessage.error('Student Registration Failed.');
  }
}
//学校注册
const schoolRegisterForm = async () => {

  try {
    await ElMessageBox.confirm('Attention please! username cannot be changed after school registration.', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    schoolForm.value?.resetFields()
    schoolDialog.value = true;
  } catch (error) {
    ElMessage.info('Cancel registration');
  }
}
const submitSchoolForm = async ()=>{
  try {
    //Split by commas or Spaces, and remove whitespace characters
    const majorsArray = school.value.majors?.split(/[,，]/)?.map(item => item.trim())?.filter(item => item !== '');

    //Construct commit data
    const payload = {
      ...school.value,
      majors: majorsArray
    };

    await RegisterData(payload)
    ElMessage.success('School Registration Success')
    schoolDialog.value = false;
  }catch (error) {
    ElMessage.error('School Registration Failed.');
  }
}

//本地存储
const getLocalStorage = (name,token,role)=>{
  localStorage.setItem('name',name);
  localStorage.setItem('token',token);
  localStorage.setItem('role',role);
}

</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 90vh;
}

.login-box {
  width: 400px;
  padding: 40px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}


.login-form {
  width: 100%;
  max-width: 400px;
  margin: 0 auto;
}
.form-group {
  margin-bottom: 20px;
  width: 100%;
}
.el-form-item__content {
  width: 100%;
  display: flex !important;
}

.login-btn {
  width: 100%;
  margin-top: 10px;
  box-sizing: border-box;
  display: block;
  transition: all 0.3s;
  margin-left: 0px;
}

.login-links a {
  color: #666;
  text-decoration: none;
  font-size: 14px;
}

.login-links a:hover {
  color: #409eff;
}
.switch-auth {
  display: flex;
  gap: 5px;
  margin-left: -8px;
}
.auth-link {
  margin-left: 2px;
}
.majors-hint{
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

</style>