import request from "@/utils/axios";

export const LoginData = (loginForm)=>{
    return request({
        url:'/api/auth/login',
        method:'post',
        data:loginForm
    })
}
export const RegisterData = (studentForm)=>{
    return request({
        url:'/api/auth/register',
        method:'post',
        data:studentForm
    })
}

export const ResetPassword = (studentForm)=>{
    return request({
        url:'/api/auth/resetPassword',
        method:'post',
        data:studentForm
    })
}