// src/api/schoolApi.d.ts
import request from "@/utils/axios";

//String concatenation should use backquotes, not single quotes.
// get data
export const getSchoolData = () => {
    return request({
        url:'/api/admin/schools ',
        method:'get'
    });
};

//School Enquiry
export const getSchoolById = (id) => {
    return request({
        url: `/api/admin/schools/${id}`,
        method: 'get'
    });
};

//add school
export const addSchoolData = (School) => {
    return request({
        url:'/api/admin/schools ',
        method:'post',
        data:School
    });
};

// edit school
export const editSchoolData = (id,data) => {
    return request({
        url: `/api/admin/schools/${id}`,
        method: 'put',
        data:data
    });
};

//delete school
export const deleteSchoolData = (id) => {
    return request({
        url: `/api/admin/schools/${id}`,
        method: 'delete'
    });
};

//Get individual school information
export const SingleSchoolData = ()=>{
    return request({
        url:'/api/school/info',
        method:'get'
    });
};

//Modify individual school information
export const editSingleSchoolData = (data)=>{
    return request({
        url:'/api/school/info',
        method:'put',
        data
    });
};

//Add the school image function
export const addSchoolPhoto = (formData)=>{
    return request({
        url:'/api/school/avatar',
        method:'post',
        formData
    });
};

//Backing up data
export const databaseBackup = () => {
    return request({
        url:'/api/admin/database/backup',
        method:'post'
    })
};

//Recovering data
export const databaseRestore = (data) => {
    return request({
        url:'/api/admin/database/restore',
        method:'post',
        data
    })
}

