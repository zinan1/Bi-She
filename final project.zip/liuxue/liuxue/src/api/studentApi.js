import request from "@/utils/axios";

//String concatenation should use backquotes, not single quotes.
// get data
export const getStudentData = () => {
    return request.get('/api/admin/students');
};
//Enquiring about students
export const getStudentById = (id) => {
    return request.get(`/api/admin/students/${id}`)
};
//add student
export const addStudentData = (Student) => {
    return request.post('/api/admin/students',Student);
};
// edit student
export const editStudentData = (id, data) => {
    return request({
        url: `/api/admin/students/${id}`,
        method: 'put',
        data: data
    });
};

//delete student
export const deleteStudentData = (id) => {
    return request.delete(`/api/admin/students/${id}`);
};

//Obtaining Personal Information
export const SingleStudentData = ()=>{
    return request({
        url:'/api/student/info',
        method:'get'
    });
};
//Modification of Personal Information
export const editSingleStudentData = (data)=>{
    return request({
        url:'/api/student/info',
        method:'put',
        data
    });
};
//Add the student image function
export const addStudentPhoto = (file)=>{
    return request({
        url:'/api/student/avatar',
        method:'post',
        file
    });
};

//Students search for schools with that major
export const studentSearchMajors = (majors) => {
    return request({
        url:'/api/student/schools/search',
        method:'post',
        data:majors
    })
}
