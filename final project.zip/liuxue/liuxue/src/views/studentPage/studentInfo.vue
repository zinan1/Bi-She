<template>
  <div>
    <div>
      <h1>Personal Information</h1>
    </div>
    <div>
      <el-descriptions title=" "  border>
        <el-descriptions-item
            :rowspan="2"
            :width="140"
            label="Photo"
            align="center"
        >
          <el-image
              style="width: 100px; height: 100px"
              :src="getFullAvatarUrl(studentData.avatar)"
              fit="cover"
              @click="triggerFileInput"
              class="hoverable-image"
          />
          <input
              type="file"
              ref="fileInput"
              style="display: none"
              accept="image/*"
              @change="handleFileChange"
          />
        </el-descriptions-item>
        <el-descriptions-item label="ID" align="center">
          {{ studentData.id }}
        </el-descriptions-item>
        <el-descriptions-item label="username" align="center">
          {{ studentData.studentId }}
        </el-descriptions-item>
        <el-descriptions-item label="Name" align="center">
          {{ studentData.name }}
        </el-descriptions-item>
        <el-descriptions-item label="Gender" align="center">
          {{ studentData.gender }}
        </el-descriptions-item>
        <el-descriptions-item label="Birth Date" align="center">
          {{ studentData.birthDate }}
        </el-descriptions-item>
        <el-descriptions-item label="Contact Phone" align="center">
          {{ studentData.contactPhone }}
        </el-descriptions-item>
        <el-descriptions-item label="Contact Email" align="center">
          {{ studentData.contactEmail }}
        </el-descriptions-item>
        <el-descriptions-item label="Current School" align="center">
          {{ studentData.currentschool }}
        </el-descriptions-item>
        <el-descriptions-item label="Address" >
          {{ studentData.address }}
        </el-descriptions-item>
      </el-descriptions>
    </div>
    <div class="show-btn" style="position: absolute; right: 30px; margin-top: 50px;" >
      Change student information →
      <el-button round size="large" @click="showEdit">
        Edit
      </el-button>
    </div>
    <div>
      <el-dialog
          v-model="dialogVisible"
          :title="dialogTitle"
          width="50%"
          align="center"
      >
        <el-form
            :model="studentForm"
            ref="studentFormRef"
            label-width="120px"
        >
          <el-form-item label="ID" prop="id">
            <el-input v-model="studentForm.id" readonly/>
          </el-form-item>
          <el-form-item label="Student ID" prop="studentId">
            <el-input v-model="studentForm.studentId" readonly/>
          </el-form-item>
          <el-form-item label="Gender" prop="gender">
            <el-input v-model="studentForm.gender" readonly/>
          </el-form-item>
          <el-form-item label="Name" prop="name" >
            <el-input v-model="studentForm.name" />
          </el-form-item>
          <el-form-item label="Birth Date" prop="birthDate">
            <el-date-picker
                v-model="studentForm.birthDate"
                type="date"
                placeholder="Select birth date"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                style="width: 100%"
            />
          </el-form-item>
          <el-form-item label="Contact Phone" prop="contactPhone">
            <el-input v-model="studentForm.contactPhone" />
          </el-form-item>
          <el-form-item label="Contact Email" prop="contactEmail">
            <el-input v-model="studentForm.contactEmail" />
          </el-form-item>
          <el-form-item label="Address" prop="address">
            <el-input v-model="studentForm.address" type="textarea" />
          </el-form-item>
          <el-form-item label="Current School" prop="currentschool">
            <el-input v-model="studentForm.currentschool" type="textarea" />
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitForm">Confirm</el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import {editSingleStudentData, SingleStudentData} from "@/api/studentApi";
import {ElMessage, ElMessageBox} from "element-plus";
import {addSchoolPhoto} from "@/api/schoolApi";
import axios from "axios";

const fileInput = ref(null);
const loading = ref(false);
// Dialog box control
const dialogVisible = ref(false)
const dialogTitle = ref('')
const showName = ref('')
// Form references
const studentFormRef = ref(null)
// Student Form
const studentForm = ref({})

const studentData = ref({
  avatar:'',
  id: '',
  studentId: '',
  name: '',
  gender: '',
  birthDate: '',
  contactPhone: '',
  contactEmail: '',
  address: ''
});

onMounted( ()=>{
  getPersonalData()
})

const getFullAvatarUrl = (relativePath) =>{
  setLocalUrl(relativePath)
  if(!relativePath) return 'http://localhost:8082/avatars/default_school.png';
  let fullUrl = relativePath?.replace(/\\/g, '/');
  console.log(`http://localhost:8082/${fullUrl}`);
  return `http://localhost:8082/${fullUrl}`;
};

const setLocalUrl = (path) => {
  localStorage.setItem('path',path)
}

const triggerFileInput = () => {
  fileInput.value.click();
};

// 处理文件选择
const handleFileChange = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  // Checking the file type
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请选择图片文件');
    return;
  }

  // file size
  if (file.size > 2 * 1024 * 1024) {
    ElMessage.error('Images cannot exceed 2MB in size');
    return;
  }

  try {
    loading.value = true;

    const token = localStorage.getItem('token')
    // 1. Upload images to the backend
    const formData = new FormData();
    formData.append('file', file);

    const response = await axios.post('http://localhost:8082/api/student/avatar', formData, {
      headers: {
        'Authorization': token,
        'Content-Type': 'multipart/form-data'
      }
    });

    console.log(response)
    const avatarUrl = response.data?.avatarUrl
    const fullUrl = `${avatarUrl.replace(/\\/g, '/')}`

    studentData.value.avatar = fullUrl
    ElMessage.success('Avatar updated successfully');
    await getPersonalData()
  } catch (error) {
    ElMessage.error('Avatar update failed: ' + error.message);
  } finally {
    loading.value = false;
    // Clear the input so that you can select the same file to upload again
    event.target.value = '';
  }
};

const getPersonalData = async () => {
  try {
    const {data} = await SingleStudentData();
    studentData.value = data;
    showName.value = data.name;
    studentForm.value = {...data}
    console.log(data)
  }catch (error) {
    ElMessage.error('Failed to fetch data');
  }
}

const showEdit = async () =>{
  try {
    await ElMessageBox.confirm('Only these contents can be modified: Name, Birth Date, Contact Phone, Contact Email, Address.', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    dialogTitle.value = showName.value
    dialogVisible.value = true
  } catch (error) {
    ElMessage.info('Canceling changes');
  }
}

const submitForm = async () => {
  try {
    await ElMessageBox.confirm('Confirm to modify personal information!', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    const {data} = await editSingleStudentData(studentForm.value);
    studentData.value = data
    ElMessage.success('Change success');
    dialogVisible.value = false;
  } catch (error) {
    ElMessage.error('Change failed');
  }
}

</script>

<style scoped>
h1{
  text-align: center;
}
.hoverable-image {
  transition: transform 0.3s ease;
  cursor: pointer;
}

.hoverable-image:hover {
  transform: scale(1.05);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}
</style>