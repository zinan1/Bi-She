<template>
  <div class="student-layout">
    <el-aside class="aside-nav" width="200px">
      <div class="block">
        <el-avatar class="qiuqiu" :size="40" :src="circleUrl" />
        <span class="username">{{ name }}</span>
      </div>
      <el-menu class="menu-nav" router :default-active="activePath" >
        <el-menu-item
            v-for="route in studentRoutes[0].children"
            :key="route.path"
            :index="route.path"
            :class="{ 'is-active': $route.path === route.path }"
        >
          <span>{{ route.meta?.title || route.name }}</span>
        </el-menu-item>
      </el-menu>
      <el-button class="border-top-bottom" >
        <span @click="ShowExit" >Exit</span>
      </el-button>
    </el-aside>
    <main class="content">
      <router-view></router-view>
    </main>
  </div>
</template>

<script  setup>
import studentRoutes from '@/router/studentRoutes';
import {computed, onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import router from "@/router";
import {ElMessage} from "element-plus";

const route = useRoute();
const name = ref(null)


const activePath = computed(() => route.matched[0].path);

onMounted(()=>{
  getName();
})
const getName = () => {
  try {
    const username = localStorage.getItem('name');
    if (!username) {
      return router.replace('/login');
    }
    name.value = username;
  } catch (error) {
    console.error('Failed to get the username:', error);
    router.replace('/login');
  }
};

const HeadUrl = () =>{
  const path = localStorage.getItem('path')
  if (!path) return 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png';
  let fullUrl = path.replace(/\\/g, '/');
  return `http://localhost:8082/${fullUrl}`;
}

const circleUrl = computed(() => HeadUrl())

const ShowExit = ()=>{
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('path');
    router.replace('/');
    ElMessage.success('Exited safely');
  } catch (error) {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('path');
    router.replace('/');
  }
}

</script>

<style scoped>
.student-layout {
  display: flex;
  min-height: 100vh;
}
.aside-nav {
  background-image: url('~@/assets/nav.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  position: fixed;  /* 修改为 fixed 定位 */
  left: 0;
  top: 0;
  bottom: 0;
  width: 200px;  /* 保持与 el-aside 的 width 属性一致 */
  border-right: 1px solid #e6e6e6;
  box-sizing: border-box;
  z-index: 1000;  /* 确保导航栏在内容上方 */
}

.content {
  flex-grow: 1;
  padding: 20px;
  margin-left: 200px;  /* 添加左边距避开侧边栏 */
  width: calc(100% - 200px);  /* 计算剩余宽度 */
}

.el-menu-item {
  border-bottom: 1px solid #f0f0f0;
}
.student-layout {
  display: flex;
}
.content {
  flex-grow: 1;
  padding: 20px;
}

.is-active {
  color: #409eff;
}

.block {
  margin-left: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
  flex: 1;
  margin-top: 15px;
  margin-bottom: 15px;
}
.border-top-bottom {
  border-left: none !important;
  border-right: none !important;
  border-top: 1px solid #DCDFE6 !important;
  border-bottom: 1px solid #DCDFE6 !important;
  border-radius: 0 !important;
}
.el-button, .el-button.is-round {
  padding: 8px 15px;
  width: 330px;
  height: 55px;
  margin-left: -132px;
  background: rgba(255, 255, 255, 0.1) !important;
  backdrop-filter: blur(8px);
  border-right: none;
  flex-grow: 1;
}
.menu-nav{
  background: rgba(255, 255, 255, 0.1) !important;
  backdrop-filter: blur(8px);
  border-right: none;
  flex-grow: 1;
}
</style>