<template>
  <div>
    <div class="tiaoti-btn">
      <h1>All School Information</h1>
    </div>
    <div class="btn-container">
      <el-input
          class="search-input"
          v-model="searchSchoolId"
          placeholder="Search school ID or major"
          @keyup.enter="schoolSearch"
      ></el-input>
      <el-button
          class="search-btn"
          type="primary"
          :icon="Search"
          @click="schoolSearch"
      >Search</el-button>
    </div>
    <div class="cards-container">
      <div v-for="item in schoolList" :key="item.id" class="card-item">
        <el-card border>
          <!-- Image display -->
          <div class="tupian">
            <el-image
                style="width: 100px; height: 100px"
                :src="getFullAvatarUrl(item.avatar)"
                fit="cover"
            />
          </div>
          <template #footer>
            <!-- Name of school -->
            <span class="school-name">{{item.id}} {{ item.schoolName }}</span>
            <el-button
                class="btn-Apply"
                size="small"
                round
                @click="showApply(item)"
            >
              Open: School Details
            </el-button>
          </template>
        </el-card>
      </div>
      <el-dialog
          v-model="dialogVisible"
          :title="currentSchool?.schoolName"
          width="55%"
      >
        <el-form
            ref="schoolForm"
            :model="formData"
            label-width="120px"
            label-position="right"
        >
          <el-form-item label="ID">
            {{formData.id}}
          </el-form-item>
          <el-form-item label="School ID">
            {{formData.schoolId}}
          </el-form-item>
          <el-form-item label="School Name" >
            {{formData.schoolName}}
          </el-form-item>

          <el-form-item label="Location" >
            {{formData.location}}
          </el-form-item>

          <el-form-item label="Description" >
            {{formData.description}}
          </el-form-item>

          <el-form-item label="Contact Phone">
            {{formData.contactPhone}}
          </el-form-item>

          <el-form-item label="Contact Email">
            {{formData.contactEmail}}
          </el-form-item>

          <el-form-item label="Website" >
            {{formData.website}}
          </el-form-item>
          <el-form-item label="Apply Request" >
            {{formData.applyrequest}}
          </el-form-item>
          <el-form-item label="Optional major">
            <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            <span v-for="(major, index) in formData.majors" :key="index" style="margin-right: 8px;">
              {{ major }}
            </span>
            </div>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogVisible = false">Cancel</el-button>
            <el-button type="primary" @click="ApplySchool">Apply School</el-button>
          </span>
        </template>
      </el-dialog>
      <el-dialog
          v-model="applyDialogVisible"
          :title="currentSchool?.schoolName"
          width="50%"
          class="center-title-dialog"
          @closed="resetForm"
      >
        <el-form
            ref="studentFormRef"
            :model="student"
            :rules="studentApplicationFormRules"
            label-width="175px"
        >
          <el-form-item label="Student ID" prop="student_id" required>
            <el-input v-model="student.student_id" />
          </el-form-item>
          <el-form-item label="GPA" prop="gpa" required>
            <el-input v-model="student.gpa" />
          </el-form-item>
          <el-form-item label="Grades" prop="grades" required>
            <el-input v-model="student.grades" />
          </el-form-item>
          <el-form-item label="Current School" prop="currentschool" required>
            <el-input v-model="student.currentschool" />
          </el-form-item>
          <el-form-item label="Major" prop="major" required>
            <el-select
                v-model="student.major"
                placeholder="Please select a major"
                style="width: 100%"
            >
              <el-option
                  v-for="(major, index) in currentSchool?.majors || []"
                  :key="index"
                  :label="major"
                  :value="major"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="Graduation(Yes or No)" prop="enrolled" required>
            <el-select v-model="student.enrolled">
              <el-option label="YES" value="YES" />
              <el-option label="NO" value="NO" />
            </el-select>
          </el-form-item>
          <el-form-item label="Application Files" prop="applicationFiles">
            <input
                type="file"
                ref="fileInput"
                style="display: none"
                @change="handleFileChange"
            />
            <el-button type="primary" @click.prevent="triggerFileInput">
              Upload application documents
            </el-button>
            <p v-if="selectedFile" style="margin-top: 10px;margin-left: 20px;">Selected: {{ selectedFile.name }}</p>
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="applyDialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitForm">Confirm</el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import {getSchoolData, getSchoolById} from '@/api/schoolApi';
import {ref, onMounted, onUnmounted} from "vue";
import {studentApplication} from "@/api/applicationApi";
import {ElMessage} from "element-plus";
import { Search } from '@element-plus/icons-vue';
import { debounce } from 'lodash';
import {studentSearchMajors} from "@/api/studentApi";

//Storing a list of schools
const schoolList = ref([]);

//School details dialog box
const dialogVisible = ref(false)
const currentSchool = ref(null);
const formData = ref({});

//Request dialog box
const applyDialogVisible = ref(false)
const studentFormRef = ref(null)

//Search box
const searchSchoolId = ref('')

// Stores the files selected by the user
const fileInput = ref(null);
const selectedFile = ref(null);

//Initialize the student application information
const student = ref({
  student_id:'',
  school_id:'',
  gpa:'',
  grades:'',
  currentschool:'',
  major:'',
  enrolled:'',
});

//Getting school data
const loadSchoolData = async () => {
  try {
    const { data } = await getSchoolData();
    console.log(data);
    schoolList.value = data || [];
  } catch (error) {
    console.error('Failed to fetch school data:', error);
    schoolList.value = [];
  }
};

onMounted(()=>{
  loadSchoolData()
})

// Validation rules
const studentApplicationFormRules = {
  student_id: [
    { required: true, message: 'The Student ID cannot be null', trigger: ['blur', 'change'] },
  ],
  gpa: [
    { required: true, message: 'The GPA cannot be null', trigger: ['blur', 'change'] }
  ],
  grades: [
    { required: true, message: 'The grade cannot be null', trigger: ['blur', 'change'] },
  ],
  major: [
    { required: true, message: 'Please select a major', trigger: 'blur' }
  ],
}

const resetForm = () => {
  // Resetting form data
  Object.assign(student, {
    student_id: '',
    gpa: '',
    grades: '',
    major:'',
    enrolled: ''
  })

  selectedFile.value = null;
  if (fileInput.value) {
    fileInput.value.value = '';
  }
  // Clear validation state
  studentFormRef.value?.resetFields()

}
const showApply = (item) => {
  try {
    console.log(item?.majors)
    const { schoolId } = item;
    student.value.school_id = schoolId;
    currentSchool.value = item;
    formData.value = { ...item };
    dialogVisible.value = true;
  }catch (error){
    console.log('Failed to open the request dialog box')
  }
}

const ApplySchool = () => {
  dialogVisible.value = false;
  applyDialogVisible.value = true;
}

// Add a file selection handler
const handleFileChange = (e) => {
  const files = e.target.files;
  if (files && files.length > 0) {
    selectedFile.value = files[0];
  } else {
    selectedFile.value = null;
  }
};

const submitForm = async () => {
    try {
      console.log(student.value)
      await studentFormRef.value?.validate();

      if (!selectedFile.value) {
        ElMessage.warning('Please upload the application documents');
        return;
      }

      const formData = new FormData();
      // add data
      formData.append('file', selectedFile.value);
      formData.append('applicationData', JSON.stringify(student.value));

      await studentApplication(formData);
      ElMessage.success('Application submitted successfully');
      applyDialogVisible.value = false;
    }catch (error){
      console.error('Validation failure:', error);
    }
}

const schoolSearch = debounce( async () =>{
  if (!searchSchoolId.value) {
    await loadSchoolData()
    return;
  }
  try {
    const isSchoolId = /^\d+$/.test(searchSchoolId.value);
    if(isSchoolId){
      const res = await getSchoolById(searchSchoolId.value)
      schoolList.value = res.data ? [res.data] : []
      if (schoolList.value.length === 0) {
        ElMessage.warning('The school information was not found')
      }
    }else{
      const searchData = {major: searchSchoolId.value};
      const res = await studentSearchMajors(searchData);
      if (res.data.message) {
        ElMessage.warning('No school was found to offer this major')
        return;
      }
      schoolList.value = res.data || [];
    }
  } catch (error) {
    ElMessage.error('Search failure: Without this school,' )
    schoolList.value = []
  }
},500)

const getFullAvatarUrl = (path) => {
  const BaseUrl = 'http://localhost:8082';
  switch (path) {
    case '/avatars/default_school.png':
      return `${BaseUrl}/avatars/default_school.png`;
    default:
      const fullUrl = `${path?.replace(/\\/g, '/')}`
        console.log(`${BaseUrl}/${fullUrl}`)
      return `${BaseUrl}/${fullUrl}`;
  }
}

const triggerFileInput = (e) => {
  e?.preventDefault(); // 添加这行确保阻止默认行为
  fileInput.value.click();
};

onUnmounted(() => {
  schoolSearch?.cancel();
});
</script>

<style scoped>
.tiaoti-btn{
  text-align: center;
}
.btn-container {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 8px;
  margin-right: 33px;
}
.search-input {
  width: 200px;
}

.search-btn{
  width: 130px;
}

.cards-container {
  display: flex;
  flex-wrap: wrap;
  gap: 70px;
  justify-content: flex-start;
  padding: 30px;
}


.card-item {
  flex: 0 0 calc(33.333% - 20px);
  max-width: 350px;
  min-width: 300px;
}

.tupian {
  width: 100%;
  height: 200px;
  position: relative;
  overflow: hidden;
}

.school-name {
  display: block;
  margin-bottom: 10px;
}

.btn-Apply {
  border: none !important;
  margin-left: -10px;
}
:deep(.el-dialog__header) {
  text-align: center;
}
:deep(.el-dialog__footer) {
  text-align: center;
  padding: 16px 20px;
}
:deep(.el-dialog__footer .el-button) {
  margin: 0 30px;
  min-width: 100px;
}
:deep(.el-image) {
  width: 100% !important;
  height: 100% !important;
  display: block !important;
}

:deep(.el-image__inner) {
  width: 100% !important;
  height: 100% !important;
  object-fit: cover !important;
}
</style>