<template xmlns="http://www.w3.org/1999/html">
  <div>
    <el-card class="reset-card">
        <div class="student-reset-container">
          <el-form
              ref="studentResetFormRef"
              :model="studentResetForm"
              :rules="studentFormRules"
              label-position="top"
              @submit.prevent="submitForm"
          >
            <el-form-item>
              <h2 >Password Reset</h2>
            </el-form-item>
            <el-form-item label="Username" prop="loginId">
              <el-input
                  v-model="studentResetForm.loginId"
                  placeholder="Enter your username"
                  prefix-icon="User"
                  clearable
              />
            </el-form-item>
            <el-form-item label="Identity" prop="role">
              <el-select
                  v-model="studentResetForm.role"
                  placeholder="Select your identity"
                  style="width: 100%"
              >
                <el-option label="Student" value="STUDENT" />
                <el-option label="School" value="SCHOOL" />
              </el-select>
            </el-form-item>

            <el-form-item label="New Password" prop="newPassword">
              <el-input
                  v-model="studentResetForm.newPassword"
                  type="password"
                  placeholder="Enter new password"
                  autocomplete="new-password"
                  prefix-icon="Lock"
                  show-password
                  clearable
              />
              <div class="password-hint">
                Password must be 6-20 characters, containing letters and numbers
              </div>
            </el-form-item>
            <el-form-item label="Confirm Password" prop="confirmPassword">
              <el-input
                  v-model="studentResetForm.confirmPassword"
                  type="password"
                  placeholder="Confirm your new password"
                  autocomplete="new-password"
                  prefix-icon="Lock"
                  show-password
                  clearable
              />
            </el-form-item>
            <el-form-item>
              <el-button
                  type="primary"
                  native-type="submit"
                  :loading="submitting"
                  class="submit-btn"
              >
                Reset Password
              </el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-card>
  </div>
</template>
<script setup>
import { reactive, ref } from 'vue'
import { ResetPassword } from "@/api/loginApi"
import { useRouter } from 'vue-router'
import {ElMessage, ElMessageBox} from 'element-plus'

const router = useRouter()
const studentResetFormRef = ref(null)
const submitting = ref(false)

const studentResetForm = reactive({
  loginId: '',
  role: '',
  newPassword: '',
  confirmPassword: ''
})

// password rule
const validatePassword = (rule, value, callback) => {
  if (!value) {
    callback(new Error('Please input password'))
  } else if (value.length < 6 || value.length > 20) {
    callback(new Error('Password length should be 6-20 characters'))
  } else if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) {
    callback(new Error('Password must contain both letters and numbers'))
  } else {
    callback()
  }
}

// Confirm password validation
const validateConfirmPassword = (rule, value, callback) => {
  if (!value) {
    callback(new Error('Please confirm your password'))
  } else if (value !== studentResetForm.newPassword) {
    callback(new Error('Two passwords do not match!'))
  } else {
    callback()
  }
}

const studentFormRules = reactive({
  loginId: [
    { required: true, message: 'Please input username', trigger: 'blur' },
    { min: 3, max: 16, message: 'Length should be 4-16 characters', trigger: 'blur' }
  ],
  role: [
    { required: true, message: 'Please select identity', trigger: 'change' }
  ],
  newPassword: [
    { required: true, validator: validatePassword, trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, validator: validateConfirmPassword, trigger: 'blur' }
  ]
})

const submitForm = async () => {
  try {
    await ElMessageBox.confirm('Confirm to modify student information!', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    const valid = await studentResetFormRef.value.validate()
    if (!valid){
      ElMessage.warning("Please check the input input")
    } else {
      submitting.value = true
      await ResetPassword(studentResetForm)
      ElMessage.success('Password reset successfully')
      await router.push('/login')
    }
  } catch (error) {
    ElMessage.info('Quitting the change')
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.student-reset-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 97vh;
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}
.reset-card {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 70vh;
  padding: 30px;
  border-radius: 8px;
  border: 1px solid #ebeef5;
}

.submit-btn {
  width: 100%;
  margin-top: 10px;
}
.password-hint {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
:deep(.el-form-item__label) {
  font-weight: 500;
}
</style>