<template>
  <div class="faq-container">
    <h1 class="faq-title">Study Abroad Application Help Center</h1>

    <!-- Application Process Related -->
    <el-collapse v-model="activeNames" accordion>
      <el-collapse-item name="1" title="I. Application Process Related">
        <div class="faq-section">
          <h3>Application Timeline</h3>
          <div class="faq-item">
            <div class="question">Q: When should I start preparing my study abroad application?</div>
            <div class="answer">A: Begin preparations one year in advance. For Fall 2026 admission, start in Fall 2025.</div>
          </div>

          <h3>Application Materials</h3>
          <div class="faq-item">
            <div class="question">Q: What materials are needed for study abroad applications?</div>
            <div class="answer">
              A:
              <ul>
                <li><strong>Basic Materials</strong>: Personal Statement, Recommendation Letters (2-3), Academic Transcripts</li>
                <li><strong>Language Tests</strong>: IELTS, TOEFL, GRE, etc. (varies by target country and program)</li>
                <li><strong>Additional Materials</strong>: Portfolio (for arts programs), Resume, Research Proposal, etc.</li>
              </ul>
            </div>
          </div>

          <h3>Application System</h3>
          <div class="faq-item">
            <div class="question">Q: How to use the application system?</div>
            <div class="answer">A: Create account → Fill in personal and application information → Upload documents → Review and submit</div>
          </div>
        </div>
      </el-collapse-item>

      <!-- University and Program Selection -->
      <el-collapse-item name="2" title="II. University and Program Selection">
        <div class="faq-section">
          <h3>Program Selection</h3>
          <div class="faq-item">
            <div class="question">Q: How should I choose my study abroad program?</div>
            <div class="answer">A: Consider your interests, career goals, and employment prospects. Choose a program that aligns with both your passions and professional objectives.</div>
          </div>

          <h3>University Rankings</h3>
          <div class="faq-item">
            <div class="question">Q: Should I always choose higher ranked universities?</div>
            <div class="answer">A: Rankings matter, but also consider the university's specialized programs, location, and cultural environment.</div>
          </div>
        </div>
      </el-collapse-item>

      <!-- Language Tests Related -->
      <el-collapse-item name="3" title="III. Language Tests Related">
        <div class="faq-section">
          <h3>Test Preparation</h3>
          <div class="faq-item">
            <div class="question">Q: How to prepare for IELTS or TOEFL?</div>
            <div class="answer">
              A: Build vocabulary, familiarize yourself with test formats, practice with past papers, and consider preparatory courses or online resources.
            </div>
          </div>

          <h3>Score Requirements</h3>
          <div class="faq-item">
            <div class="question">Q: What are the language requirements for studying abroad?</div>
            <div class="answer">
              A:
              <ul>
                <li><strong>UK</strong>: Undergraduate IELTS 6.0-6.5, Graduate 6.5-7.0</li>
                <li><strong>USA</strong>: Undergraduate TOEFL 80-100, Graduate around 100</li>
                <li>Specific requirements vary by institution and program</li>
              </ul>
            </div>
          </div>
        </div>
      </el-collapse-item>

      <!-- Visa Application Related -->
      <el-collapse-item name="4" title="IV. Visa Application Related">
        <div class="faq-section">
          <h3>Visa Documentation</h3>
          <div class="faq-item">
            <div class="question">Q: What documents are needed for a student visa?</div>
            <div class="answer">
              A: Valid passport, visa photos, admission letter, financial proof, academic transcripts, etc. Required documents vary by country.
            </div>
          </div>

          <h3>Visa Interview</h3>
          <div class="faq-item">
            <div class="question">Q: What questions are asked during student visa interviews?</div>
            <div class="answer">A: Questions about study plans, financial sources, etc. Prepare honest, logical answers in advance and maintain confidence and politeness.</div>
          </div>
        </div>
      </el-collapse-item>
    </el-collapse>
  </div>
</template>

<script setup>
import { ref } from 'vue';

// Controls the expansion item of the accordion panel
const activeNames = ref(['1']);
</script>

<style scoped>
.faq-container {
  max-width: 1000px;
  margin: 0 auto;
  padding: 30px 20px;
}

.faq-title {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
  font-size: 28px;
}

.faq-section {
  padding: 0 15px;
}

.faq-item {
  margin-bottom: 20px;
  padding: 15px;
  background-color: #f9f9f9;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.faq-item:hover {
  background-color: #f0f0f0;
  transform: translateY(-2px);
}

.question {
  font-weight: bold;
  color: #1890ff;
  margin-bottom: 8px;
  font-size: 16px;
}

.answer {
  color: #666;
  line-height: 1.6;
}

h3 {
  color: #444;
  margin: 25px 0 15px;
  padding-bottom: 8px;
  border-bottom: 1px solid #eee;
}

:deep(.el-collapse-item__header) {
  font-size: 18px;
  font-weight: bold;
  padding-left: 10px;
}

:deep(.el-collapse-item__content) {
  padding-bottom: 0;
}

ul {
  padding-left: 20px;
  margin: 10px 0;
}

li {
  margin-bottom: 5px;
}
</style>