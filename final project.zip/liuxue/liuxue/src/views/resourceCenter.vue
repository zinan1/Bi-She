<template>
  <div>
    <div class="resource-container">
      <nav class="main-nav" :class="{ 'nav-hidden': !showNav }">
        <div class="nav-container">
          <router-link to="/" class="nav-item">Home</router-link>
          <router-link to="/resourceCenter" class="nav-item">Cultural Exchange</router-link>
          <router-link to="/login" class="nav-item">Login</router-link>
        </div>
      </nav>
      <div class="BlankSpace-container"></div>
      <div class="culture-container">
        <div class="culture-header">
          <h1>Experience the beauty of Chinese culture</h1>
          <p class="subtitle">Explore the profoundness of Chinese culture and discover the unique charm of studying in China.</p>
        </div>

        <div class="culture-stats">
          <div class="stat-item">
            <div class="stat-number">5000+</div>
            <div class="stat-desc">Long history</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">Numerous</div>
            <div class="stat-desc">Cultural heritages</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">56</div>
            <div class="stat-desc">Ethnic groups</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">Diverse</div>
            <div class="stat-desc">Cultural activities</div>
          </div>
        </div>
      </div>
    </div>
    <div class="show-culture-container">
      <div class="tupian-image"></div>
      <div class="culture-content">
        <h2 class="H2title">Inheriting the Essence of Chinese Culture</h2>
        <h3 class="H3-subtitle">Promoting Cultural Exchange and Understanding</h3>

        <div class="description">
          <p>We are committed to providing international students with a platform to understand and experience Chinese culture, helping them better integrate into Chinese society.</p>
          <p>Through in-depth cultural introductions and exchange activities, we aim to promote mutual understanding and friendship among students from different cultural backgrounds.</p>
          <p>We believe that cultural exchange is an important way to enhance international cooperation and friendship, and is also key to cultivating talents with a global vision.</p>
        </div>

        <table class="stats-table">
          <thead>
          <tr>
            <th>Starting Year</th>
            <th>Cultural Events</th>
            <th>Partner Universities</th>
            <th>Participating Students</th>
          </tr>
          </thead>
          <tbody>
          <tr>
            <td>2025</td>
            <td>50+</td>
            <td>20+</td>
            <td>5000+</td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
    <!-- New Culture Exploration Sections -->
    <div class="culture-exploration">
      <h2 class="exploration-title">Explore Chinese Culture Themes</h2>

      <div class="exploration-grid">
        <div class="exploration-card" :style="{ backgroundImage: `url(${require('@/assets/home6.png')})` }">
          <div class="card-content">
            <h3>Traditional Festivals</h3>
            <p>Learn about the history and cultural significance of Chinese traditional festivals</p>
          </div>
        </div>

        <div class="exploration-card" :style="{ backgroundImage: `url(${require('@/assets/home7.png')})` }">
          <div class="card-content">
            <h3>Chinese Art</h3>
            <p>Appreciate the charm of Chinese painting, calligraphy, ceramics, and other arts</p>
          </div>
        </div>

        <div class="exploration-card" :style="{ backgroundImage: `url(${require('@/assets/home8.png')})` }">
          <div class="card-content">
            <h3>Chinese Cuisine</h3>
            <p>Taste the local specialties from different regions of China and experience the flavors of China</p>
          </div>
        </div>

        <div class="exploration-card" :style="{ backgroundImage: `url(${require('@/assets/home9.png')})` }">
          <div class="card-content">
            <h3>Urban Landscapes</h3>
            <p>Explore the history, culture, and modern development of different Chinese cities</p>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer -->
    <footer class="main-footer">
      <div class="footer-content">
        <p class="copyright">© 2025 International Student University Selection System</p>
        <p class="authors">Authors: Yangming Qin; Zian Yu; Zhongyuan Ren</p>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';

// 导航栏显示控制
const showNav = ref(true);
let lastScrollPosition = 0;

const handleScroll = () => {
  const currentScrollPosition = window.pageYOffset || document.documentElement.scrollTop;

  // 向下滚动且超过一定距离时隐藏导航栏
  if (currentScrollPosition > lastScrollPosition && currentScrollPosition > 100) {
    showNav.value = false;
  }
  // 向上滚动时显示导航栏
  else if (currentScrollPosition < lastScrollPosition) {
    showNav.value = true;
  }

  lastScrollPosition = currentScrollPosition;
};

onMounted(() => {
  window.addEventListener('scroll', handleScroll);
});

onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll);
});

</script>

<style scoped>
/* Navigation bar styles */
.main-nav {
  position: fixed;
  top: 0;
  left: 8px;
  right: 8px;
  background-color: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(5px);
  box-shadow: 0 2px 15px rgba(0, 0, 0, 0.3);
  z-index: 1000;
  transition: all 0.3s ease;
}

.nav-container {
  display: flex;
  justify-content: center;
  max-width: 1200px;
  margin: 0 auto;
  padding: 15px 20px;
}

.nav-item {
  padding: 12px 25px;
  color: white;
  text-decoration: none;
  font-size: 16px;
  font-weight: 500;
  transition: all 0.3s ease;
  position: relative;
  opacity: 0.9;
}

.nav-item:hover {
  color: #fff;
  opacity: 1;
  text-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
}

.nav-item::after {
  content: '';
  position: absolute;
  bottom: 8px;
  left: 25px;
  right: 25px;
  height: 2px;
  background-color: white;
  transform: scaleX(0);
  transition: transform 0.3s ease;
}

.nav-item:hover::after {
  transform: scaleX(1);
}

.nav-hidden {
  transform: translateY(-100%);
  opacity: 0;
}

@media (max-width: 768px) {
  .nav-container {
    padding: 10px 5px;
  }

  .nav-item {
    padding: 10px 15px;
    font-size: 14px;
  }
}
.resource-container {
  margin-top: 70px;
  background-image: url('~@/assets/home2.png');
  background-size: cover;
  background-position: center;
}
.BlankSpace-container{
  width: 100%;
  height: 10px;
}
.culture-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 40px 20px;
  text-align: center;
}

.culture-header h1 {
  font-size: 2.5rem;
  color: white;
  margin-bottom: 20px;
}

.subtitle {
  font-size: 1.2rem;
  color: white;
  margin-bottom: 50px;
}

.culture-stats {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: 30px;
}

.stat-item {
  flex: 1;
  min-width: 200px;
  padding: 20px;
  background-color: #f9f9f9;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  background-repeat: no-repeat;
  display: block;
  opacity: 0.6;
  border-radius: 100px 100px 100px 100px;
}

.stat-number {
  font-size: 2.2rem;
  font-weight: bold;
  color: #e74c3c;
  margin-bottom: 10px;
}

.stat-desc {
  font-size: 1.1rem;
  color: #555;
}

/* For the last item where the order is different */
.stat-item:last-child .stat-number {
  order: 2;
  margin-top: 10px;
  margin-bottom: 0;
}

.stat-item:last-child .stat-desc {
  order: 1;
  margin-bottom: 10px;
}

@media (max-width: 768px) {
  .culture-stats {
    flex-direction: column;
  }

  .stat-item {
    min-width: 100%;
  }
}
.show-culture-container {
  display: flex;
  height: 400px;
  justify-content: space-between;
  align-items: center;
  padding: 2rem;
  background-color: #ffca80;
}
.tupian-image{
  width: 500px;
  background-image: url('~@/assets/home5.png');
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  min-height: 300px;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  display: block;
  opacity: 0.5;
  border-radius: 100px 100px 100px 100px;
}
.culture-content {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 8px;
  opacity: 0.5;
}

/* Culture exploration section */
.culture-exploration {
  padding: 3rem 2rem;
  max-width: 1500px;
  margin: 0 auto;
  background-image: url('~@/assets/home1.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

.exploration-title {
  text-align: center;
  font-size: 2rem;
  color: #333;
  margin-bottom: 2rem;
}

.exploration-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.exploration-card {
  height: 300px;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  border-radius: 8px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.exploration-card:hover {
  transform: translateY(-5px);
}

.card-content {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 1.5rem;
  background: linear-gradient(to top, rgba(0, 0, 0, 0.7), transparent);
  color: white;
}



/* Responsive adjustments */
@media (max-width: 768px) {
  .exploration-grid {
    grid-template-columns: 1fr;
  }

  .exploration-card {
    height: 250px;
  }
}
/* Footer styles */
.main-footer {
  background-color: #000;
  color: #fff;
  padding: 30px 0;
  text-align: center;
  font-size: 14px;
}

.footer-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.copyright {
  margin-bottom: 10px;
  color: rgba(255, 255, 255, 0.8);
}

.authors {
  color: rgba(255, 255, 255, 0.6);
  font-size: 13px;
}

@media (max-width: 768px) {
  .main-footer {
    padding: 20px 0;
  }

  .copyright, .authors {
    font-size: 12px;
  }
}
</style>