<template>
  <div class="app-container">
    <div class="header-container">
      <div class="total-count">Total number of school: {{ total }}</div>
      <div class="search-container">
        <el-input
            class="search-input"
            v-model="searchSchoolId"
            placeholder="Please enter ID"
            @keyup.enter="schoolSearch"
        ></el-input>
        <el-button
            class="search-btn"
            type="primary"
            :icon="Search"
            @click="schoolSearch"
        >Search</el-button>
      </div>
    </div>
    <div class="table-container">
      <el-table
          :data="schoolData"
          style="width: 100%"
          v-loading="loading"
          stripe
          border
          highlight-current-row
      >
        <el-table-column
            label="ID"
            prop="id"
            width="80"
            align="center"
        />
        <el-table-column
            label="School ID"
            prop="schoolId"
            width="100"
            align="center"
        />
        <el-table-column
            label="School Name"
            prop="schoolName"
            width="135"
            align="center"
        />
        <el-table-column
            label="Location"
            prop="location"
            width="150"
            align="center"
        />
        <el-table-column
            label="Description"
            prop="description"
            width="150"
            align="center"
        />
        <el-table-column
            label="Contact Phone"
            prop="contactPhone"
            width="150" 
            align="center"
        />
        <el-table-column
            label="Contact Email"
            prop="contactEmail"
            align="center"
            show-overflow-tooltip
        />
        <el-table-column
            label="Website"
            prop="website"
            align="center"
            show-overflow-tooltip
        />
        <el-table-column
            label="Apply Request"
            prop="applyrequest"
            align="center"
            show-overflow-tooltip
        />
        <el-table-column label="Operations" width="150">
          <template #default="{ row }">
            <el-button
                size="small"
                type="info"
                @click="showEdit(row)"
            >
              Detail
            </el-button>
            <el-button
                size="small"
                type="danger"
                @click="showDelete(row)"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="school-pagination-block" v-if="showPaginated">
      <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20]"
          :background="background"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
      />
      <div class="data-backup">
        <div class="operation-buttons">
          <el-button
              type="primary"
              @click="showBackup"
              :loading="backupLoading"
          >
            Data backup
          </el-button>
          <el-button
              type="warning"
              @click="showRestore"
              :loading="restoreLoading"
          >
            Data recovery
          </el-button>
        </div>
      </div>
    </div>
    <el-dialog
        v-model="dialogVisible"
        width="30%"
    >
      <template #header>
        <div style="text-align: center">
          <span class="el-dialog__title">View School</span>
        </div>
      </template>
      <el-form
          ref="schoolForm"
          :model="school"
          label-width="120px"
          label-position="right"
      >
        <el-form-item label="ID" prop="id">
          {{school.id}}
        </el-form-item>

        <el-form-item label="School ID" prop="schoolId">
          {{school.schoolId}}
        </el-form-item>

        <el-form-item label="School Name" prop="schoolName">
          {{school.schoolName}}
        </el-form-item>

        <el-form-item label="Location" prop="location">
          {{school.location}}
        </el-form-item>

        <el-form-item label="Description" prop="description">
          {{school.description}}
        </el-form-item>

        <el-form-item label="Contact Phone" prop="contactPhone">
          {{school.contactPhone}}
        </el-form-item>

        <el-form-item label="Contact Email" prop="contactEmail">
          {{school.contactEmail}}
        </el-form-item>

        <el-form-item label="Website" prop="website">
          {{school.website}}
        </el-form-item>

        <el-form-item label="Apply Request" prop="applyrequest">
          {{school.applyrequest}}
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="dialogVisible = false">Confirm</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import {getSchoolData, getSchoolById, deleteSchoolData, databaseBackup, databaseRestore} from '@/api/schoolApi';
import {computed, onMounted, onUnmounted, ref, watch} from "vue";
import { Search } from '@element-plus/icons-vue';
import {ElMessage, ElMessageBox} from 'element-plus';
import { debounce } from 'lodash';

// data
const schoolData = ref([])
const searchSchoolId = ref('')
const loading = ref(true);

// Pagination related
const currentPage = ref(1);
const pageSize = ref(10);
const total = ref(0);
const background = ref(true);
const allSchoolData = ref([])

const dialogVisible =ref(false);
//Backup and restore
const backupLoading = ref(false)
const restoreLoading = ref(false)


const school = ref({
  id:'',
  schoolId: '',
  schoolName: '',
  location: '',
  description: '',
  contactPhone: '',
  contactEmail: '',
  website: ''
});

onMounted(() => {
  showSchools();
});

const updatePaginatedData = () => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  schoolData.value = allSchoolData.value.slice(start, end)
}

const showPaginated = computed(() => {
  return searchSchoolId.value ? '' : showSchools()
})

const showSchools = async () => {
  loading.value = true;
  try {
    const resp = await getSchoolData();
    allSchoolData.value = resp.data;
    total.value = allSchoolData.value.length;
    updatePaginatedData()
  } catch (error) {
    console.error('Request failed:', error);
  }finally {
    loading.value = false;
  }
}

const schoolSearch = debounce( async () =>{
  if (!searchSchoolId.value) {
    await showSchools()
    return
  }
  try {
    const res = await getSchoolById(searchSchoolId.value)
    schoolData.value = res.data ? [res.data] : []
    if (schoolData.value.length === 0) {
      ElMessage.warning('The school information was not found')
    }
  } catch (error) {
    ElMessage.error('Search failure: Without this school,' + error.message)
    schoolData.value = []
  }
},500)

const showEdit = async (row)=>{
  try {
    school.value = { ...row };
    dialogVisible.value = true
  }catch (error){
    console.log('Viewing failures')
  }
}

const showDelete = async (row)=>{
  try {
    await ElMessageBox.confirm(`Confirm deletion ${row.schoolId}?`, 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    await deleteSchoolData(row.id)
    total.value -=1;
    await showSchools()
    updatePaginatedData()
    ElMessage.success('Delete successfully')
  }catch (error){
    ElMessage.info(`Cancel deletion ${row.schoolId}`)
  }

}

const showBackup = async () => {
  try {
    backupLoading.value = true
    await ElMessageBox.confirm('Are you sure you want to perform a data backup?', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    const resp = await databaseBackup()
    const fullUrl = `${resp.data?.backupPath?.replace(/\\/g, '/')}`
    storagePath(fullUrl)
    console.log(fullUrl)
    ElMessage.success('Backup successful！')
  } catch (error) {
    ElMessage.info(`Canceling a backup`)
  } finally {
    backupLoading.value = false
  }
}

const showRestore = async () => {
  try {
    restoreLoading.value = true
    await ElMessageBox.confirm('Are you sure you want to recover your data? This operation overwrites the existing data', 'Warnings', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    const fullUrl = localStorage.getItem('fullUrl')
    const restore = {
      backupPath:fullUrl
    }
    await databaseRestore(restore)
    ElMessage.success('Recovery successful! The system may need a refresh')
  } catch (error) {
    ElMessage.info(`Cancel recovery data`)
  } finally {
    restoreLoading.value = false
  }
}

const storagePath = (fullUrl) => {
  localStorage.setItem('fullUrl',fullUrl)
}

watch([currentPage, pageSize], () => {
  if (!searchSchoolId.value) {
    updatePaginatedData()
  }
})

onUnmounted(() => {
  schoolSearch?.cancel();
});

</script>

<style>
.header-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding: 0 10px;
}

.total-count {
  font-weight: bold;
  font-size: 14px;
  color: #606266;
}

.search-container {
  display: flex;
  gap: 8px;
}


.search-input {
  width: 200px;
}

.search-btn {
  width: 100px;
}


.btn-container {
  display: none;
}

.table-container {
  margin-top: 15px;
}

.school-pagination-block {
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

</style>