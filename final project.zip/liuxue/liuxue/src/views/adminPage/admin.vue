<template>
  <el-container class="layout-container-demo" style="height: 700px">
    <el-aside class="aside-nav"
              width="210px"
      >
      <div class="block">
        <el-avatar class="qiuqiu" :size="40" :src="circleUrl" />
        <span class="username">{{ name }}</span>
      </div>
      <el-menu class="menu-nav" router :default-active="activePath">
        <el-menu-item
            v-for="route in adminRoutes[0].children"
            :key="route.path"
            :index="route.path"
            :class="{ 'is-active': $route.path === route.path }"
        >
          <span>{{ route.meta?.title || route.name }}</span>
          </el-menu-item>
      </el-menu>
      <el-button class="border-top-bottom" >
        <span @click="ShowExit" >Exit</span>
      </el-button>
    </el-aside>
    <el-container>
      <el-header style="height: auto; text-align: center; font-size: 50px">
        <div>{{ $route.name }}</div>
      </el-header>

      <el-main class="content">
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script  setup>
import adminRoutes from '@/router/adminRoutes';
import {computed, onMounted, reactive, ref, toRefs} from 'vue';
import { useRoute } from 'vue-router';
import router from "@/router";
import {ElMessage} from "element-plus";

const route = useRoute();
const name = ref(null)

const activePath = computed(() => route.matched[0].path);

onMounted(()=>{
  getName();
})

const getName = () => {
  try {
    const username = localStorage.getItem('name');
    if (!username) {
      return router.replace('/login');
    }
    name.value = username;
  } catch (error) {
    console.error('Fail to get school:', error);
    router.replace('/login');
  }
};

const state = reactive({
  circleUrl:
      'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png',
})

const { circleUrl } = toRefs(state)

const ShowExit = ()=>{
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('path');
    router.replace('/');
    ElMessage.success('Exited safely');
  } catch (error) {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    localStorage.removeItem('role');
    localStorage.removeItem('path');
    router.replace('/');
  }
}

</script>

<style scoped>


.layout-container-demo{
  display: flex;
}
.block {
  margin-left: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
  flex: 1;
  margin-top: 15px;
  margin-bottom: 15px;
}
.aside-nav {
  border-right: 1px solid #e6e6e6;
  height: 100vh;
  color: #e6e6e6;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-color: rgba(0, 0, 0, 0.7);
  border-right: 1px solid #e6e6e6;
  position: fixed;  /* 修改为 fixed 定位 */
  left: 0;
  top: 0;
  bottom: 0;
  width: 210px;  /* 保持与 el-aside 的 width 属性一致 */
  border-right: 1px solid #e6e6e6;
  box-sizing: border-box;
  z-index: 1000;  /* 确保导航栏在内容上方 */
}
.el-menu-item {
  color: white;
  border-bottom: 1px solid #f0f0f0;
}
.content {
  flex-grow: 1;
  padding: 20px;
  margin-left: 200px;  /* 添加左边距避开侧边栏 */
  width: calc(100% - 200px);  /* 计算剩余宽度 */
}
.is-active {
  color: #409eff;
}
.menu-nav{
  color: white;
  border-right: none;
  flex-grow: 1;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1); /* 调整边框透明度 */
  backdrop-filter: blur(10px); /* 添加背景模糊效果 */
  background-color: rgba(255, 255, 255, 0.1); /* 半透明背景增强模糊效果 */
  transition: all 0.3s ease; /* 添加过渡动画 */
}

.border-top-bottom {
  color: #e6e6e6;
  border-left: none !important;
  border-right: none !important;
  border-top: 1px solid #DCDFE6 !important;
  border-bottom: 1px solid #DCDFE6 !important;
  border-radius: 0 !important;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1); /* 调整边框透明度 */
  backdrop-filter: blur(10px); /* 添加背景模糊效果 */
  background-color: rgba(255, 255, 255, 0.1); /* 半透明背景增强模糊效果 */
  transition: all 0.3s ease; /* 添加过渡动画 */
}
.el-button, .el-button.is-round {
  padding: 8px 15px;
  width: 350px;
  height: 55px;
  margin-left: -142px;
  border-right: none;
  flex-grow: 1;
}
</style>