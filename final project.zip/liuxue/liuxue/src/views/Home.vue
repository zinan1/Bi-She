<template>
  <div class="app-container">
    <!-- Navigation Bar -->
    <nav class="main-nav" :class="{ 'nav-hidden': !showNav }">
      <div class="nav-container">
        <router-link to="/" class="nav-item">Home</router-link>
        <router-link to="/resourceCenter" class="nav-item">Cultural Exchange</router-link>
        <router-link to="/login" class="nav-item">Login</router-link>
      </div>
    </nav>
    <div class="home-container">
      <header class='nav'>
        <h1 class="header-title">Welcome to International Students Studying in China</h1>
      </header>
      <!-- Page content -->
      <main class="image-content">
        <div class="image-text">
          <img src="../assets/home2.png" alt="description" class="image-nav">
          <div class="text-container">
            <h2 class="t-text">Start your study in China journey</h2>
            <button class="start-btn" round @click="showLogin">Get Started →</button>
            <h2 class="tt-text">We provide you with comprehensive information and guidance to help you realize your dream of studying abroad and experience the wonderful Chinese culture.</h2>
          </div>
        </div>
      </main>
    </div>

    <!-- Services Section -->
    <div class="services-section">
      <div class="service-cards">
        <div class="service-card">
          <div class="card-number">01</div>
          <h3 class="card-title">University Search</h3>
          <p class="card-desc">Quickly find information about Chinese universities, including programs and application requirements.</p>
        </div>
        <div class="service-card">
          <div class="card-number">02</div>
          <h3 class="card-title">University Information</h3>
          <p class="card-desc">Provides the latest university information to help you choose the right one for you.</p>
        </div>
        <div class="service-card">
          <div class="card-number">03</div>
          <h3 class="card-title">Visa Guidance</h3>
          <p class="card-desc">Detailed visa application process and document preparation guidance.</p>
        </div>
      </div>
    </div>
    <!-- Application Process Section -->
    <div class="application-process">
      <div class="process-container">
        <div class="process-content">
          <h2 class="process-title">Study Abroad Application Process</h2>
          <h3 class="process-subtitle">Clear Application Steps</h3>
          <p class="process-desc">
            We provide detailed guidance for the study abroad application process, from document preparation to visa processing, with professional advice at every step.
            We also offer various practical tools and resources, such as application checklists and essay writing guides, to help you prepare application materials efficiently.
          </p>
          <ul class="process-features">
            <li>
              <strong>Document Preparation</strong>
              <span>Detailed application checklist and preparation guide to ensure you're fully prepared.</span>
            </li>
            <li>
              <strong>University Selection</strong>
              <span>Recommend suitable Chinese universities and programs based on your interests and background.</span>
            </li>
            <li>
              <strong>Visa Processing</strong>
              <span>Professional visa application guidance to help you obtain your student visa smoothly.</span>
            </li>
          </ul>
        </div>
        <div class="process-image"></div>
      </div>
    </div>
    <!-- Contact Section -->
    <div class="contact-section">
      <div class="contact-container">
        <h2 class="contact-title">Contact Us</h2>
        <p class="contact-desc">
          If you have any questions about studying in China, please feel free to contact us. We're here to help.
        </p>

        <div class="contact-info">
          <div class="info-item">
            <h3>Working Hours</h3>
            <p>Monday to Friday 9:00 am - 6:00 pm</p>
          </div>

          <div class="info-item">
            <h3>My Address</h3>
            <p>3119163101@qq.com</p>
          </div>

          <div class="info-item">
            <h3>Contact Information</h3>
            <p>+86-15203048411</p>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer -->
    <footer class="main-footer">
      <div class="footer-content">
        <p class="copyright">© 2025 International Student University Selection System</p>
        <p class="authors">Authors: Yangming Qin; Zian Yu; Zhongyuan Ren</p>
      </div>
    </footer>
  </div>
</template>

<script setup >
import { ref, onMounted, onUnmounted } from 'vue';
import router from "@/router";
import {ElMessage} from "element-plus";

// The navigation bar shows controls
const showNav = ref(true);
let lastScrollPosition = 0;

const handleScroll = () => {
  const currentScrollPosition = window.pageYOffset || document.documentElement.scrollTop;

  // Hide the navigation bar when scrolling down past a certain distance
  if (currentScrollPosition > lastScrollPosition && currentScrollPosition > 100) {
    showNav.value = false;
  }
  // Displays the navigation bar when scrolling up
  else if (currentScrollPosition < lastScrollPosition) {
    showNav.value = true;
  }

  lastScrollPosition = currentScrollPosition;
};

onMounted(() => {
  window.addEventListener('scroll', handleScroll);
});

onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll);
});

const showLogin = async () => {
  try {
    const username = localStorage.getItem('name');
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');

    // If the username or token doesn't exist, navigate to the login page
    if (!username || !token) {
      await router.replace('/login');
      return;
    }
    // Navigate to different pages depending on the role
    switch (role) {
      case 'STUDENT':
        await router.replace('/studentPage');
        break;
      case 'SCHOOL':
        await router.replace('/schoolPage');
        break;
      case 'ADMIN':
        await router.replace('/adminPage');
        break;
      default:
        await router.replace('/login');
    }
  } catch (error) {
    console.error('Route jump failed:', error);
    ElMessage.error('Login status is abnormal, please login again');
    await router.replace('/login');
  }
};
</script>

<style>
/* Navigation bar styles */
.main-nav {
  position: fixed;
  top: 0;
  left: 8px;
  right: 8px;
  background-color: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(5px);
  box-shadow: 0 2px 15px rgba(0, 0, 0, 0.3);
  z-index: 1000;
  transition: all 0.3s ease;
}

.nav-container {
  display: flex;
  justify-content: center;
  max-width: 1200px;
  margin: 0 auto;
  padding: 15px 20px;
}

.nav-item {
  padding: 12px 25px;
  color: white;
  text-decoration: none;
  font-size: 16px;
  font-weight: 500;
  transition: all 0.3s ease;
  position: relative;
  opacity: 0.9;
}

.nav-item:hover {
  color: #fff;
  opacity: 1;
  text-shadow: 0 0 5px rgba(255, 255, 255, 0.5);
}

.nav-item::after {
  content: '';
  position: absolute;
  bottom: 8px;
  left: 25px;
  right: 25px;
  height: 2px;
  background-color: white;
  transform: scaleX(0);
  transition: transform 0.3s ease;
}

.nav-item:hover::after {
  transform: scaleX(1);
}

.nav-hidden {
  transform: translateY(-100%);
  opacity: 0;
}

.home-container {
  margin-top: 70px;
  min-height: calc(100vh - 70px);
}

@media (max-width: 768px) {
  .nav-container {
    padding: 10px 5px;
  }

  .nav-item {
    padding: 10px 15px;
    font-size: 14px;
  }

  .home-container {
    margin-top: 60px;
    min-height: calc(100vh - 60px);
  }
}

.home-container {
  min-height: 100vh;
  text-align: center;
  padding: 50px;
  background-image: url('~@/assets/home1.png');
  background-size: cover;
  background-position: center;
  filter: brightness(1.5);
}

@media (max-width: 768px) {
  .nav-container {
    padding: 10px;
  }

  .nav-item {
    padding: 8px 12px;
    font-size: 14px;
  }

  .home-container {
    margin-top: 60px;
    min-height: calc(100vh - 60px);
  }
}

.content-section {
  padding: 50px;
  background-color: #f5f5f5;
}

.content-item {
  max-width: 800px;
  margin: 0 auto 40px;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.content-item h2 {
  color: #333;
  margin-bottom: 15px;
}

.content-item p, .content-item ul {
  color: #666;
  line-height: 1.6;
}

.content-item ul {
  padding-left: 20px;
}

/* app-container */
.app-container {
  height: 100vh;
}
.action-buttons {
  margin-top: 30px;
  display: flex;
  justify-content: center;
  gap: 20px;
}

.action-buttons .el-button {
  width: 120px;
  padding: 28px 30px;
}

.header-title{
  margin-top: auto;
  color: white;
  font-size: 50px;
}
.el-button, .el-button.is-round {
  padding: 28px 30px;
}
.login-btn {
  width: 150px;
  height: 250px;
  margin-left: 450px;
  font-size: 200px;
}
.image-content {
  padding: 20px;
}
.image-nav{
  display: flex;
  width: 600px;
  height: 500px;
  margin-left: 50px;
  display: block;
  opacity: 0.2;
  border-radius: 0 100px 0 100px;
}


.image-text {
  display: flex;
  align-items: flex-start;
  gap: 20px;
}

.text-container {
  display: flex;
  flex-direction: column;
  margin-top: 50px;
}

.t-text {
  color: white;
  font-size: 40px;
  margin-bottom: 20px;
  align-self: flex-start;
}

.start-btn {
  width: 150px;
  height: 70px;
  align-self: flex-start;
  padding: 20px;
  border-radius: 50px 50px 50px 50px;
  border: none !important;
  outline: none !important;
  box-shadow: none !important;
  font-size: 15px;
  font-weight: bold;
  margin-top: 50px;
}
.tt-text{
  color: white;
  margin-top: 50px;
  padding: 20px;
  align-self: flex-start;
  border: none !important;
  outline: none !important;
  box-shadow: none !important;
  font-size: 19px;
}

/* Service block style */
.services-section {
  padding: 10px 5px;
  background-color: #fff;
  background-image: url('~@/assets/home3.png');
  background-size: cover;
  background-position: center;
}

.service-cards {
  display: flex;
  justify-content: center;
  gap: 30px;
  max-width: 1200px;
  margin: 0 auto;
  flex-wrap: wrap;
}

.service-card {
  flex: 1;
  min-width: 100px;
  max-width: 380px;
  padding: 10px 5px;
  background: #f9f9f9;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.08);
  transition: transform 0.3s ease;
}

.service-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 8px 25px rgba(0,0,0,0.12);
}

.card-number {
  font-size: 32px;
  font-weight: bold;
  color: #1890ff;
  margin-bottom: 15px;
}

.card-title {
  font-size: 24px;
  color: #333;
  margin-bottom: 15px;
}

.card-desc {
  font-size: 16px;
  color: #666;
  line-height: 1.6;
}

@media (max-width: 768px) {
  .service-cards {
    flex-direction: column;
    align-items: center;
  }

  .service-card {
    width: 100%;
    max-width: 100%;
  }
}

/* Study abroad Block style */
.application-process {
  padding: 60px 0;
  background-color: #ffca80;
  background-image: url('~@/assets/home1.png');
  background-size: cover;
  background-position: center;
}

.process-container {
  display: flex;
  max-width: 1200px;
  margin: 0 auto;
  align-items: center;
}

.process-content {
  flex: 1;
  padding: 0 40px;
}

.process-image {
  flex: 1;
  height: 500px;
  background-image: url('~@/assets/home4.png');
  background-size: contain;
  background-position: center;
  background-repeat: no-repeat;
  display: block;
  opacity: 0.2;
  border-radius: 100px 100px 100px 100px;
}

.process-title {
  font-size: 36px;
  color: white;
  margin-bottom: 15px;
}

.process-subtitle {
  color: white;
  font-size: 24px;
  margin-bottom: 20px;
}

.process-desc {
  font-size: 16px;
  color: white;
  line-height: 1.8;
  margin-bottom: 30px;
}

.process-features {
  color: white;
  list-style: none;
  padding: 0;
}

.process-features li {
  color: white;
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
}

.process-features strong {
  color: white;
  font-size: 18px;
  margin-bottom: 8px;
}

.process-features span {
  color: white;
  font-size: 15px;
  line-height: 1.6;
}

@media (max-width: 768px) {
  .process-container {
    flex-direction: column;
  }

  .process-content {
    padding: 20px;
    margin-bottom: 30px;
  }

  .process-image {
    width: 100%;
    height: 300px;
  }
}
/* Contact block styles */
.contact-section {
  padding: 60px 0;
  background-color: #ffca80;
  border-top: 1px solid #e8e8e8;
}

.contact-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 0 20px;
  text-align: center;
}

.contact-title {
  font-size: 32px;
  color: #333;
  margin-bottom: 20px;
  position: relative;
  display: inline-block;
}

.contact-title::after {
  content: '';
  position: absolute;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
  width: 80px;
  height: 3px;
  background-color: #1890ff;
}

.contact-desc {
  font-size: 16px;
  color: #666;
  line-height: 1.8;
  margin-bottom: 40px;
}

.contact-info {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: 30px;
}

.info-item {
  flex: 1;
  min-width: 200px;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.info-item h3 {
  color: #333;
  font-size: 18px;
  margin-bottom: 15px;
  position: relative;
  padding-bottom: 10px;
}

.info-item h3::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 40px;
  height: 2px;
  background-color: #1890ff;
}

.info-item p {
  color: #666;
  line-height: 1.6;
  font-size: 15px;
}

@media (max-width: 600px) {
  .contact-info {
    flex-direction: column;
    align-items: center;
  }

  .info-item {
    width: 100%;
    max-width: 300px;
  }
}

/* Footer styles */
.main-footer {
  background-color: #000;
  color: #fff;
  padding: 30px 0;
  text-align: center;
  font-size: 14px;
}

.footer-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.copyright {
  margin-bottom: 10px;
  color: rgba(255, 255, 255, 0.8);
}

.authors {
  color: rgba(255, 255, 255, 0.6);
  font-size: 13px;
}

@media (max-width: 768px) {
  .main-footer {
    padding: 20px 0;
  }

  .copyright, .authors {
    font-size: 12px;
  }
}
</style>
