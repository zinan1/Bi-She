<template>
  <div>
    <h1>Schools view student application information</h1>
    <div class="table-container">
      <el-table
          :data="studentApplicationData"
          v-loading="loading"
          style="width: 100%"
          stripe
          border
          highlight-current-row
      >
        <el-table-column
            label="ID"
            prop="id"
            width="80"
            align="center"
        />
        <el-table-column
            label="Student ID"
            prop="student.studentId"
            width="100"
            align="center"
        />
        <el-table-column
            label="GPA"
            prop="gpa"
            width="80"
            align="center"
        />
        <el-table-column
            label="Grades"
            prop="grades"
            width="80"
            align="center"
        />
        <el-table-column
            label="Major"
            prop="major"
            align="center"
        />
        <el-table-column
            label="Current School"
            prop="currentschool"
            align="center"
        />
        <el-table-column
            label="Graduation(Yes or No)"
            prop="enrolled"
            width="100"
            align="center"
        />
        <el-table-column label="Status" prop="status" width="135" align="center">
          <template #default="{ row }">
            <el-tag
                :type="getStatusTagType(row.status)"
                effect="light"
            >
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
            label="Application Date"
            prop="applicationDate"
            align="center"
        />
        <el-table-column
            label="Processed Date"
            prop="processedDate"
            align="center"
        />
        <el-table-column label="Application Materials" align="center" width="110">
          <template #default="{ row }">
            <el-button 
              size="small"
              type="primary"
              @click="async () => {
                const filePath = await showApplicationFiles(row.id);
                await handleDownload(filePath);
              }"
            >
              Download
            </el-button>
          </template>
        </el-table-column>
        <el-table-column label="Operations" align="center" width="155">
          <template #default="{ row }" >
            <el-button
                class="show-btn"
                size="small"
                type="success"
                @click="showAgree(row)"
            >
              Agree
            </el-button>
            <el-button
                class="show-btn"
                size="small"
                type="danger"
                @click="showRefuse(row)"
            >
              Refuse
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

//<script setup>
import {
  viewApplication,
  agreeApplication,
  refuseApplication,
  getApplicationFile,
  downloadApplicationFile
} from '@/api/applicationApi'
import {ref, onMounted} from "vue";
import {ElMessage, ElMessageBox} from "element-plus";

const studentApplicationData = ref([])
const loading = ref(false);

onMounted(()=>{
 getStudentApplicationSchool();
})

const getStudentApplicationSchool = async () => {
  loading.value = true;
  try {
    const {data} = await viewApplication();
    studentApplicationData.value = data;
    console.log(studentApplicationData)
  }catch (error){
    ElMessage.error('Failed to fetch data')
    studentApplicationData.value = [];
  }finally {
    loading.value = false;
  }
}
//Consent to application
const showAgree = async (row)=>{
  try {
    await ElMessageBox.confirm('Agree' + row?.student?.studentId + 'application', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    await agreeApplication(row.id)
    await getStudentApplicationSchool();
    ElMessage.success('Agree' + row?.student?.studentId + 'application success')
  }catch (error){
    ElMessage.info('Cancel the student\'s application')
  }
}
//Refusal of application
const showRefuse = async (row)=>{
  try {
    await ElMessageBox.confirm('reject' + row?.student?.studentId + 'application', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    await refuseApplication(row.id);
    await getStudentApplicationSchool();
    ElMessage.success('reject' + row?.student?.studentId + 'application success')
  }catch (error){
    ElMessage.info('Failed to reject application')
  }
}

const getStatusTagType = (status) => {
  switch (status) {
    case 'APPROVED':
      return 'success';
    case 'REJECTED':
      return 'danger';
    default:
      return 'info';
  }
}
// See application attachment
const showApplicationFiles = async (applicationId) => {
  try {
    const response = await getApplicationFile(applicationId);
    if (response.data && response.data.length > 0) {
      const fullPath = response.data[0]?.replace(/\\/g, '/');
      return fullPath?.split('/').pop();
    } else {
      ElMessage.info('There is no attachment to the application');
      return null;
    }
  } catch (error) {
    console.error('Failed to get attachment:', error);
    ElMessage.error('Failed to get attachment: ' + error.message);
    return null;
  }
};

// Downloading the file
const handleDownload = async (filePath) => {
  try {
    if (!filePath) {
      ElMessage.info('No attachments are available for download');
      return;
    }

    const response = await downloadApplicationFile(filePath);

    // Creating a download link
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;

    // Extract the filename from the path
    const fileName = filePath.split('/').pop();
    link.setAttribute('download', fileName);

    document.body.appendChild(link);
    link.click();
    link.remove();

    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Download failed:', error);
    ElMessage.error('Download failed: ' + error.message);
  }
};
</script>

<style scoped>
h1{
  text-align: center;
}
</style>