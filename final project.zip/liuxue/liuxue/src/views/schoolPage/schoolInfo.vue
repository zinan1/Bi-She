<template>
  <div>
    <div>
      <h1>School Information</h1>
    </div>
    <div>
      <el-descriptions title=" "  border>
        <el-descriptions-item
            :rowspan="2"
            :width="140"
            label="Photo"
            align="center"
        >
          <el-image
              style="width: 100px; height: 100px"
              :src="getFullAvatarUrl(schoolData.avatar)"
              fit="cover"
              @click="triggerFileInput"
              class="hoverable-image"
          />
          <input
              type="file"
              ref="fileInput"
              style="display: none"
              accept="image/*"
              @change="handleFileChange"
          />
        </el-descriptions-item>
        <el-descriptions-item label="ID" align="center">
          {{ schoolData.id }}
        </el-descriptions-item>
        <el-descriptions-item label="username" align="center">
          {{ schoolData.schoolId }}
        </el-descriptions-item>
        <el-descriptions-item label="schoolName" align="center">
          {{ schoolData.schoolName }}
        </el-descriptions-item>
        <el-descriptions-item label="location" align="center">
          {{ schoolData.location }}
        </el-descriptions-item>
        <el-descriptions-item label="Contact Phone" align="center">
          {{ schoolData.contactPhone }}
        </el-descriptions-item>
        <el-descriptions-item label="Contact Email" align="center">
          {{ schoolData.contactEmail }}
        </el-descriptions-item>
        <el-descriptions-item align="center">
          <template #label>
            <div class="label-center" >Website</div>
          </template>
          {{ schoolData.website }}
        </el-descriptions-item>
      </el-descriptions>
    </div>

    <div>
      <el-descriptions
          title=" "
          direction="vertical"
          border
          style="margin-top: 20px"
      >
        <el-descriptions-item
            :rowspan="2"
            :width="140"
            label="Description"
        >
          <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            <span style="margin-right: 8px;">
              {{ schoolData.description }}
            </span>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </div>

    <div>
      <el-descriptions
          title=" "
          direction="vertical"
          border
          style="margin-top: 20px"
      >
        <el-descriptions-item
            :rowspan="2"
            :width="140"
            label="Apply Request"
        >
          <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            <span style="margin-right: 8px;">
          {{ schoolData.applyrequest }}
            </span>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </div>

    <div>
      <el-descriptions
          title=" "
          direction="vertical"
          border
          style="margin-top: 20px"
      >
        <el-descriptions-item
            :rowspan="2"
            :width="140"
            label="The majors offered by the school"
        >
          <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            <span v-for="(major, index) in schoolData?.majors" :key="index" style="margin-right: 8px;">
              {{ major }};
            </span>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </div>
    <div class="show-btn" style="position: absolute; right: 30px; margin-top: 50px;" >
      Change school information →
      <el-button round size="large" @click="showEdit">
        Edit
      </el-button>
    </div>
    <div>
      <el-dialog
          v-model="dialogVisible"
          :title="dialogTitle"
          width="50%"
          align="center"
      >
        <el-form
            :model="schoolForm"
            ref="schoolFormRef"
            label-width="120px"
        >
          <el-form-item label="ID" prop="id" required>
            <el-input v-model="schoolForm.id" readonly />
          </el-form-item>
          <el-form-item label="School ID" prop="schoolId" required>
            <el-input v-model="schoolForm.schoolId" readonly />
          </el-form-item>
          <el-form-item label="School Name" prop="schoolName" required>
            <el-input v-model="schoolForm.schoolName" />
          </el-form-item>
          <el-form-item label="Location" prop="location" >
            <el-input v-model="schoolForm.location" />
          </el-form-item>
          <el-form-item label="Description" prop="description" >
            <el-input v-model="schoolForm.description" />
          </el-form-item>
          <el-form-item label="Contact Phone" prop="contactPhone">
            <el-input v-model="schoolForm.contactPhone" />
          </el-form-item>
          <el-form-item label="Contact Email" prop="contactEmail">
            <el-input v-model="schoolForm.contactEmail" />
          </el-form-item>
          <el-form-item label="Website" prop="website">
            <el-input v-model="schoolForm.website" type="textarea" />
          </el-form-item>
          <el-form-item label="Apply Request" prop="applyrequest">
            <el-input v-model="schoolForm.applyrequest" type="textarea" />
          </el-form-item>
          <el-form-item label="Majors" prop="majors">
            <el-input
                v-model="schoolForm.majors"
                type="textarea"
                :rows="2"
            />
            <div class="majors-hint">
              Enter a major, separated by commas or Spaces (e.g., XX College-XX Department-XX Major.)
            </div>
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitForm">Confirm</el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import {ElMessage, ElMessageBox} from "element-plus";
import {editSingleSchoolData, SingleSchoolData, addSchoolPhoto } from "@/api/schoolApi";
import axios from "axios";

// Dialog box control
const dialogVisible = ref(false)
const dialogTitle = ref('')
const showName = ref('')
// Form references
const schoolFormRef = ref(null)

const fileInput = ref(null);
const loading = ref(false);
// School Form
const schoolForm = ref({})

const schoolData = ref({
  avatar:'',
  id: '',
  schoolId: '',
  schoolName: '',
  location: '',
  description: '',
  contactPhone: '',
  contactEmail: '',
  website: '',
  majors:'',
  applyrequest:''
});

onMounted( ()=>{
  getSchoolData()
})

const getSchoolData = async () => {
  try {
    const {data} = await SingleSchoolData();
    schoolData.value = data;
    showName.value = data.schoolName;
    schoolForm.value = {...data}
    console.log(schoolData.value)
  }catch (error) {
    ElMessage.error('Failed to fetch data');
  }
}

const getFullAvatarUrl = (path) => {
  setLocalUrl(path)
  const BaseUrl = 'http://localhost:8082';
  switch (path){
    case '/avatars/default_school.png':
      return `${BaseUrl}/avatars/default_school.png`;
    default:
      return `${BaseUrl}/${path}`;
  }
};

const setLocalUrl = (path) => {
  localStorage.setItem('path',path)
}

const triggerFileInput = () => {
  fileInput.value.click();
};

// Handling file selection
const handleFileChange = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  // Checking the file type
  if (!file.type.startsWith('image/')) {
    ElMessage.error('Please select the image file');
    return;
  }

  // Checking file size
  if (file.size > 2 * 1024 * 1024) {
    ElMessage.error('Images cannot exceed 2MB in size');
    return;
  }

  try {
    loading.value = true;

    const token = localStorage.getItem('token')
    // 1. Upload images to the backend
    const formData = new FormData();
    formData.append('file', file);
    console.log(formData)

    const response = await axios.post('http://localhost:8082/api/school/avatar', formData, {
      headers: {
        'Authorization': token,
        'Content-Type': 'multipart/form-data'
      }
    });

    const avatarUrl = response.data?.avatarUrl
    console.log('school ' + avatarUrl)
    const fullUrl = `${avatarUrl?.replace(/\\/g, '/')}`
    console.log('school ' + fullUrl)

    schoolData.value.avatar = fullUrl

    ElMessage.success('图片更新成功');
  } catch (error) {
    ElMessage.error('图片更新失败: ');
  } finally {
    loading.value = false;
    // Clear the input so that you can select the same file to upload again
    event.target.value = '';
  }
};

const showEdit = async () =>{
  try {
    await ElMessageBox.confirm('The id and username cannot be modified', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    dialogTitle.value = showName.value
    dialogVisible.value = true
  } catch (error) {
    ElMessage.info('Canceling changes');
  }
}

const submitForm = async () => {
  try {
    await ElMessageBox.confirm('Confirm to modify personal information!', 'Tips', {
      confirmButtonText: 'Confirm',
      cancelButtonText: 'Cancel',
      type: 'warning'
    })
    //Split by commas or Spaces, and remove whitespace characters. Already an array, use it directly. If it's a string, split it by comma/space
    const majorsArray = Array.isArray(schoolForm.value.majors)
        ? schoolForm.value.majors
        : (schoolForm.value.majors || '')
            .split(/[,，]/)
            .map(item => item.trim())
            .filter(item => item !== '');
    //Construct commit data
    const payload = {
      ...schoolForm.value,
      majors: majorsArray
    };
    const {data} = await editSingleSchoolData(payload);
    schoolData.value = data
    ElMessage.success('Change success');
    dialogVisible.value = false;
  } catch (error) {
    ElMessage.error('Change failed');
  }
}

</script>

<style scoped>
h1{
  text-align: center;
}
.label-center{
  text-align: center;
}
.show-btn{
  text-align: right;
 }
.majors-hint{
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
.hoverable-image {
  transition: transform 0.3s ease;
  cursor: pointer;
}

.hoverable-image:hover {
  transform: scale(1.05);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}
</style>