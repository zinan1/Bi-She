const { defineConfig } = require('@vue/cli-service')
const webpack = require('webpack') // 引入 webpack
module.exports = defineConfig({
  devServer: {  // 所有开发服务器配置都放在这里
    port: 8080,
    historyApiFallback: true,  // 支持History模式
    client: {
      overlay: {
        runtimeErrors: (error) => {
          if (error.message.includes('ResizeObserver')) {
            return false;
          }
          return true;
        },
      },
    },
    proxy: {
      '/api': {
        target: 'http://localhost:8082',
        changeOrigin: true,
        pathRewrite: {
          '^/api': '',
        },
      },
    },
  },
  transpileDependencies: true,
  // 新增 configureWebpack 配置
  configureWebpack: {
    plugins: [
      new webpack.DefinePlugin({
        __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: JSON.stringify(false), // 关闭 hydration 不匹配详细警告
      }),
    ],
  },
})
